'use strict';
/* UROBOROS · URB2 — arnês de calibração
 *
 * DUAS FASES SEPARADAS, porque custam coisas diferentes:
 *
 *   fase sigma      → só L0 (amostragem crua) + juiz. N chamadas por item.
 *                     Σ é propriedade das CÉLULAS, não do pipeline: não
 *                     precisa de atomização, BP, entropia nem síntese.
 *   fase conformal  → pipeline completo. Muito mais caro por item, mas
 *                     precisa de bem menos itens (ver a tabela do +1).
 *
 * RESUMÍVEL. Termux mata processo longo. Cada item é gravado em JSONL
 * imediatamente; reexecutar continua de onde parou.
 *
 * JULGAMENTO DETERMINÍSTICO quando o item traz gabarito numérico ou exato —
 * zero chamadas de juiz, zero viés de juiz. Só cai no juiz LLM para itens
 * factuais curados.
 *
 *   node tools/gerar-bench.js 240 42 > bench/sintetico.json
 *   node tools/calibrar.js --fase sigma     --bench bench/sintetico.json
 *   node tools/calibrar.js --fase conformal --bench bench/sintetico.json --n 80
 *   node tools/calibrar.js --relatorio
 */

require('../lib/env').carregar();
const fs = require('fs');
const path = require('path');
const { Uroboros } = require('../orchestrator');
const { glsWeights } = require('../lib/epistemic');
const { structuredCovariance, diagnose, tetrachoric } = require('../lib/estimador');
const { Conformal } = require('../lib/conformal');
const { call, parseJSON, REG } = require('../lib/providers');

const DATA = process.env.DATA_DIR || './data';

/* ---------------- argumentos ---------------- */
function args() {
  const a = process.argv.slice(2), o = { fase: null, bench: null, n: 0, relatorio: false, dominio: null };
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--fase') o.fase = a[++i];
    else if (a[i] === '--bench') o.bench = a[++i];
    else if (a[i] === '--n') o.n = Number(a[++i]);
    else if (a[i] === '--dominio') o.dominio = a[++i];
    else if (a[i] === '--relatorio') o.relatorio = true;
  }
  return o;
}

/* ---------------- checkpoint JSONL ---------------- */
function lerCkpt(f) {
  if (!fs.existsSync(f)) return [];
  return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}
function gravar(f, obj) {
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.appendFileSync(f, JSON.stringify(obj) + '\n');
}

/* ---------------- julgamento ---------------- */
// (?<![A-Za-z_\d]) impede casar o "0" de "t0", "H0", "x1" — falso positivo
// que contaminaria o julgamento quando o gabarito for próximo de zero.
const NUM_RE = /(?<![A-Za-z_\d])-?\d[\d.,]*(?:\s*[×x*]\s*10\s*\^?\s*-?\d+|\s*[eE]\s*[+-]?\d+)?/g;

function extrairNumeros(txt) {
  const out = [];
  for (const m of String(txt).matchAll(NUM_RE)) {
    let s = m[0].replace(/\s/g, '');
    const sci = /^(-?[\d.,]+)(?:[×x*]10\^?|[eE])([+-]?\d+)$/.exec(s);
    let v;
    if (sci) v = parseFloat(norm(sci[1])) * Math.pow(10, parseInt(sci[2], 10));
    else v = parseFloat(norm(s));
    if (Number.isFinite(v)) out.push(v);
  }
  return out;
  function norm(x) { return x.includes(',') && !x.includes('.') ? x.replace(',', '.') : x.replace(/,/g, ''); }
}

/**
 * Números da RESPOSTA que não aparecem no ENUNCIADO. Sem isso, uma resposta
 * que só repete os parâmetros de entrada seria contada como acerto.
 */
function candidatos(resposta, pergunta) {
  const nq = new Set(extrairNumeros(pergunta).map(x => x.toPrecision(6)));
  return extrairNumeros(resposta).filter(v => !nq.has(v.toPrecision(6)));
}

async function julgar(U, item, resposta) {
  if (!resposta) return false;
  if (item.exato) {
    const n = s => String(s).toLowerCase().replace(/\s+/g, '');
    return n(resposta).includes(n(item.exato));
  }
  if (item.num != null && item.tol != null) {
    const cand = candidatos(resposta, item.q);
    if (!cand.length) return false;
    const alvo = Number(item.num);
    return cand.some(v => Math.abs(v - alvo) <= Math.max(item.tol * Math.abs(alvo), 1e-12));
  }
  // item factual curado: juiz LLM
  try {
    const r = await call(U.judge.provider, {
      system: 'Julgue se a RESPOSTA está correta dado o GABARITO. Ignore estilo e verbosidade. Valores numéricos coincidem dentro de 2%. Responda APENAS JSON: {"correto":true|false}',
      json: true, temperature: 0, maxTokens: 120,
      messages: [{ role: 'user', content: `PERGUNTA: ${item.q}\nGABARITO: ${item.a}\nRESPOSTA: ${String(resposta).slice(0, 2000)}` }]
    });
    return !!parseJSON(r.text)?.correto;
  } catch { return null; }
}

/* ---------------- estimativa de custo ---------------- */
function custo(U, itens, fase) {
  const porProv = {};
  for (const c of U.cells) porProv[c.provider] = (porProv[c.provider] || 0) + 1;
  const mult = fase === 'sigma' ? 1 : 3;            // pipeline completo: amostra + atomização + síntese/juiz
  const linhas = Object.entries(porProv).map(([p, k]) => {
    const chamadas = k * itens * mult;
    const rpm = Number(process.env[`${p.toUpperCase()}_RPM`]) || REG[p].rpm;
    return { provedor: p, celulas: k, chamadas, rpm, minutos: Math.ceil(chamadas / rpm) };
  }).sort((a, b) => b.minutos - a.minutos);
  const total = linhas.reduce((s, l) => s + l.chamadas, 0);
  return { linhas, total, minutos: Math.max(...linhas.map(l => l.minutos)) };
}

/* ---------------- fase Σ ---------------- */
async function faseSigma(U, itens) {
  const ck = `${DATA}/ckpt-sigma.jsonl`;
  const feito = new Set(lerCkpt(ck).map(r => r.id));
  const fila = itens.filter(i => !feito.has(i.id));
  console.log(`fase Σ · ${feito.size} já feitos · ${fila.length} restantes`);
  if (!fila.length) return;

  const c = custo(U, fila.length, 'sigma');
  console.log(`custo estimado: ${c.total} chamadas · ~${c.minutos} min (gargalo: ${c.linhas[0].provedor} a ${c.linhas[0].rpm} rpm)`);

  let i = 0;
  for (const item of fila) {
    i++;
    const resp = await U.sample(item.q, item.dominio || 'geral', null);
    const row = new Array(U.n).fill(null);
    for (const x of resp) row[x.cell.id] = (await julgar(U, item, x.text)) === false ? 1 : 0;
    for (let k = 0; k < U.n; k++) if (row[k] === null) row[k] = 1;   // célula muda conta como erro
    gravar(ck, { id: item.id, dominio: item.dominio, tipo: item.tipo, row, ts: Date.now() });
    const acertos = U.n - row.reduce((a, b) => a + b, 0);
    process.stdout.write(`\r[Σ ${i}/${fila.length}] ${item.id}  ${acertos}/${U.n} corretas    `);
  }
  console.log('\nfase Σ concluída.');
}

/* ---------------- fase conformal ---------------- */
async function faseConformal(U, itens) {
  const ck = `${DATA}/ckpt-conformal.jsonl`;
  const feito = new Set(lerCkpt(ck).map(r => r.id));
  const fila = itens.filter(i => !feito.has(i.id));
  console.log(`fase conformal · ${feito.size} já feitos · ${fila.length} restantes`);
  if (!fila.length) return;

  const c = custo(U, fila.length, 'conformal');
  console.log(`custo estimado: ~${c.total} chamadas · ~${c.minutos} min`);

  let i = 0;
  for (const item of fila) {
    i++;
    const dom = item.dominio || 'geral';
    let r;
    try { r = await U.run(item.q, { domain: dom }); }
    catch (e) { console.log(`\n  [${item.id}] falhou: ${e.message}`); continue; }

    const score = Conformal.score({
      p: r.epistemico.massaModal, Hnorm: r.epistemico.H_semantica,
      nOrigins: r.alegacoes.aceitas[0]?.origens ?? 0, nFamilies: U.families.length,
      verifierChecked: true
    });
    const correto = r.texto ? await julgar(U, item, r.texto) : null;
    gravar(ck, {
      id: item.id, dominio: dom, score, correto,
      absteve: !r.texto, H: r.epistemico.H_semantica, massaModal: r.epistemico.massaModal, ts: Date.now()
    });
    process.stdout.write(`\r[C ${i}/${fila.length}] ${item.id}  s=${score.toFixed(3)}  ${correto === null ? 'abst' : correto ? 'ok' : 'ERRO'}    `);
  }
  console.log('\nfase conformal concluída.');
}

/* ---------------- relatório ---------------- */
function relatorio(U) {
  const sig = lerCkpt(`${DATA}/ckpt-sigma.jsonl`);
  const con = lerCkpt(`${DATA}/ckpt-conformal.jsonl`);
  const out = { geradoEm: new Date().toISOString(), celulas: U.cells.map(c => ({ id: c.id, provider: c.provider, family: c.family, role: c.role })) };

  console.log('\n══════════ RELATÓRIO DE CALIBRAÇÃO ══════════\n');

  if (sig.length >= 20) {
    const E = sig.map(r => r.row);
    const fit = structuredCovariance(E, U.cells);
    const wU = new Array(U.n).fill(1 / U.n);
    const wG = glsWeights(fit.Sigma);
    const dU = diagnose(fit.Sigma, wU), dG = diagnose(fit.Sigma, wG);

    console.log(`Σ estruturada  ·  T = ${fit.T} questões  ·  ${fit.familias.length} famílias`);
    console.log(`  ρ intra-família : ${fit.rhoIntra}`);
    console.log(`  ρ inter-família : ${fit.rhoInter}`);
    console.log(`  N_eff uniforme  : ${dU.N_eff}   (de ${U.n} células)`);
    console.log(`  N_eff com GLS   : ${dG.N_eff}`);
    console.log(`  teto de N_eff   : ${dG.tetoNeff}   ← limite desta Σ, inatingível por mais células`);
    console.log(`  fração comum    : ${(dG.fracaoComum * 100).toFixed(1)}%  do erro é modo comum, irremovível por média`);
    console.log(`  condicionamento : ${dG.condicionamento}`);

    console.log('\n  taxa de erro por célula:');
    U.cells.forEach((c, k) => console.log(`    ${String(k).padStart(2)} ${c.provider.padEnd(11)} ${c.role.padEnd(12)} erro=${(fit.taxaErro[k] * 100).toFixed(1)}%  peso GLS=${wG[k].toFixed(4)}  carga no modo comum=${dG.modoComum[k]}`));

    const mortas = U.cells.map((c, k) => ({ c, k, w: wG[k] })).filter(x => x.w < 0.01);
    if (mortas.length) {
      console.log('\n  células com peso GLS ≈ 0 (redundantes — desligar economiza quota sem perder N_eff):');
      for (const m of mortas) console.log(`    célula ${m.k}: ${m.c.provider}/${m.c.role}  peso=${m.w.toFixed(4)}`);
    }

    console.log('\n  blocos de correlação (φ binário; tetracórica entre parênteses, aproximada):');
    for (const b of fit.blocos.slice(0, 10)) {
      const i = U.cells.findIndex(c => c.family === b.familias[0]);
      const j = U.cells.findIndex((c, k) => k !== i && c.family === b.familias[b.familias.length - 1]);
      const tet = i >= 0 && j >= 0 ? tetrachoric(E, i, j).toFixed(2) : '—';
      console.log(`    ${b.tipo.padEnd(5)} ${b.familias.join(' + ').padEnd(24)} φ=${String(b.rho).padEnd(7)} (tet ${tet})`);
    }

    out.sigma = { T: fit.T, rhoIntra: fit.rhoIntra, rhoInter: fit.rhoInter, Sigma: fit.Sigma.map(r => r.map(x => +x.toFixed(6))), taxaErro: fit.taxaErro, pesosGLS: wG.map(x => +x.toFixed(5)), diagnostico: dG, blocos: fit.blocos };
  } else {
    console.log(`Σ: apenas ${sig.length} questões — mínimo 20. Rode --fase sigma.`);
  }

  if (con.length >= 10) {
    const C = new Conformal({ alpha: Number(process.env.ALPHA) || 0.10, file: `${DATA}/conformal.json` });
    for (const r of con) if (r.correto !== null) C.observe(r.dominio, r.score, r.correto);
    C.save();
    const doms = [...new Set(con.map(r => r.dominio))];
    console.log(`\nConformal  ·  ${con.length} execuções  ·  α = ${C.alpha}`);
    for (const d of doms) {
      const a = C.audit(d);
      if (!a.nCorretos && !a.nErrados) continue;
      console.log(`  ${d.padEnd(14)} n=${String(a.nCorretos + a.nErrados).padStart(4)}  q̂=${a.qhat}  cobertura=${(a.coberturaCorretos ?? 0).toFixed(3)} (alvo ${a.coberturaAlvo})  emissão=${(a.taxaEmissao * 100).toFixed(0)}%  precisão=${a.precisaoEmitida != null ? (a.precisaoEmitida * 100).toFixed(1) + '%' : '—'}`);
    }
    out.conformal = doms.map(d => C.audit(d));
  } else {
    console.log(`\nConformal: apenas ${con.length} execuções — mínimo 10. Rode --fase conformal.`);
  }

  fs.mkdirSync(DATA, { recursive: true });
  fs.writeFileSync(`${DATA}/covariancia.json`, JSON.stringify(out, null, 2));
  console.log(`\nescrito: ${DATA}/covariancia.json  e  ${DATA}/conformal.json\n`);
}

/* ---------------- main ---------------- */
async function main() {
  const o = args();
  const U = new Uroboros({
    cells: Number(process.env.CELLS) || 16,
    samples: 1,
    alpha: Number(process.env.ALPHA) || 0.10,
    calFile: `${DATA}/conformal.json`
  });

  if (o.relatorio) return relatorio(U);
  if (!o.bench) { console.error('uso: --fase sigma|conformal --bench <arquivo> [--n N] [--dominio D]  |  --relatorio'); process.exit(1); }

  let itens = JSON.parse(fs.readFileSync(o.bench, 'utf8'));
  if (o.dominio) itens = itens.filter(i => (i.dominio || 'geral') === o.dominio);
  if (o.n) itens = itens.slice(0, o.n);

  console.log(`cluster: ${U.n} células · ${U.families.length} famílias · N_eff a priori ${U.info().N_eff}`);
  if (o.fase === 'sigma') await faseSigma(U, itens);
  else if (o.fase === 'conformal') await faseConformal(U, itens);
  else { console.error('fase inválida'); process.exit(1); }
  relatorio(U);
}

if (require.main === module) main().catch(e => { console.error('\n' + e.stack); process.exit(1); });
module.exports = { extrairNumeros, candidatos, julgar, custo };
