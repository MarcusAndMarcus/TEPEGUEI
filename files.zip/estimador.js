'use strict';
/* UROBOROS · URB2 — estimador de Σ
 *
 * PROBLEMA: Σ cheia tem N(N+1)/2 parâmetros livres. Com N=16 são 136.
 * Estimar 136 parâmetros com T=100 questões é ruído puro — a matriz sai
 * mal condicionada, w* = Σ⁻¹1 explode, e a "otimização" piora o cluster.
 *
 * SOLUÇÃO: a estrutura de família é um prior forte e verdadeiro. Ajusta-se
 * um MODELO EM BLOCOS em vez da matriz cheia:
 *
 *     Σ_ij = √(v_i v_j) · ρ_ij ,   ρ_ij = ⎧ 1              i = j
 *                                          ⎨ ρ_in[f]        mesma família f
 *                                          ⎩ ρ_out[f,g]     famílias f≠g
 *
 * Com f famílias: f variâncias + f correlações intra + f(f−1)/2 inter.
 * Para f=8 são 44 parâmetros, não 136 — e cada um é estimado agrupando
 * TODOS os pares daquele bloco, o que multiplica o tamanho amostral efetivo.
 *
 * DIAGNÓSTICO PRINCIPAL: o autovetor dominante de Σ é a direção de erro
 * comum — o viés compartilhado b da teoria. A razão
 *
 *     fracaoComum = λ₁ / tr(Σ)
 *
 * mede que porcentagem da variância de erro do cluster é modo comum, e
 * portanto IRREMOVÍVEL por qualquer média. É o número mais informativo que
 * a calibração produz.
 */

/* ---------- autodecomposição simétrica (Jacobi cíclico) ---------- */
function jacobiEigen(A, maxSweeps = 60, tol = 1e-11) {
  const n = A.length;
  const a = A.map(r => r.slice());
  const V = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));
  for (let sweep = 0; sweep < maxSweeps; sweep++) {
    let off = 0;
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) off += a[i][j] * a[i][j];
    if (Math.sqrt(2 * off) < tol) break;
    for (let p = 0; p < n - 1; p++) {
      for (let q = p + 1; q < n; q++) {
        if (Math.abs(a[p][q]) < 1e-15) continue;
        const theta = (a[q][q] - a[p][p]) / (2 * a[p][q]);
        const t = Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
        const c = 1 / Math.sqrt(t * t + 1), s = t * c;
        for (let k = 0; k < n; k++) { const kp = a[k][p], kq = a[k][q]; a[k][p] = c * kp - s * kq; a[k][q] = s * kp + c * kq; }
        for (let k = 0; k < n; k++) { const pk = a[p][k], qk = a[q][k]; a[p][k] = c * pk - s * qk; a[q][k] = s * pk + c * qk; }
        for (let k = 0; k < n; k++) { const kp = V[k][p], kq = V[k][q]; V[k][p] = c * kp - s * kq; V[k][q] = s * kp + c * kq; }
      }
    }
  }
  const vals = a.map((r, i) => r[i]);
  const ord = vals.map((_, i) => i).sort((x, y) => vals[y] - vals[x]);
  return { values: ord.map(i => vals[i]), vectors: ord.map(i => V.map(r => r[i])) };
}

/** Projeta na cone PSD zerando autovalores negativos e reescala o traço. */
function projectPSD(S, floor = 1e-8) {
  const { values, vectors } = jacobiEigen(S);
  const n = S.length;
  const tr0 = S.reduce((s, r, i) => s + r[i], 0);
  const lam = values.map(v => Math.max(floor, v));
  const R = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let k = 0; k < n; k++)
    for (let i = 0; i < n; i++)
      for (let j = 0; j < n; j++) R[i][j] += lam[k] * vectors[k][i] * vectors[k][j];
  const tr1 = R.reduce((s, r, i) => s + r[i], 0);
  const f = tr1 > 0 ? tr0 / tr1 : 1;
  return R.map(r => r.map(x => x * f));
}

/* ---------- correlação empírica ---------- */
function corrMatrix(E) {
  const T = E.length, N = E[0].length;
  const mu = new Array(N).fill(0);
  for (const r of E) for (let i = 0; i < N; i++) mu[i] += r[i] / T;
  const sd = new Array(N).fill(0);
  for (const r of E) for (let i = 0; i < N; i++) sd[i] += (r[i] - mu[i]) ** 2 / Math.max(1, T - 1);
  for (let i = 0; i < N; i++) sd[i] = Math.sqrt(sd[i]);
  const R = Array.from({ length: N }, () => new Array(N).fill(0));
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      if (sd[i] < 1e-9 || sd[j] < 1e-9) { R[i][j] = i === j ? 1 : 0; continue; }
      let c = 0;
      for (const r of E) c += (r[i] - mu[i]) * (r[j] - mu[j]) / Math.max(1, T - 1);
      R[i][j] = Math.max(-0.99, Math.min(0.99, c / (sd[i] * sd[j])));
    }
  }
  return { R, mu, sd };
}

/**
 * Ajusta o modelo em blocos.
 * @param E     matriz T×N de erro binário
 * @param cells [{id, family, provider, role}]
 * @param opts.minPares   nº mínimo de pares para confiar num bloco
 * @param opts.encolher   peso de encolhimento do bloco para a média global
 */
function structuredCovariance(E, cells, opts = {}) {
  const { minPares = 3, encolher = 0.25 } = opts;
  const T = E.length, N = cells.length;
  if (!T) throw new Error('sem amostras');
  const { R, mu } = corrMatrix(E);

  // variância de Bernoulli por célula, com piso (célula que nunca errou ainda erra)
  const v = mu.map(p => Math.max(1e-3, p * (1 - p)));

  const fams = [...new Set(cells.map(c => c.family))];
  const fidx = new Map(fams.map((f, k) => [f, k]));
  const acc = new Map();  // chave bloco -> {soma, n}
  const key = (a, b) => (a <= b ? `${a}|${b}` : `${b}|${a}`);

  for (let i = 0; i < N; i++)
    for (let j = i + 1; j < N; j++) {
      const k = key(fidx.get(cells[i].family), fidx.get(cells[j].family));
      if (!acc.has(k)) acc.set(k, { s: 0, n: 0 });
      const a = acc.get(k); a.s += R[i][j]; a.n++;
    }

  // Encolhimento HIERÁRQUICO em dois níveis. Encolher tudo para a média
  // global colapsa intra e inter — o erro que a versão ingênua comete.
  // Nível 1: bloco -> média do seu TIPO (intra ou inter)
  // Nível 2: tipo  -> média global (só se o tipo tiver poucos pares)
  // O peso usa n·T, não n: um único par medido em 300 questões é um
  // estimador forte, ainda que seja um par só.
  let gs = 0, gn = 0, is = 0, iN = 0, os = 0, oN = 0;
  for (const [k, { s, n }] of acc) {
    gs += s; gn += n;
    const [a, b] = k.split('|').map(Number);
    if (a === b) { is += s; iN += n; } else { os += s; oN += n; }
  }
  const rhoGlobal = gn ? gs / gn : 0.3;
  const kShrink = minPares / Math.max(1e-6, encolher) * 20;   // ~240 amostras-pares
  const pull = (raw, alvo, nT) => { const w = nT / (nT + kShrink); return w * raw + (1 - w) * alvo; };

  const rhoIntra = iN ? pull(is / iN, rhoGlobal, iN * T) : rhoGlobal;
  const rhoInter = oN ? pull(os / oN, rhoGlobal, oN * T) : rhoGlobal;

  const rho = new Map();
  for (const [k, { s, n }] of acc) {
    const [a, b] = k.split('|').map(Number);
    const alvo = a === b ? rhoIntra : rhoInter;
    rho.set(k, Math.max(-0.5, Math.min(0.98, pull(s / n, alvo, n * T))));
  }

  const Sigma = Array.from({ length: N }, () => new Array(N).fill(0));
  for (let i = 0; i < N; i++)
    for (let j = 0; j < N; j++) {
      if (i === j) { Sigma[i][j] = v[i]; continue; }
      const r = rho.get(key(fidx.get(cells[i].family), fidx.get(cells[j].family))) ?? rhoGlobal;
      Sigma[i][j] = Math.sqrt(v[i] * v[j]) * r;
    }

  const S = projectPSD(Sigma);
  const blocos = [...rho.entries()].map(([k, r]) => {
    const [a, b] = k.split('|').map(Number);
    return { familias: a === b ? [fams[a]] : [fams[a], fams[b]], tipo: a === b ? 'intra' : 'inter', rho: +r.toFixed(4), pares: acc.get(k).n };
  }).sort((x, y) => y.rho - x.rho);

  return {
    Sigma: S, taxaErro: mu.map(x => +x.toFixed(4)),
    rhoGlobal: +rhoGlobal.toFixed(4), rhoIntra: +rhoIntra.toFixed(4), rhoInter: +rhoInter.toFixed(4),
    blocos, familias: fams, T
  };
}

/* ---------- diagnósticos ---------- */
function diagnose(Sigma, w = null) {
  const N = Sigma.length;
  const { values, vectors } = jacobiEigen(Sigma);
  const tr = Sigma.reduce((s, r, i) => s + r[i], 0);
  const wt = w || new Array(N).fill(1 / N);
  let vbar = 0; for (let i = 0; i < N; i++) vbar += Sigma[i][i] / N;
  let q = 0; for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) q += wt[i] * wt[j] * Sigma[i][j];
  const sw = wt.reduce((a, b) => a + b, 0);
  const Neff = q > 0 ? (vbar * sw * sw) / q : N;

  return {
    N, N_eff: +Neff.toFixed(3),
    fracaoComum: +(values[0] / tr).toFixed(4),          // quanto do erro é modo comum
    tetoNeff: +(tr / values[0]).toFixed(3),             // limite superior de N_eff nesta Σ
    condicionamento: +(values[0] / Math.max(1e-12, values[N - 1])).toFixed(1),
    espectro: values.map(x => +x.toFixed(5)),
    modoComum: vectors[0].map(x => +x.toFixed(3))       // carga de cada célula no viés compartilhado
  };
}

/**
 * Correlação tetracórica (aprox. de Digby). φ medido em acerto/erro binário é
 * atenuado quando a taxa de erro é baixa, o que torna ρ incomparável entre
 * domínios fáceis e difíceis. A tetracórica estima a correlação da variável
 * latente contínua e é invariante à taxa base — use SÓ para relatório.
 * A deflação de LLR e o N_eff continuam usando φ, que é a quantidade que
 * de fato aparece em Var((1/N)Σeᵢ).
 */
function tetrachoric(E, i, j) {
  let a = 0, b = 0, c = 0, d = 0;
  for (const r of E) {
    if (r[i] && r[j]) a++; else if (r[i] && !r[j]) b++; else if (!r[i] && r[j]) c++; else d++;
  }
  a += 0.5; b += 0.5; c += 0.5; d += 0.5;                 // correção de Haldane
  const w = Math.pow((a * d) / (b * c), 3 / 4);
  return Math.cos(Math.PI / (1 + w));
}

module.exports = { jacobiEigen, projectPSD, corrMatrix, structuredCovariance, diagnose, tetrachoric };
