'use strict';
/* UROBOROS · URB2 — autoteste offline (sem chaves de API) */

const assert = require('assert');
const V = require('../lib/verifier');
const U = require('../lib/urb2');
const B = require('../lib/bp');
const E = require('../lib/epistemic');
const G = require('../lib/graph');
const { Conformal } = require('../lib/conformal');
const Msk = require('../lib/mascara');

let n = 0, ok = 0;
const t = (nome, fn) => { n++; try { fn(); ok++; console.log(`  ok  ${nome}`); } catch (e) { console.log(`  FALHA ${nome}: ${e.message}`); } };

console.log('\n[Polo V]');
t('aritmética segura', () => assert(Math.abs(V.evalExpr('sqrt(2)*3+ln(e)') - 5.2426406) < 1e-6));
t('sem eval: símbolo inválido rejeitado', () => assert.throws(() => V.evalExpr('process.exit(1)')));
t('detecta 12*7=82', () => assert.strictEqual(V.checkArithmetic('12*7 = 82')[0].ok, false));
t('aceita 2^10=1024', () => assert.strictEqual(V.checkArithmetic('2^10 = 1024')[0].ok, true));
t('dimensional N≠J', () => assert.strictEqual(V.checkUnits([{ grandeza: 'E', valor: 1, unidade: 'N', unidadeEsperada: 'J' }])[0].ok, false));
t('dimensional N·m=J', () => assert.strictEqual(V.checkUnits([{ grandeza: 'W', valor: 1, unidade: 'N m', unidadeEsperada: 'J' }])[0].ok, true));
t('veto propaga', () => assert.strictEqual(V.verify('logo 12*7 = 82').veto, true));

console.log('\n[URB2]');
t('round-trip', () => {
  const o = { type: U.TYPE.CLAIM, cell: 7, hops: 2, claimId: 0xCAFEBABE, originMask: 0b10110n, llr: -3.5, payload: 'σ₈ = 0.811' };
  const d = U.decode(U.encode(o));
  assert.strictEqual(d.claimId, o.claimId); assert.strictEqual(d.originMask, o.originMask);
  assert.strictEqual(d.llr, o.llr); assert.strictEqual(d.payload, o.payload);
});
t('CRC detecta corrupção', () => {
  const b = U.encode({ originMask: 0b1011n, payload: 'xyz' });
  b[b.length - 4] ^= 0x40;                       // último byte do payload
  assert.throws(() => U.decode(b), /CRC/);
});
t('eco recusado no repasse', () => {
  const tel = U.decode(U.encode({ cell: 1, originMask: 0b0011n, payload: 'p' }));
  assert.strictEqual(U.forward(tel, 0b0001n), null);
});
t('máscara funde no repasse', () => {
  const tel = U.decode(U.encode({ cell: 1, originMask: 0b0011n, payload: 'p' }));
  assert.strictEqual(U.forward(tel, 0b0100n).originMask, 0b0111n);
});

console.log('\n[propagação de crença]');
t('deflação: 4 da mesma família < 4 famílias distintas', () => {
  const mesma = [0, 1, 2, 3].map(i => ({ cell: i, family: 'anthropic', bit: Msk.bitDe(i), llr: 2 }));
  const difs = ['a', 'b', 'c', 'd'].map((f, i) => ({ cell: i, family: f, bit: Msk.bitDe(i), llr: 2 }));
  const A = B.aggregate(mesma, { rhoDefault: 0.85 }).llr;
  const D = B.aggregate(difs, { rhoDefault: 0.85 }).llr;
  assert(A < D, `${A} deveria ser < ${D}`);
  assert(A < 3, 'família única não pode chegar perto do teto');
});
t('veto do Polo V domina consenso unânime', () => {
  const evs = ['a', 'b', 'c', 'd'].map((f, i) => ({ cell: i, family: f, bit: Msk.bitDe(i), llr: 6 }));
  evs.push({ cell: -1, family: '__verifier', bit: Msk.VERIFICADOR, llr: -B.L_MAX, kind: 'verifier' });
  assert.strictEqual(B.aggregate(evs, {}).llr, -B.L_MAX);
});
t('extrínseco exclui a própria origem', () => {
  const evs = ['a', 'b', 'c'].map((f, i) => ({ cell: i, family: f, bit: Msk.bitDe(i), llr: 2 }));
  const r = B.extrinsic(evs, 0b001n, {});
  assert.strictEqual(r.nOrigins, 2);
  assert.strictEqual(r.mask & 0b001n, 0n);
});
t('lavagem de alucinação bloqueada', () => {
  // célula 0 inventa; o eco volta 3 vezes com a mesma máscara de origem
  const eco = [0, 1, 2, 3].map(() => ({ cell: 0, family: 'a', bit: 1n, llr: 3 }));
  const r = B.aggregate(eco, { rhoDefault: 0.85 });
  assert.strictEqual(r.nOrigins, 1, 'eco não pode virar origem nova');
});
t('IDs colidem sob reformulação', () => {
  assert.strictEqual(B.ClaimGraph.id('H0 é 67.4 km/s/Mpc'), B.ClaimGraph.id('h0 e 67.4 km/s/mpc'));
});
t('grafo converge', () => {
  const g = new B.ClaimGraph({ rhoDefault: 0.6, damping: 0.4 });
  g.add('x', { cell: 0, family: 'a', bit: 1n, llr: 2 });
  g.add('x', { cell: 1, family: 'b', bit: 2n, llr: 2 });
  const passos = g.run(60, 1e-4);
  assert(passos < 60, 'deveria convergir antes do teto');
  assert(Math.abs([...g.claims.values()][0].llr - 4) < 1e-3, 'ponto fixo errado');
});

console.log('\n[epistêmico]');
t('trava numérica separa tensão de Hubble', () => {
  const cl = E.clusterByShingles([
    'H0 vale cerca de 67.4 km/s/Mpc', 'H0 é aproximadamente 67.4 km/s/Mpc',
    'H0 = 73.0 km/s/Mpc', 'O valor de H0 é próximo de 73.0 km/s/Mpc'
  ]);
  assert.strictEqual(cl.length, 2);
});
t('entropia zero em consenso total', () => {
  assert.strictEqual(E.semanticEntropy([[0, 1, 2, 3]]).H, 0);
});
t('N_eff colapsa com família única', () => {
  const homo = Array.from({ length: 10 }, (_, i) => ({ id: i, family: 'anthropic' }));
  const hetero = Array.from({ length: 10 }, (_, i) => ({ id: i, family: 'f' + i }));
  const a = E.effectiveN(E.priorCovariance(homo));
  const b = E.effectiveN(E.priorCovariance(hetero));
  assert(a < 2 && b > a * 2, `homogêneo=${a.toFixed(2)} heterogêneo=${b.toFixed(2)}`);
});
t('GLS zera célula redundante', () => {
  const cells = [{ family: 'a' }, { family: 'a' }, { family: 'a' }, { family: 'b' }].map((c, i) => ({ id: i, ...c }));
  const w = E.glsWeights(E.priorCovariance(cells));
  assert(w[3] > w[0], 'a família minoritária deve pesar mais');
});
t('inversa correta', () => {
  const I = E.inverse([[4, 1], [1, 3]], 0);
  assert(Math.abs(I[0][0] - 3 / 11) < 1e-9 && Math.abs(I[0][1] + 1 / 11) < 1e-9);
});

console.log('\n[topologia]');
t('C10(1,3) é bipartido e NÃO converge', () => assert.strictEqual(G.mixingTime(10, [1, 3]), Infinity));
t('C10(1,2,3) converge em ~6', () => assert.strictEqual(G.mixingTime(10, [1, 2, 3]), 6));
t('gossip preguiçoso conserta bipartição', () => assert(G.mixingTime(10, [1, 3], 1e-2, 0.5) < Infinity));
t('matriz de mistura é estocástica', () => {
  const W = G.mixingMatrix(10, [1, 2, 3]);
  for (const r of W) assert(Math.abs(r.reduce((a, b) => a + b, 0) - 1) < 1e-9);
});

console.log('\n[conformal]');
t('cobertura empírica ≈ 1-α', () => {
  const C = new Conformal({ alpha: 0.10, minCal: 20 });
  let s = 7; const rnd = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let i = 0; i < 500; i++) C.observe('d', 0.1 + 0.2 * rnd(), true);
  const a = C.audit('d');
  assert(Math.abs(a.coberturaCorretos - 0.9) < 0.03, `cobertura=${a.coberturaCorretos}`);
});
t('banda de ressalva é mais permissiva que a de emissão', () => {
  const C = new Conformal({ alpha: 0.10, minCal: 20 });
  let s = 9; const rnd = () => ((s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let i = 0; i < 400; i++) C.observe('d', 0.1 + 0.3 * rnd(), true);
  const d = C.decide('d', 0.2);
  assert(d.qRessalvar > d.qEmitir, `${d.qRessalvar} deveria ser > ${d.qEmitir}`);
});
t('Mondrian cai para o pool global se faltar amostra', () => {
  const C = new Conformal({ alpha: 0.1, minCal: 50 });
  for (let i = 0; i < 60; i++) C.observe('fisica', 0.2, true);
  assert.strictEqual(C.qhat('juridico').scope, 'global');
});


console.log('\n[estimador]');
const EST = require('../lib/estimador');
t('Jacobi: autovalores e residuo', () => {
  const A = [[4, 1, 0], [1, 3, 1], [0, 1, 2]];
  const r = EST.jacobiEigen(A);
  assert(Math.abs(r.values.reduce((a, b) => a + b, 0) - 9) < 1e-9, 'traco');
  const v = r.vectors[0], l = r.values[0];
  const Av = A.map(row => row.reduce((s, x, j) => s + x * v[j], 0));
  assert(Math.hypot(...Av.map((x, i) => x - l * v[i])) < 1e-9, 'Av = lv');
});
t('projecao PSD elimina autovalor negativo', () => {
  const S = EST.projectPSD([[1, 0.99, 0.99], [0.99, 1, -0.99], [0.99, -0.99, 1]]);
  assert(Math.min(...EST.jacobiEigen(S).values) >= -1e-9);
});
t('Sigma estruturada separa intra de inter', () => {
  let s = 7; const u = () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
  let sp = null; const g = () => { if (sp !== null) { const v = sp; sp = null; return v; } let a, b, r; do { a = 2 * u() - 1; b = 2 * u() - 1; r = a * a + b * b; } while (r >= 1 || r === 0); const f = Math.sqrt(-2 * Math.log(r) / r); sp = b * f; return a * f; };
  const fams = ['A', 'A', 'B', 'B', 'C', 'C'];
  const cells = fams.map((f, i) => ({ id: i, family: f, provider: 'p' + f, role: 'solver' }));
  const E2 = [];
  for (let k = 0; k < 400; k++) { const gg = g(); const gf = { A: g(), B: g(), C: g() };
    E2.push(cells.map(c => (Math.sqrt(0.25) * gg + Math.sqrt(0.55) * gf[c.family] + Math.sqrt(0.2) * g()) > 0.52 ? 1 : 0)); }
  const fit = EST.structuredCovariance(E2, cells);
  assert(fit.rhoIntra > fit.rhoInter + 0.15, `intra=${fit.rhoIntra} inter=${fit.rhoInter}`);
  assert(EST.diagnose(fit.Sigma).N_eff < cells.length, 'N_eff deve ser menor que N');
});
t('fracaoComum entre 0 e 1 e teto coerente', () => {
  const cells = Array.from({ length: 6 }, (_, i) => ({ id: i, family: 'f' + (i % 3) }));
  const S = E.priorCovariance(cells);
  const d = EST.diagnose(S);
  assert(d.fracaoComum > 0 && d.fracaoComum <= 1);
  assert(d.N_eff <= d.tetoNeff + 1e-6, `N_eff=${d.N_eff} teto=${d.tetoNeff}`);
});

console.log('\n[bench sintetico]');
const GB = require('./gerar-bench');
const { extrairNumeros, candidatos } = require('./calibrar');
t('gabaritos sao reproduziveis com a mesma semente', () => {
  assert.deepStrictEqual(GB.gerar(20, 7), GB.gerar(20, 7));
});
t('parametros variam entre itens (memorizacao inutil)', () => {
  const its = GB.gerar(200, 3).filter(i => i.tipo === 'idade');
  assert(new Set(its.map(i => i.num)).size > its.length * 0.8, 'gabaritos repetidos demais');
});
t('todo item tem criterio de julgamento', () => {
  for (const i of GB.gerar(120, 11)) assert(i.exato || (i.num != null && i.tol != null), `${i.id} sem gabarito verificavel`);
});
t('extracao ignora indice de variavel', () => {
  assert.deepStrictEqual(extrairNumeros('t0 = 14.12 Gyr'), [14.12]);
});
t('filtro anti-eco descarta parametros do enunciado', () => {
  assert.deepStrictEqual(candidatos('H0 vale 67.4 e Om vale 0.315', 'Dado H0 = 67.4 e Om = 0.315, calcule.'), []);
});


console.log('\n[ancora]');
const { Ancora, converter, llrGaussiano } = require('../lib/ancora');
const ANC = new Ancora();
t('LLR e monotono e cruza zero perto de 2 sigma', () => {
  assert(llrGaussiano(0) > llrGaussiano(1) && llrGaussiano(1) > llrGaussiano(3));
  assert(llrGaussiano(2) > 0 && llrGaussiano(2.2) < 0.1);
});
t('converte unidade antes de comparar', () => {
  assert.strictEqual(converter(13797, 'Myr', 'Gyr'), 13.797);
  assert.strictEqual(converter(5, 'K', 'Gyr'), null);
});
t('6000 anos para idade do universo e vetado', () => {
  const r = ANC.local('A idade do universo e 6000 anos');
  assert(r && r.veto, 'deveria vetar apos converter para Gyr');
});
t('13797 Myr e aceito (mesma grandeza, outra unidade)', () => {
  const r = ANC.local('A idade do universo e 13797 Myr');
  assert(r && !r.veto && r.llr > 1.5, JSON.stringify(r));
});
t('tensao de Hubble: nem afirma forte nem veta', () => {
  const a = ANC.local('H0 = 67.4 km/s/Mpc'), b = ANC.local('H0 = 73.0 km/s/Mpc');
  assert(a.tensao && b.tensao, 'deve marcar tensao');
  assert(!a.veto && !b.veto, 'nenhum dos dois pode ser vetado');
  assert(a.llr <= 0.85 && b.llr <= 0.85, 'LLR atenuado em disputa');
});
t('valor errado para TODAS as fontes nao se salva pela tensao', () => {
  const r = ANC.local('H0 = 55.0 km/s/Mpc');
  assert(r.veto || r.llr < -5, JSON.stringify(r));
});
t('entrada nao verificada abstem', () => {
  assert.strictEqual(ANC.local('O parametro w0 vale -0.9'), null);
});
t('alias dentro de outra palavra nao dispara', () => {
  const m = ANC.tabela.extrair('G = 6.6743e-11 m^3 kg^-1 s^-2');
  assert.strictEqual(m.length, 1, JSON.stringify(m));
  assert(Math.abs(m[0].valor - 6.6743e-11) < 1e-20);
});
t('dois aliases para o mesmo numero contam uma vez so', () => {
  const m = ANC.tabela.extrair('A constante de Hubble H0 vale 67.4 km/s/Mpc');
  assert.strictEqual(m.length, 1, JSON.stringify(m));
});
t('alias numerico nao envenena o proprio valor', () => {
  const r = ANC.local('inverso da constante de estrutura fina = 137.035999084');
  assert(r && r.llr > 1.5 && !r.veto, JSON.stringify(r));
});
t('toda entrada verificada se reconhece a partir do proprio valor', () => {
  for (const k of Object.keys(ANC.tabela.grandezas)) {
    for (const e of ANC.tabela.verificadas(k)) {
      const alias = (ANC.tabela.aliases[k] || [k])[0];
      const frase = `${alias} = ${e.valor} ${e.unidade === '1' ? '' : e.unidade}`.trim();
      const r = ANC.local(frase);
      assert(r && r.llr > 0, `${frase} -> ${r ? r.llr : 'nada'}`);
    }
  }
});
t('ancora entra com bit fora do espaco das celulas', async () => {
  const evs = await ANC.evidencia('A idade do universo e 13.797 Gyr');
  assert(evs.length === 1 && evs[0].bit === Msk.ANCORA);
  assert(evs[0].family.startsWith('__ancora'));
});


console.log('\n[rag metrico]');
const RAG = require('../lib/rag');
function corpus(seed) {
  let z = seed; const uu = () => ((z = (Math.imul(z, 1664525) + 1013904223) >>> 0) / 4294967296);
  let sq = null; const gg = () => { if (sq !== null) { const v = sq; sq = null; return v; } let a, b, r; do { a = 2 * uu() - 1; b = 2 * uu() - 1; r = a * a + b * b; } while (r >= 1 || r === 0); const f = Math.sqrt(-2 * Math.log(r) / r); sq = b * f; return a * f; };
  const vv = d => Array.from({ length: d }, gg), D = 48;
  const cA = RAG.normalizar(vv(D)), cB = RAG.normalizar(vv(D));
  const nu = (c, n, sd) => Array.from({ length: n }, () => RAG.normalizar(c.map(x => x + sd * gg())));
  const A = nu(cA, 60, 0.25), B = nu(cB, 60, 0.25);
  const P = Array.from({ length: 20 }, (_, i) => { const t = (i + 1) / 21; return RAG.normalizar(cA.map((x, k) => (1 - t) * x + t * cB[k] + 0.1 * gg())); });
  return { docs: [...A, ...B, ...P], rot: [...A.map(() => 'A'), ...B.map(() => 'B'), ...P.map(() => 'P')], q: RAG.normalizar(cA.map(x => x + 0.15 * gg())) };
}
t('metrica do artigo == cosseno com embeddings normalizados', () => {
  const { docs, q } = corpus(11);
  const rk = a => a.map((v, i) => i).sort((x, y) => a[x] - a[y]);
  const cos = docs.map(x => 1 - x.reduce((s, v, i) => s + v * q[i], 0));
  for (const lam of [0.01, 1, 100]) {
    const r = rk(RAG.tensorRAG5D_paper(docs, q, lam));
    assert.deepStrictEqual(r.slice(0, 15), rk(cos).slice(0, 15), `lambda=${lam} deveria empatar com cosseno`);
  }
});
t('alpha=0 reproduz o ranking do artigo', () => {
  const { docs, q } = corpus(12);
  const ix = new RAG.IndiceMetrico(docs, null, { alpha: 0 });
  const d = ix.distancias(q), rk = a => a.map((v, i) => i).sort((x, y) => a[x] - a[y]);
  assert.deepStrictEqual(rk(d).slice(0, 10), rk(RAG.tensorRAG5D_paper(docs, q, 0.01)).slice(0, 10));
});
t('alpha aumenta o alcance entre dominios monotonicamente', () => {
  const { docs, rot, q } = corpus(13);
  const pos = al => { const ix = new RAG.IndiceMetrico(docs, null, { alpha: al }); const d = ix.distancias(q);
    const o = d.map((v, i) => i).sort((a, b) => d[a] - d[b]);
    for (let k = 0; k < o.length; k++) if (rot[o[k]] === 'B') return k + 1; return o.length; };
  const p0 = pos(0), p1 = pos(1);
  assert(p1 < p0, `alpha=1 deveria alcancar B antes: ${p1} vs ${p0}`);
});
t('pre-fatoracao == forma quadratica direta', () => {
  const { docs, q } = corpus(14);
  const ix = new RAG.IndiceMetrico(docs, null, { alpha: 0.5, normalizar: false });
  const { S } = RAG.covariancia(docs);
  const { R } = RAG.fatorMetrica(S, 0.5);
  const M = Array.from({ length: docs[0].length }, (_, i) => Array.from({ length: docs[0].length }, (_, j) =>
    R.reduce((s, row) => s + row[i] * row[j], 0)));
  const d = ix.distancias(q);
  const dl = docs[0].map((v, i) => v - q[i]);
  let quad = 0; for (let i = 0; i < dl.length; i++) for (let j = 0; j < dl.length; j++) quad += dl[i] * M[i][j] * dl[j];
  assert(Math.abs(quad - d[0]) < 1e-8, `${quad} vs ${d[0]}`);
});
t('pontes sobrevivem quando ha orcamento de expansao', () => {
  const { docs, q } = corpus(15);
  const base = new RAG.IndiceMetrico(docs, null, { alpha: 0.35 });
  const d = base.distancias(q), o = d.map((v, i) => i).sort((a, b) => d[a] - d[b]);
  const pontes = {}; pontes[o[0]] = o.slice(-3);
  const ix = new RAG.IndiceMetrico(docs, null, { alpha: 0.35, pontes });
  assert.strictEqual(ix.recuperar(q, 3).length, 3, 'sem orcamento, nada de ponte');
  const r = ix.recuperar(q, 3, { expandir: 3 });
  assert.strictEqual(r.length, 6);
  assert(r.filter(x => x.viaPonte !== null).length === 3, 'as 3 pontes precisam aparecer');
});
t('geodesica difere da distancia direta', () => {
  const { docs, q } = corpus(16);
  const ix = new RAG.IndiceMetrico(docs, null, { alpha: 0.35 });
  const a = ix.recuperar(q, 10, { modo: 'metrica' }).map(x => x.indice);
  const b = ix.recuperar(q, 10, { modo: 'geodesica' }).map(x => x.indice);
  assert(JSON.stringify(a) !== JSON.stringify(b), 'geodesica deveria reordenar');
});


console.log('\n[escala · mais de 31 celulas]');
const Prov = require('../lib/providers');
t('bit de celula 32+ nao colide (o bug de 1<<i)', () => {
  assert.strictEqual(1 << 32, 1, 'premissa: Number envolve em 32 bits');
  const b = [0, 31, 32, 33, 255, 1000].map(Msk.bitDe);
  assert.strictEqual(new Set(b.map(String)).size, b.length, 'BigInt nao pode colidir');
});
t('popcount correto acima de 32 bits', () => {
  let m = Msk.ZERO;
  for (const i of [0, 32, 33, 200, 255]) m |= Msk.bitDe(i);
  assert.strictEqual(Msk.origens(m), 5);
  assert.deepStrictEqual(Msk.indices(m), [0, 32, 33, 200, 255]);
});
t('slots reservados nao contam como celula', () => {
  const m = Msk.bitDe(5) | Msk.VERIFICADOR | Msk.ANCORA | Msk.ANCORA_REDE;
  assert.strictEqual(Msk.origens(m), 1);
});
t('telegrama carrega mascara de 256 celulas', () => {
  let m = Msk.ZERO;
  for (let i = 0; i < 256; i += 3) m |= Msk.bitDe(i);
  const d = U.decode(U.encode({ cell: 200, originMask: m, payload: 'p' }));
  assert.strictEqual(d.originMask, m);
  assert.strictEqual(Msk.origens(d.originMask), 86);
});
t('extrinseco funciona para celula 33', () => {
  const evs = [0, 33, 70].map((i, k) => ({ cell: i, family: 'f' + k, bit: Msk.bitDe(i), llr: 2 }));
  const r = B.extrinsic(evs, Msk.bitDe(33), {});
  assert.strictEqual(r.nOrigins, 2);
  assert.strictEqual(r.mask & Msk.bitDe(33), 0n);
});
t('256 celulas: bits todos distintos', () => {
  const env = { ANTHROPIC_API_KEY: 'x', GEMINI_API_KEY: 'y' };
  const c = Prov.buildCells(256, env);
  assert.strictEqual(new Set(c.map(x => x.bit.toString())).size, 256);
});
t('composicao acusa replicas exatas', () => {
  const env = { ANTHROPIC_API_KEY: 'x', GEMINI_API_KEY: 'y' };
  const comp = Prov.composicao(Prov.buildCells(256, env));
  assert(comp.saturado, 'com 2 familias, 256 celulas tem que saturar');
  assert(comp.replicasExatas > 100, `replicas=${comp.replicasExatas}`);
});
t('semaforo limita concorrencia', async () => {
  const sem = new Prov.Semaforo(4);
  let vivos = 0, pico = 0;
  await Promise.all(Array.from({ length: 40 }, () => sem.com(async () => {
    vivos++; pico = Math.max(pico, vivos);
    await new Promise(r => setTimeout(r, 2));
    vivos--;
  })));
  assert(pico <= 4, `pico=${pico}`);
});


console.log('\n[pares cruzados]');
const Pv = require('../lib/providers');
const ENVP = { ANTHROPIC_API_KEY: 'x', GEMINI_API_KEY: 'y' };
t('todo par mistura familias diferentes', () => {
  const c = Pv.buildPairs(8, ENVP);
  assert.strictEqual(c.length, 16);
  for (let k = 0; k < 8; k++) {
    const d = c.filter(x => x.par === k);
    assert.strictEqual(d.length, 2, `par ${k}`);
    assert.notStrictEqual(d[0].family, d[1].family, `par ${k} nao e cruzado`);
  }
});
t('papeis do par sao complementares', () => {
  const c = Pv.buildPairs(8, ENVP);
  for (let k = 0; k < 8; k++) {
    const [a, b] = c.filter(x => x.par === k);
    assert.notStrictEqual(a.role, b.role, `par ${k} repete papel`);
    assert.strictEqual(a.lado, 'propositor');
    assert.strictEqual(b.lado, 'refutador');
  }
});
t('parceiros apontam um para o outro', () => {
  const c = Pv.buildPairs(6, ENVP);
  for (const x of c) {
    assert.strictEqual(c[x.parceiro].parceiro, x.id);
    assert.strictEqual(c[x.parceiro].par, x.par);
  }
});
t('modo pares exige duas familias', () => {
  assert.throws(() => Pv.buildPairs(4, { ANTHROPIC_API_KEY: 'x' }), /2 famílias/);
});
t('par cruzado vale mais que duas celulas da mesma familia', () => {
  const mesma = [0, 1].map(i => ({ cell: i, family: 'anthropic', bit: Msk.bitDe(i), llr: 1.4 }));
  const cruz = [{ cell: 0, family: 'anthropic', bit: Msk.bitDe(0), llr: 1.4 },
                { cell: 1, family: 'google', bit: Msk.bitDe(1), llr: 1.4 }];
  const a = B.aggregate(mesma, { rhoDefault: 0.85 }).llr;
  const c = B.aggregate(cruz, { rhoDefault: 0.85 }).llr;
  assert(c > a * 1.3, `cruzado=${c.toFixed(3)} mesma=${a.toFixed(3)}`);
});
t('pesos GLS nao encolhem a evidencia pelo tamanho do cluster', () => {
  // regressao: pesos somando 1 dividiam todo LLR por N
  const evs = n => Array.from({ length: n }, (_, i) => ({ cell: i, family: 'f' + i, bit: Msk.bitDe(i), llr: 2 }));
  const wRel = n => new Array(n).fill(1);
  const l8 = B.aggregate(evs(8), { w: wRel(8) }).llr;
  const l2 = B.aggregate(evs(2), { w: wRel(2) }).llr;
  assert(l8 > l2, `8 celulas (${l8.toFixed(2)}) tem que valer mais que 2 (${l2.toFixed(2)})`);
});


console.log('\n[aprendizado e ondas]');
t('parar cedo e MAIS estrito que emitir (direcao do alfa)', () => {
  const C = new Conformal({ alpha: 0.10, minCal: 20 });
  let z = 5; const rr = () => ((z = (Math.imul(z, 1664525) + 1013904223) >>> 0) / 4294967296);
  for (let i = 0; i < 400; i++) C.observe('d', 0.1 + 0.3 * rr(), true);
  const emitir = C.qhat('d', 0.10).q, parar = C.qhat('d', 0.40).q;
  assert(parar < emitir, `parar=${parar.toFixed(4)} tem que ser < emitir=${emitir.toFixed(4)}`);
});
t('confiabilidade penaliza celula que so erra', () => {
  const R = new E.Reliability();
  for (let i = 0; i < 12; i++) R.update(0, 'd', false);
  for (let i = 0; i < 12; i++) R.update(1, 'd', true);
  assert(R.llrWeight(0, 'd') < 0, 'quem so erra tem LLR de peso negativo');
  assert(R.llrWeight(1, 'd') > 0);
  const r0 = R.get(0, 'd');
  assert(r0.a / (r0.a + r0.b) < 0.3, JSON.stringify(r0));
});
t('cobertura da ancora: 100% no dominio dela, 0% fora', () => {
  const bench = require('../bench/sintetico.json');
  const A = new Ancora();
  const cosmo = bench.filter(i => i.dominio === 'cosmologia');
  const outros = bench.filter(i => i.dominio !== 'cosmologia');
  const anc = l => l.filter(i => A.local(i.a) || A.local(i.q + ' ' + i.a)).length;
  assert.strictEqual(anc(cosmo), cosmo.length, 'ancora tem que cobrir todo item cosmologico');
  assert.strictEqual(anc(outros), 0, 'e nao deve opinar fora do escopo dela');
});
t('todo papel tem prompt de sistema', () => {
  const orq = require('fs').readFileSync(require('path').join(__dirname, '..', 'orchestrator.js'), 'utf8');
  for (const r of Pv.ROLES) assert(new RegExp(`\\b${r}\\s*:`).test(orq), `papel ${r} sem ROLE_SYS`);
});


console.log('\n[nucleo e pool]');
const ENV216 = { ANTHROPIC_API_KEY: 'x', GEMINI_API_KEY: 'y' };
t('cluster grande divide em nucleo + pool', () => {
  const c = Pv.buildPairs(108, ENV216);
  assert.strictEqual(c.length, 216);
  const nucleo = c.slice(0, 32), pool = c.slice(32);
  assert.strictEqual(pool.length, 184);
  assert.strictEqual(new Set(nucleo.map(x => x.family)).size, 2, 'nucleo cobre as duas familias');
});
t('pool tem as duas familias para verificacao cruzada', () => {
  const c = Pv.buildPairs(108, ENV216).slice(32);
  const fams = new Set(c.map(x => x.family));
  assert.strictEqual(fams.size, 2, 'sem as duas familias nao ha verificacao cruzada');
});
t('216 celulas: bits distintos e mascara serializa', () => {
  const c = Pv.buildPairs(108, ENV216);
  assert.strictEqual(new Set(c.map(x => x.bit.toString())).size, 216);
  let m = Msk.ZERO;
  for (const x of c) m |= x.bit;
  assert.strictEqual(Msk.origens(m), 216);
  const d = U.decode(U.encode({ originMask: m, payload: 'p' }));
  assert.strictEqual(d.originMask, m);
});
t('saturacao: 216 celulas com 2 familias sao quase todas replicas', () => {
  const comp = Pv.composicao(Pv.buildPairs(108, ENV216));
  assert(comp.replicasExatas > 100, `replicas=${comp.replicasExatas}`);
  assert.strictEqual(comp.paresCruzados, 108);
});


console.log('\n[par como transistor]');
const Tr = require('../lib/transistor');
t('corte: refutacao forte zera o ganho', () => {
  const r = Tr.par(6, [{ veredito: 'refuto', forca: 0.95 }]);
  assert(r.ganho < 0.01, `ganho=${r.ganho}`);
  assert(!r.conduz && r.llr < 0, JSON.stringify(r));
});
t('propositor muito confiante nao sobrevive ao corte', () => {
  const r = Tr.par(12, [{ veredito: 'refuto', forca: 1 }]);
  assert(r.llr < 0, `L=${r.llr} — corte precisa vencer confianca maxima`);
});
t('sem base, sem corrente: refutador sozinho nao cria crenca', () => {
  assert.strictEqual(Tr.par(0, [{ veredito: 'sustento', forca: 1 }]).llr, 0);
  assert(Tr.par(-1, [{ veredito: 'sustento', forca: 1 }]).llr < 0);
});
t('regiao ativa amplifica monotonicamente', () => {
  const g = [0, 0.3, 0.6, 1].map(s => Tr.par(2, [{ veredito: 'sustento', forca: s }]).ganho);
  for (let i = 1; i < g.length; i++) assert(g[i] > g[i - 1], JSON.stringify(g));
  assert(g[0] === 1, 'forca 0 e transparente');
});
t('saturacao limita a saida', () => {
  const a = Tr.par(8, [{ veredito: 'sustento', forca: 1 }]);
  const b = Tr.par(12, [{ veredito: 'sustento', forca: 1 }]);
  assert.strictEqual(a.llr, b.llr, 'acima da saturacao a saida nao cresce');
  assert.strictEqual(a.regiao, 'saturacao');
});
t('nao_sei e transparente', () => {
  const r = Tr.par(2.5, [{ veredito: 'nao_sei', forca: 0.9 }]);
  assert.strictEqual(r.ganho, 1);
  assert(Math.abs(r.llr - 2.5) < 1e-9);
});
t('cascata: ganhos multiplicam, pull-downs somam', () => {
  const dois = Tr.par(2, [{ veredito: 'refuto', forca: 0.8 }, { veredito: 'refuto', forca: 0.8 }]);
  const um = Tr.par(2, [{ veredito: 'refuto', forca: 0.8 }]);
  assert(dois.llr < um.llr, 'dois refutadores derrubam mais que um');
  assert(dois.ganho < um.ganho);
});
t('serie derruba com um corte; paralelo sobrevive', () => {
  const bons = [Tr.par(2, [{ veredito: 'sustento', forca: 0.7 }]), Tr.par(2, [{ veredito: 'nao_sei' }])];
  const comCorte = [...bons, Tr.par(2, [{ veredito: 'refuto', forca: 0.95 }])];
  assert(Tr.serie(bons).conduz && Tr.paralelo(bons).conduz);
  assert(!Tr.serie(comCorte).conduz, 'serie tem que abrir');
  assert(Tr.paralelo(comCorte).conduz, 'paralelo tem que sobreviver');
  assert(Tr.serie(comCorte).llr < Tr.paralelo(comCorte).llr);
});

console.log(`\n${ok}/${n} testes passaram\n`);
process.exit(ok === n ? 0 : 1);
