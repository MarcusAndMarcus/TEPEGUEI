'use strict';
/* UROBOROS · URB2 — camada epistêmica
 *
 * Três instrumentos, do mais barato ao mais caro:
 *
 *  1. ENTROPIA SEMÂNTICA (Farquhar et al., Nature 2024)
 *     Entropia sobre CLASSES DE SIGNIFICADO, não sobre tokens. Duas respostas
 *     "Paris" e "A capital é Paris" são o mesmo evento. Clusteriza por
 *     implicação bidirecional (NLI) e mede
 *         H = -Σ_c p_c ln p_c,        H̃ = H / ln N ∈ [0,1]
 *     H̃ alto = o modelo não sabe (incerteza epistêmica), sinal primário de
 *     alucinação confabulatória.
 *
 *  2. COVARIÂNCIA DE ERRO Σ e N_eff
 *     Erros de LLMs NÃO são independentes: corpora de pré-treino se
 *     sobrepõem. Para pesos w,
 *         N_eff = (Σᵢwᵢ)² / (wᵀ Σ w)
 *     Com N células e correlação média ρ:  N_eff = N / (1 + (N-1)ρ).
 *     10 células de 2 famílias com ρ≈0.6 → N_eff ≈ 1.6. Dez vozes valendo
 *     uma e meia. É por isso que adicionar FAMÍLIAS vale muito mais que
 *     adicionar células.
 *
 *  3. PESOS ÓTIMOS (GLS / mínima variância)
 *         w* = Σ⁻¹1 / (1ᵀΣ⁻¹1),     Var* = 1 / (1ᵀΣ⁻¹1)
 *     Idêntico ao portfólio de variância mínima de Markowitz. Modelos
 *     redundantes recebem peso ~0 automaticamente; modelos com erro
 *     ANTI-correlacionado podem receber peso negativo (e devem).
 */

const { call, parseJSON } = require('./providers');

/* ================= 1. entropia semântica ================= */

const NLI_SYS =
`Você é um verificador de equivalência semântica. Recebe uma PERGUNTA e uma lista de RESPOSTAS numeradas.
Agrupe as respostas em classes de equivalência: duas respostas ficam na mesma classe se, no contexto da pergunta,
cada uma IMPLICA a outra (implicação bidirecional). Diferença de redação, ordem ou verbosidade não separa classes.
Diferença de valor numérico, de entidade, de sinal ou de conclusão SEPARA classes.
Responda APENAS JSON: {"clusters":[[0,2],[1],[3,4]]}. Todo índice deve aparecer exatamente uma vez.`;

async function clusterByEntailment(question, answers, judge = { provider: 'groq' }) {
  if (answers.length <= 1) return [[0]].slice(0, answers.length);
  const list = answers.map((a, i) => `[${i}] ${String(a).slice(0, 900)}`).join('\n');
  try {
    const r = await call(judge.provider, {
      system: NLI_SYS, json: true, temperature: 0, maxTokens: 700,
      messages: [{ role: 'user', content: `PERGUNTA:\n${question}\n\nRESPOSTAS:\n${list}` }]
    });
    const p = parseJSON(r.text);
    const cl = p?.clusters;
    if (Array.isArray(cl) && cl.flat().length === answers.length) return cl;
  } catch { /* cai no fallback */ }
  return clusterByShingles(answers);
}

/**
 * Fallback determinístico (sem API). Duas travas:
 *  (a) ASSINATURA NUMÉRICA — se duas respostas carregam números
 *      significativos conflitantes, ficam em clusters distintos por decreto.
 *      67.4 e 73.0 nunca colapsam, mesmo com redação quase idêntica.
 *  (b) Jaccard sobre 2-shingles + união-busca para o resto.
 */
function clusterByShingles(answers, thr = 0.30, relTol = 0.02) {
  const sh = answers.map(a => shingles(norm(a), 2));
  const nums = answers.map(numericSignature);
  const parent = answers.map((_, i) => i);
  const find = x => (parent[x] === x ? x : (parent[x] = find(parent[x])));

  for (let i = 0; i < answers.length; i++) {
    for (let j = i + 1; j < answers.length; j++) {
      const cmp = numericCompat(nums[i], nums[j], relTol);
      if (cmp === 'conflito') continue;                    // (a) trava dura
      const sim = jaccard(sh[i], sh[j]);
      if (cmp === 'igual' || sim >= thr) parent[find(i)] = find(j);
    }
  }
  const g = new Map();
  for (let i = 0; i < answers.length; i++) { const r = find(i); if (!g.has(r)) g.set(r, []); g.get(r).push(i); }
  return [...g.values()];
}

function numericSignature(text) {
  const out = [];
  const re = /-?\d+(?:[.,]\d+)?(?:\s*[eE]\s*[+-]?\d+)?/g;
  let m;
  while ((m = re.exec(String(text)))) {
    const v = parseFloat(m[0].replace(',', '.').replace(/\s/g, ''));
    if (Number.isFinite(v) && Math.abs(v) > 1e-12) out.push(v);
  }
  return out;
}

/** 'igual' | 'conflito' | 'neutro' */
function numericCompat(a, b, relTol) {
  if (!a.length || !b.length) return 'neutro';
  const near = (x, y) => Math.abs(x - y) <= relTol * Math.max(Math.abs(x), Math.abs(y));
  const matched = a.filter(x => b.some(y => near(x, y))).length;
  if (matched === 0) return 'conflito';
  if (matched >= Math.min(a.length, b.length)) return 'igual';
  return 'neutro';
}

const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s.+\-]/g, ' ').replace(/\s+/g, ' ').trim();
function shingles(s, k) { const w = s.split(' '); const set = new Set(); for (let i = 0; i + k <= w.length; i++) set.add(w.slice(i, i + k).join(' ')); return set.size ? set : new Set(w); }
function jaccard(a, b) { let inter = 0; for (const x of a) if (b.has(x)) inter++; const u = a.size + b.size - inter; return u ? inter / u : 0; }

/**
 * Entropia semântica com pesos por célula (peso = independência efetiva).
 * Retorna H, H normalizada, cluster modal e sua massa.
 */
function semanticEntropy(clusters, weights = null) {
  const w = i => (weights ? (weights[i] ?? 1) : 1);
  const mass = clusters.map(c => c.reduce((s, i) => s + w(i), 0));
  const Z = mass.reduce((a, b) => a + b, 0) || 1;
  const p = mass.map(m => m / Z);
  const H = -p.reduce((s, pi) => s + (pi > 0 ? pi * Math.log(pi) : 0), 0) + 0; // + 0 normaliza -0
  const Hmax = Math.log(Math.max(2, clusters.length));
  const k = p.indexOf(Math.max(...p));
  return { H, Hnorm: H / Hmax, p, modal: clusters[k], modalMass: p[k], nClusters: clusters.length };
}

/* ================= 2. covariância de erro e N_eff ================= */

/**
 * @param E matriz de erro binária: E[t][i] = 1 se a célula i errou na questão t
 * @param shrink regularização de Ledoit-Wolf simplificada (encolhe para diagonal)
 */
function errorCovariance(E, shrink = 0.15) {
  const T = E.length, N = E[0]?.length || 0;
  if (!T || !N) return null;
  const mu = new Array(N).fill(0);
  for (const row of E) for (let i = 0; i < N; i++) mu[i] += row[i] / T;
  const S = Array.from({ length: N }, () => new Array(N).fill(0));
  for (const row of E)
    for (let i = 0; i < N; i++)
      for (let j = 0; j < N; j++) S[i][j] += (row[i] - mu[i]) * (row[j] - mu[j]) / Math.max(1, T - 1);
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) if (i !== j) S[i][j] *= (1 - shrink);
  for (let i = 0; i < N; i++) S[i][i] += 1e-6;
  return { Sigma: S, meanError: mu };
}

/** Σ a priori quando ainda não há histórico: blocos por família. */
function priorCovariance(cells, { rhoIntra = 0.85, rhoInter = 0.28, sigma = 0.45 } = {}) {
  const N = cells.length, v = sigma * sigma;
  const S = Array.from({ length: N }, () => new Array(N).fill(0));
  for (let i = 0; i < N; i++)
    for (let j = 0; j < N; j++)
      S[i][j] = i === j ? v : v * (cells[i].family === cells[j].family ? rhoIntra : rhoInter);
  return S;
}

/**
 * N_eff = (v̄ · (Σwᵢ)²) / (wᵀ Σ w).
 * Com w uniforme e Σ homogênea de correlação ρ, reduz a N/(1+(N-1)ρ).
 */
function effectiveN(Sigma, w = null) {
  const N = Sigma.length;
  const wt = w || new Array(N).fill(1 / N);
  let vbar = 0; for (let i = 0; i < N; i++) vbar += Sigma[i][i] / N;
  let q = 0; for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) q += wt[i] * wt[j] * Sigma[i][j];
  const sw = wt.reduce((a, b) => a + b, 0);
  return q > 0 ? (vbar * sw * sw) / q : N;
}

/* ================= 3. pesos GLS ================= */

function inverse(A, ridge = 1e-4) {
  const n = A.length;
  const M = A.map((r, i) => [...r.map((x, j) => x + (i === j ? ridge : 0)), ...r.map((_, j) => (i === j ? 1 : 0))]);
  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
    if (Math.abs(M[piv][c]) < 1e-12) return null;
    [M[c], M[piv]] = [M[piv], M[c]];
    const d = M[c][c];
    for (let k = 0; k < 2 * n; k++) M[c][k] /= d;
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c];
      if (!f) continue;
      for (let k = 0; k < 2 * n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map(r => r.slice(n));
}

/**
 * w* = Σ⁻¹1 / (1ᵀΣ⁻¹1).  clampNeg=true zera pesos negativos e renormaliza
 * (mais robusto quando Σ é estimada com poucas amostras).
 */
function glsWeights(Sigma, { ridge = 1e-3, clampNeg = true } = {}) {
  const N = Sigma.length;
  const Inv = inverse(Sigma, ridge);
  if (!Inv) return new Array(N).fill(1 / N);
  let w = Inv.map(r => r.reduce((a, b) => a + b, 0));
  if (clampNeg) w = w.map(x => Math.max(0, x));
  const s = w.reduce((a, b) => a + b, 0);
  return s > 0 ? w.map(x => x / s) : new Array(N).fill(1 / N);
}

/* ================= confiabilidade Dawid–Skene (Beta-Bernoulli) ================= */

class Reliability {
  constructor(prior = { a: 3, b: 1 }) { this.prior = prior; this.tab = new Map(); }
  key(cell, domain) { return `${cell}::${domain || '_'}`; }
  get(cell, domain) { return this.tab.get(this.key(cell, domain)) || { ...this.prior }; }
  update(cell, domain, correct) {
    const k = this.key(cell, domain), r = this.get(cell, domain);
    correct ? r.a++ : r.b++;
    this.tab.set(k, r);
    return r;
  }
  /** LLR do peso de voto: ln(acc/(1-acc)) com média posterior de Beta. */
  llrWeight(cell, domain) {
    const r = this.get(cell, domain);
    const acc = Math.min(0.995, Math.max(0.005, r.a / (r.a + r.b)));
    return Math.log(acc / (1 - acc));
  }
  toJSON() { return [...this.tab.entries()]; }
  static fromJSON(j, prior) { const r = new Reliability(prior); for (const [k, v] of j || []) r.tab.set(k, v); return r; }
}

module.exports = {
  clusterByEntailment, clusterByShingles, semanticEntropy,
  errorCovariance, priorCovariance, effectiveN, glsWeights, inverse,
  Reliability, jaccard, numericSignature, numericCompat
};
