'use strict';
/* UROBOROS · URB2 — carregador de .env, zero dependências
 *
 * Faltava isto: o código lia `process.env` direto, o que no Termux funcionava
 * com `export`, mas no Windows exigia `set` a cada sessão de terminal — e
 * qualquer chave esquecida silenciosamente removia uma FAMÍLIA do cluster,
 * derrubando N_eff sem erro visível.
 *
 * Tolera as três armadilhas de arquivo no Windows:
 *   · BOM UTF-8 no início (Bloco de Notas grava por padrão)
 *   · fim de linha CRLF
 *   · aspas em volta do valor
 * Nunca sobrescreve variável já definida no ambiente real.
 */

const fs = require('fs');
const path = require('path');

function carregar(arquivo = null, { sobrescrever = false } = {}) {
  const f = arquivo || process.env.ENV_FILE || path.join(process.cwd(), '.env');
  if (!fs.existsSync(f)) return { arquivo: f, existe: false, carregadas: 0, chaves: [] };

  let txt = fs.readFileSync(f, 'utf8');
  if (txt.charCodeAt(0) === 0xfeff) txt = txt.slice(1);              // BOM
  // .env gravado como UTF-16LE (PowerShell `>` faz isso) vira "n\0o\0d\0e"
  if (txt.includes('\u0000')) txt = Buffer.from(fs.readFileSync(f)).toString('utf16le').replace(/^\uFEFF/, '');

  const chaves = [];
  for (let linha of txt.split(/\r?\n/)) {
    linha = linha.trim();
    if (!linha || linha.startsWith('#')) continue;
    const i = linha.indexOf('=');
    if (i < 1) continue;
    const k = linha.slice(0, i).trim().replace(/^export\s+/, '');
    let v = linha.slice(i + 1).trim();
    // Ordem importa: se o valor está entre aspas, o fechamento delimita — tudo
    // depois é comentário. Sem aspas, só ` #` (espaço-cerquilha) inicia
    // comentário, porque chave de API pode conter '#' colado.
    if (v[0] === '"' || v[0] === "'") {
      const fim = v.indexOf(v[0], 1);
      v = fim > 0 ? v.slice(1, fim) : v.slice(1);
    } else {
      v = v.replace(/\s+#.*$/, '').trim();
    }
    if (!v) continue;
    if (!sobrescrever && process.env[k] !== undefined) continue;
    process.env[k] = v;
    chaves.push(k);
  }
  return { arquivo: f, existe: true, carregadas: chaves.length, chaves };
}

module.exports = { carregar };
