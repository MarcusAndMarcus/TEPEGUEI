'use strict';
/* UROBOROS · URB2 — orquestrador
 *
 * Pipeline (cada estágio emite evento SSE):
 *
 *   L0 amostragem     N células × k amostras, temperatura espalhada
 *   L1 atomização     resposta -> alegações atômicas + confiança declarada
 *   L2 Polo V         verificação determinística; veto absoluto
 *   L3 entropia sem.  clusteriza por implicação; H̃ por alegação e global
 *   L4 crença         BP no grafo alegação×célula, extrínseco + deflação
 *   L5 conformal      escore de não-conformidade -> emitir/ressalvar/abster
 *   L6 síntese        redação apenas com alegações sobreviventes
 */

require('./lib/env').carregar();
const { buildCells, buildPairs, composicao, call, parseJSON, available, emLote, ajustarConcorrencia } = require('./lib/providers');
const { priorCovariance, glsWeights, effectiveN, clusterByEntailment, semanticEntropy, Reliability } = require('./lib/epistemic');
const { ClaimGraph, confToLLR, sigmoid, L_MAX } = require('./lib/bp');
const Msk = require('./lib/mascara');
const { Conformal } = require('./lib/conformal');
const fs = require('fs');
const { verify } = require('./lib/verifier');
const { Ancora } = require('./lib/ancora');
const Tr = require('./lib/transistor');
const graph = require('./lib/graph');

const ROLE_SYS = {
  solver:      'Responda com precisão. Prefira o resultado correto ao resultado impressionante.',
  skeptic:     'Responda e depois liste explicitamente o que na sua própria resposta é incerto ou não verificável.',
  adversarial: 'Seu trabalho é FALSIFICAR. Produza a melhor resposta e em seguida o contra-argumento mais forte contra ela. Se a pergunta contiver pressuposto falso, diga.',
  formalist:   'Responda por derivação formal: defina símbolos, mostre passos, verifique unidades e casos-limite.',
  empirical:   'Responda ancorado em números, datas e fontes concretas. Sem número verificável, marque como não sustentado.',
  minimalist:  'Responda o mínimo suficiente. Nada de contexto decorativo. Se não sabe, diga que não sabe.',
  decompositor:'Quebre o problema em subproblemas independentes, resolva cada um e recomponha.',
  analogico:   'Resolva por analogia com um caso conhecido e depois diga onde a analogia falha.',
  limite:      'Verifique casos-limite e assintóticos antes de concluir: zero, infinito, sinais, degeneração.',
  unidades:    'Trate o problema por análise dimensional primeiro. Toda grandeza sai com unidade explícita.',
  contraexemplo:'Procure ativamente um contraexemplo à resposta óbvia antes de aceitá-la.',
  historico:   'Situe a pergunta na literatura: o que mudou, o que foi revisado, o que ainda é aberto.',
  quantitativo:'Só afirme o que puder quantificar. Ordem de grandeza vale mais que adjetivo.',
  causal:      'Separe correlação de mecanismo. Diga qual é o mecanismo ou admita que não há.',
  definicional:'Fixe as definições dos termos antes de responder; ambiguidade de definição é a resposta.',
  operacional: 'Responda pelo procedimento: o que se mede, com que instrumento, com que erro.'
};

const ATOM_SYS =
`Decomponha a resposta abaixo em ALEGAÇÕES ATÔMICAS verificáveis independentemente.
Uma alegação atômica contém exatamente um fato, sem conjunções.
Para cada uma dê "conf" em [0,1] — probabilidade de ser verdadeira, calibrada e honesta.
Marque "kind": "fact" (verificável), "calc" (contém cálculo), "opinion" (juízo), "meta" (sobre a própria resposta).
Responda APENAS JSON: {"claims":[{"text":"...","conf":0.0,"kind":"fact"}]}`;

const REFUT_SYS =
`Você é o REFUTADOR de um par. Recebe ALEGAÇÕES produzidas por outro modelo, de família diferente da sua.
Sua tarefa não é concordar por educação: é tentar DERRUBAR cada alegação com o que você sabe.
Para cada uma responda "veredito": "refuto" (é falsa ou tem erro concreto), "sustento" (você chegaria à mesma
conclusão de forma independente) ou "nao_sei" (fora do seu alcance — use sem constrangimento).
"forca" em [0,1] indica quanto você confia no seu próprio veredito.
Responda APENAS JSON: {"vereditos":[{"i":0,"veredito":"sustento","forca":0.8,"motivo":"..."}]}`;

const SYNTH_SYS =
`Escreva a resposta final usando SOMENTE as alegações fornecidas como VERIFICADAS.
As marcadas como INCERTAS podem aparecer, mas explicitamente hedgeadas.
As REJEITADAS não podem aparecer nem por implicação.
Não invente nada novo. Não acrescente ressalvas genéricas. Escreva em português.`;

class Uroboros {
  constructor(opts = {}) {
    this.n = opts.cells || 16;
    this.samplesPerCell = opts.samples || 1;
    // modo pares: cada célula nasce colada a uma de OUTRA família, com papéis
    // complementares (propõe / contesta). Não muda N_eff — muda onde cada
    // chamada cai dentro da covariância, e habilita refutação cruzada.
    this.modo = opts.modo || process.env.MODO || 'pares';
    if (this.modo === 'pares') {
      try { this.cells = buildPairs(Math.max(1, Math.floor(this.n / 2))); this.n = this.cells.length; }
      catch (e) { this.modo = 'solto'; this.avisoModo = e.message; this.cells = buildCells(this.n); }
    } else this.cells = buildCells(this.n);
    this.families = [...new Set(this.cells.map(c => c.family))];
    this.Sigma = priorCovariance(this.cells, opts.corr);
    this.w = glsWeights(this.Sigma);
    this.Neff = effectiveN(this.Sigma, this.w);
    this.topology = graph.bestChords(this.n, opts.degree || 6)[0];
    this.rounds = Math.min(10, this.topology.T);
    this.conformal = new Conformal({ alpha: opts.alpha ?? 0.10, file: opts.calFile || null });
    // Confiabilidade por (célula, domínio). Existia e nunca era usada — agora
    // fecha o laço: o Polo V e a âncora produzem rótulo de graça a cada
    // consulta, e cada célula acumula histórico Beta-Bernoulli.
    this.relFile = opts.relFile || `${process.env.DATA_DIR || './data'}/confiabilidade.json`;
    try { this.reliability = Reliability.fromJSON(JSON.parse(fs.readFileSync(this.relFile, 'utf8'))); }
    catch { this.reliability = new Reliability(); }
    this.aprender = opts.aprender !== false && process.env.APRENDER !== '0';
    this.judge = opts.judge || { provider: available()[0]?.id };
    this.ancora = opts.ancora === false ? null : new Ancora({ L_MAX: 12 });
    this.usarRede = !!opts.ancoraRede;
    this.rho = opts.rho || {};
    // composição dos pares: serie (precisão) | paralelo (cobertura) | misto
    this.composicaoPares = opts.composicaoPares || process.env.COMPOSICAO || 'misto';
    // NÚCLEO vs POOL. Acima de ~30 células, mais gente respondendo A MESMA
    // pergunta não compra nada: N_eff satura em 1/ρ. Mas células fazendo
    // TAREFAS DIFERENTES escalam linearmente, porque não há penalidade de
    // correlação entre trabalhos distintos.
    //   núcleo → amostra a pergunta (redundância, satura)
    //   pool   → verifica alegações DISTINTAS, cada uma de outra família
    //            (paralelismo, escala)
    this.nucleo = Math.min(this.n, Number(process.env.NUCLEO) || Math.min(32, this.n));
    if (this.modo === 'pares' && this.nucleo % 2) this.nucleo--;
    this.celulasNucleo = this.cells.slice(0, this.nucleo);
    this.celulasPool = this.cells.slice(this.nucleo);
    this.comp = composicao(this.cells);
    ajustarConcorrencia(Number(process.env.CONCURRENCY) || Math.min(24, Math.max(4, Math.ceil(this.n / 8))));
  }

  info() {
    return {
      celulas: this.n, familias: this.families, provedores: [...new Set(this.cells.map(c => c.provider))],
      N_eff: +this.Neff.toFixed(2),
      topologia: { cordas: this.topology.S, lambda2: +this.topology.lambda2.toFixed(4), rodadas: this.rounds },
      pesos: this.w.map(x => +x.toFixed(4)), alpha: this.conformal.alpha,
      ancora: this.ancora ? { grandezas: Object.keys(this.ancora.tabela.grandezas).length, naoVerificadas: this.ancora.tabela.naoVerificadas().length } : null,
      modo: this.modo, composicaoPares: this.composicaoPares, avisoModo: this.avisoModo || null,
      nucleo: this.nucleo, pool: this.celulasPool.length,
      orcamentoVerificacao: Number(process.env.ORCAMENTO_VERIF) || 60,
      composicao: this.comp,
      retornoMarginal: this.retornoMarginal()
    };
  }

  /**
   * Rotulagem gratuita: toda alegação vetada pelo Polo V ou pela âncora é um
   * erro CONFIRMADO das células que a afirmaram; toda alegação fortemente
   * ancorada é um acerto confirmado. Zero chamadas extras de API — o rótulo
   * vem da camada determinística, que já rodou.
   */
  aprenderComVerificador(G, domain) {
    if (!this.aprender) return { creditos: 0, debitos: 0 };
    let creditos = 0, debitos = 0;
    for (const c of G.claims.values()) {
      const vetada = c.vetoed || c.ancora?.veto;
      const confirmada = c.ancora && !c.ancora.veto && !c.ancora.tensao && c.ancora.llr >= 1.5;
      if (!vetada && !confirmada) continue;
      for (const e of c.evs) {
        if (e.cell < 0 || e.kind === 'refutacao') continue;   // verificador/âncora não se avaliam
        this.reliability.update(e.cell, domain, !vetada);
        vetada ? debitos++ : creditos++;
      }
    }
    if (creditos + debitos) {
      try {
        fs.mkdirSync(require('path').dirname(this.relFile), { recursive: true });
        fs.writeFileSync(this.relFile, JSON.stringify(this.reliability.toJSON()));
      } catch { /* disco efêmero no Render: perde o aprendizado, não a consulta */ }
    }
    return { creditos, debitos };
  }

  /** Peso relativo de cada célula: GLS a priori × confiabilidade medida. */
  pesosEfetivos(domain) {
    const base = this.w.map(x => x * this.n);
    if (!this.aprender) return base;
    return base.map((x, i) => {
      const r = this.reliability.get(i, domain);
      if (r.a + r.b < 8) return x;                    // sem histórico: não mexe
      const acc = r.a / (r.a + r.b);
      // fator em [0,5; 1,5]: histórico modula, não domina
      return x * Math.max(0.5, Math.min(1.5, 2 * acc));
    });
  }

  /**
   * Retorno marginal de N_eff por célula acrescentada, na composição atual.
   * É o número que decide se vale aumentar CELLS: quando a próxima célula
   * compra menos de 1% de N_eff, ela é despesa, não informação.
   */
  retornoMarginal() {
    const f = this.families.length;
    const rIn = 0.85, rOut = 0.28;
    const neff = N => { const m = Math.ceil(N / f); return N / (1 + (m - 1) * rIn + (N - m) * rOut); };
    const atual = neff(this.n), dobro = neff(this.n * 2);
    const teto = f / (1 + (f - 1) * rOut) * (1 / (1 - 0)) && (1 / ((rIn + (f - 1) * rOut) / f));
    return {
      N_eff_atual: +atual.toFixed(3),
      N_eff_dobrando_celulas: +dobro.toFixed(3),
      ganhoAoDobrar: `${((dobro / atual - 1) * 100).toFixed(1)}%`,
      tetoDestaComposicao: +teto.toFixed(3),
      recomendacao: this.comp.saturado
        ? `${this.comp.replicasExatas} células são réplicas exatas — só ${this.comp.combinacoesPossiveis} combinações distintas existem com ${f} família(s)`
        : 'composição ainda não saturada'
    };
  }

  /* ---------- L0b · amostragem em ondas com parada antecipada ----------
   *
   * Com o Gemini a 15 rpm, 16 pares custam ~1 min só de amostragem. Mas em
   * pergunta fácil os quatro primeiros pares já concordam entre famílias, e
   * gastar os doze restantes não compra nada.
   *
   * ARMADILHA DA PARADA OPCIONAL: espiar os dados e parar quando "está bom"
   * enfraquece a garantia — você seleciona justamente as realizações que
   * parecem certas, e o escore parcial fica otimista em relação ao que a
   * amostra completa daria.
   *
   * A correção é gastar α. E aqui o sinal engana: q̂ é o quantil (1−α), logo
   * α MAIOR dá quantil MENOR, isto é, limiar MAIS ESTRITO. Para parar cedo
   * usa-se q̂(4α); para emitir na amostra completa, q̂(α). Parar exige passar
   * por uma régua mais alta do que emitir — que é exatamente o que compensa
   * o viés da espiada.
   */
  async sampleEmOndas(question, domain, emit) {
    const tamOnda = Math.max(2, Number(process.env.ONDA) || (this.modo === 'pares' ? 8 : 6));
    const respostas = [];
    let usadas = 0, ondas = 0;

    for (let inicio = 0; inicio < this.celulasNucleo.length; inicio += tamOnda) {
      const lote = this.celulasNucleo.slice(inicio, inicio + tamOnda);
      const novas = await this._chamarCelulas(lote, question, domain, emit);
      respostas.push(...novas);
      usadas += lote.length;
      ondas++;

      const restam = this.celulasNucleo.length - usadas;
      if (!restam || respostas.length < 4) continue;

      const se = await this.entropy(question, respostas, null);
      const score = Conformal.score({
        p: se.modalMass, Hnorm: se.Hnorm,
        nOrigins: new Set(respostas.map(r => r.cell.family)).size,
        nFamilies: this.families.length, verifierChecked: true
      });
      // 4α, não α/4: quantil menor = régua mais alta (ver comentário acima)
      const estrito = this.conformal.qhat(domain, Math.min(0.6, this.conformal.alpha * 4));
      if (estrito.calibrated && score <= estrito.q) {
        emit?.('paradaAntecipada', {
          ondas, celulasUsadas: usadas, celulasPoupadas: restam,
          score: +score.toFixed(4), limiarEstrito: +estrito.q.toFixed(4),
          economia: `${((restam / this.celulasNucleo.length) * 100).toFixed(0)}%`
        });
        break;
      }
    }
    return { respostas, ondas, usadas };
  }

  async _chamarCelulas(cells, question, domain, emit) {
    const jobs = cells.map(cell => async () => {
      try {
        const r = await call(cell.provider, {
          system: `${ROLE_SYS[cell.role] || ROLE_SYS.solver}\nDomínio: ${domain || 'geral'}.`,
          messages: [{ role: 'user', content: question }],
          temperature: cell.temperature, maxTokens: 1100
        });
        emit?.('cell', { cell: cell.id, provider: cell.provider, role: cell.role, lado: cell.lado || null, ms: r.ms, ok: true });
        return { cell, sample: 0, text: r.text };
      } catch (e) {
        emit?.('cell', { cell: cell.id, provider: cell.provider, ok: false, erro: String(e.message).slice(0, 160) });
        return null;
      }
    });
    return (await emLote(jobs)).filter(Boolean);
  }

  /* ---------- L0 ---------- */
  async sample(question, domain, emit) {
    const jobs = [];
    for (const cell of this.celulasNucleo) {
      for (let k = 0; k < this.samplesPerCell; k++) {
        jobs.push(async () => {
          try {
            const r = await call(cell.provider, {
              system: `${ROLE_SYS[cell.role]}\nDomínio: ${domain || 'geral'}.`,
              messages: [{ role: 'user', content: question }],
              temperature: Math.min(1.0, cell.temperature + 0.1 * k),
              maxTokens: 1100
            });
            emit?.('cell', { cell: cell.id, provider: cell.provider, role: cell.role, ms: r.ms, ok: true });
            return { cell, sample: k, text: r.text };
          } catch (e) {
            emit?.('cell', { cell: cell.id, provider: cell.provider, ok: false, erro: String(e.message).slice(0, 160) });
            return null;
          }
        });
      }
    }
    // emLote respeita o semáforo global: 256 células não podem abrir 256 sockets
    const r = await emLote(jobs, {
      onProgresso: (f, t) => { if (t > 32 && f % Math.ceil(t / 20) === 0) emit?.('progresso', { fase: 'amostragem', feitas: f, total: t }); }
    });
    return r.filter(Boolean);
  }

  /* ---------- L1 ---------- */
  async atomize(responses, emit) {
    const out = [];
    await emLote(responses.map(r => async () => {
      try {
        const a = await call(r.cell.provider, {
          system: ATOM_SYS, json: true, temperature: 0, maxTokens: 900,
          messages: [{ role: 'user', content: r.text.slice(0, 6000) }]
        });
        const p = parseJSON(a.text);
        for (const c of (p?.claims || []).slice(0, 24))
          if (c?.text) out.push({ cell: r.cell, text: String(c.text).trim(), conf: Number(c.conf) || 0.6, kind: c.kind || 'fact' });
      } catch { /* célula muda nesta rodada */ }
    }), { onProgresso: (f, t) => { if (t > 32 && f % Math.ceil(t / 10) === 0) emit?.('progresso', { fase: 'atomizacao', feitas: f, total: t }); } });
    emit?.('atomizacao', { alegacoes: out.length });
    return out;
  }

  /* ---------- L1b · refutação cruzada ----------
   * Cada alegação volta para o PARCEIRO do seu autor, que é de outra família.
   * Um refutador da mesma família erra junto (ρ=0,85) e quase não enxerga o
   * que o autor não viu; de outra família cobre 4,8× mais do espaço de erro
   * não coberto. É a única arma interna contra viés compartilhado.
   */
  async crossCheck(atoms, emit) {
    if (this.modo !== 'pares' && !this.celulasPool.length) return [];

    // Aloca escrutínio onde ele importa. Alegação com confiança declarada
    // perto de 0,5 é onde a evidência é mais fraca; alegação já em 0,95 não
    // precisa de mais um verificador. Ordena por incerteza e gasta o orçamento
    // de cima para baixo, sempre com verificador de OUTRA família que o autor.
    const orcamento = Number(process.env.ORCAMENTO_VERIF) || 60;
    const porTexto = new Map();
    for (const a of atoms) {
      if (!porTexto.has(a.text)) porTexto.set(a.text, []);
      porTexto.get(a.text).push(a);
    }
    const alegacoes = [...porTexto.entries()]
      .map(([text, lista]) => ({ text, autores: lista.map(x => x.cell), incerteza: 1 - Math.abs(2 * (lista[0].conf ?? 0.6) - 1) }))
      .sort((a, b) => b.incerteza - a.incerteza);

    // verificadores disponíveis: parceiros (modo pares) + pool inteiro
    const disponiveis = [...this.celulasPool];
    if (this.modo === 'pares') for (const a of atoms) {
      const p = a.cell.parceiro != null ? this.cells[a.cell.parceiro] : null;
      if (p && !disponiveis.includes(p)) disponiveis.push(p);
    }

    const tarefas = new Map();      // idVerificador -> [alegações]
    let gastos = 0, vi = 0;
    for (const al of alegacoes) {
      if (gastos >= orcamento) break;
      const famAutores = new Set(al.autores.map(c => c.family));
      // até 2 verificadores por alegação, ambos de família que não a escreveu
      let atribuidos = 0;
      for (let tent = 0; tent < disponiveis.length && atribuidos < 2 && gastos < orcamento; tent++) {
        const v = disponiveis[(vi + tent) % disponiveis.length];
        if (famAutores.has(v.family)) continue;
        if (!tarefas.has(v.id)) tarefas.set(v.id, []);
        if (tarefas.get(v.id).length >= 3) continue;    // lote pequeno = escrutínio profundo
        tarefas.get(v.id).push(al.text);
        atribuidos++; gastos++;
      }
      vi += 2;
    }

    const out = [];
    await emLote([...tarefas.entries()].map(([pid, textos]) => async () => {
      const p = this.cells[pid];
      const sub = textos.map(t => ({ text: t, cell: porTexto.get(t)[0].cell }));
      try {
        const r = await call(p.provider, {
          system: REFUT_SYS, json: true, temperature: 0.1, maxTokens: 900,
          messages: [{ role: 'user', content: sub.map((a, i) => `[${i}] ${a.text}`).join('\n') }]
        });
        for (const v of (parseJSON(r.text)?.vereditos || [])) {
          const a = sub[Number(v.i)];
          if (!a || v.veredito === 'nao_sei') continue;
          const forca = Math.min(0.9, Math.max(0.1, Number(v.forca) || 0.5));
          out.push({
            text: a.text, cell: p, autor: a.cell,
            veredito: v.veredito,
            llr: (v.veredito === 'refuto' ? -1 : 1) * confToLLR(0.5 + forca * 0.4)
          });
        }
      } catch { /* parceiro mudo */ }
    }), { onProgresso: (f, t) => { if (t > 16 && f % Math.ceil(t / 8) === 0) emit?.('progresso', { fase: 'refutacao', feitas: f, total: t }); } });
    emit?.('refutacao', {
      verificadores: tarefas.size, alegacoesEscrutinadas: gastos, orcamento,
      julgadas: out.length,
      refutadas: out.filter(x => x.veredito === 'refuto').length,
      sustentadas: out.filter(x => x.veredito === 'sustento').length
    });
    return out;
  }

  /* ---------- L2..L4 ---------- */
  buildGraph(atoms, emit, refutacoes = [], dominio = 'geral') {
    // w normalizado para média 1: pesos GLS são RELATIVOS entre células, não
    // uma partição da unidade. Com soma 1 o grafo encolhia toda evidência por N.
    const wRel = this.pesosEfetivos(dominio);
    const G = new ClaimGraph({ rhoDefault: 0.8, damping: 0.35, rho: this.rho, w: wRel, prior: -0.4 });
    let vetos = 0, verified = 0, ancoradas = 0, disputa = 0;

    for (const a of atoms) {
      G.add(a.text, { cell: a.cell.id, family: a.cell.family, bit: a.cell.bit, llr: confToLLR(a.conf), kind: a.kind, par: a.cell.par });
    }
    // ═══ O PAR COMO TRANSISTOR ═══
    // O refutador não SOMA: ele MODULA. Coletor = propositor (conteúdo), base =
    // refutador de outra família (controle), emissor = saída para o grafo.
    // Somando, um refutador que diz "sustento" criava crença sozinho, mesmo em
    // alegação que ninguém propôs. Com ganho multiplicativo isso é impossível:
    // sem corrente de coletor, ganho nenhum produz saída.
    const vereditosPorTexto = new Map();
    for (const r of refutacoes) {
      if (!vereditosPorTexto.has(r.text)) vereditosPorTexto.set(r.text, []);
      vereditosPorTexto.get(r.text).push({
        veredito: r.veredito,
        forca: Math.min(1, Math.abs(r.llr) / 2.2),
        cell: r.cell
      });
    }
    let emCorte = 0, amplificados = 0;
    for (const c of G.claims.values()) {
      const vs = vereditosPorTexto.get(c.text);
      if (!vs || !vs.length) continue;

      // um "par" por propositor distinto; verificadores em cascata na base
      const porAutor = new Map();
      for (const e of c.evs) {
        if (e.cell < 0 || e.kind === 'refutacao') continue;
        porAutor.set(e.cell, (porAutor.get(e.cell) ?? 0) + e.llr);
      }
      // A base de um par só aceita controle de família DIFERENTE. Sem esta
      // trava, um refutador acabava modulando também o propositor da própria
      // família — e aí o "cruzamento" não era cruzado: a mesma família julgava
      // a si mesma com ρ = 0,85, que é quase não julgar.
      const pares = [...porAutor.entries()].map(([cell, lp]) => {
        const fam = this.cells[cell]?.family;
        const base = vs.filter(v => v.cell.family !== fam);
        return { ...Tr.par(lp, base), cell, semControle: base.length === 0 };
      });
      if (!pares.length) continue;

      const saida = this.composicaoPares === 'serie' ? Tr.serie(pares)
        : this.composicaoPares === 'paralelo' ? Tr.paralelo(pares)
        : Tr.misto(new Map([...pares.reduce((m, p) => {
            const f = this.cells[p.cell]?.family || '?';
            if (!m.has(f)) m.set(f, []); m.get(f).push(p); return m;
          }, new Map())]));

      c.transistor = {
        pares: pares.length, modo: saida.modo, conduz: saida.conduz,
        ganhoMedio: +(pares.reduce((s2, p) => s2 + p.ganho, 0) / pares.length).toFixed(3),
        regioes: pares.map(p => p.regiao)
      };
      if (pares.some(p => p.regiao === 'corte')) emCorte++;
      if (pares.some(p => p.ganho > 1.2)) amplificados++;

      // a saída do transistor SUBSTITUI a soma das evidências do propositor;
      // verificador e âncora continuam entrando por fora, com direito de veto
      c.evs = c.evs.filter(e => e.cell < 0);
      c.evs.push({
        cell: -3, family: '__transistor', bit: Msk.RESERVADO << 3n,
        llr: saida.llr, kind: 'transistor'
      });
      c.llr = saida.llr;
    }
    if (emCorte || amplificados) emit?.('transistor', { emCorte, amplificados, composicao: this.composicaoPares });
    // concordância cruzada por alegação: pares em que AMBOS os lados sustentam
    for (const c of G.claims.values()) {
      const porPar = new Map();
      for (const e of c.evs) {
        if (e.par == null) continue;
        if (!porPar.has(e.par)) porPar.set(e.par, new Set());
        if (e.llr > 0) porPar.get(e.par).add(e.family);
      }
      const total = porPar.size;
      const cruzados = [...porPar.values()].filter(s => s.size >= 2).length;
      c.paresTotais = total;
      c.paresConcordantes = cruzados;
      c.concordanciaCruzada = total ? cruzados / total : 0;
    }
    for (const c of G.claims.values()) {
      // L2a · Polo V determinístico
      const v = verify(c.text);
      if (v.checked) {
        verified++;
        if (v.veto) vetos++;
        c.evs.push({ cell: -1, family: '__verifier', bit: Msk.VERIFICADOR, llr: v.llr, kind: 'verifier' });
        c.verifier = { veto: v.veto, checks: v.checks.length };
      }
      // L2b · âncora externa. Entra como VERIFICAÇÃO, nunca como contexto de L0:
      // injetar a mesma passagem nas N células elevaria ρ e colapsaria N_eff.
      if (this.ancora) {
        const anc = this.ancora.local(c.text);
        if (anc) {
          ancoradas++;
          if (anc.tensao) disputa++;
          if (anc.veto) vetos++;
          c.evs.push({ cell: -2, family: '__ancora:tabela', bit: Msk.ANCORA, llr: anc.llr, kind: anc.veto ? 'verifier' : 'ancora' });
          c.ancora = { llr: +anc.llr.toFixed(2), fonte: anc.fonte, tensao: anc.tensao, veto: anc.veto, detalhe: anc.detalhe };
        }
      }
    }
    const usados = G.run(this.rounds);
    const comCruz = [...G.claims.values()].filter(c => c.paresConcordantes > 0).length;
    emit?.('crenca', { alegacoes: G.claims.size, verificadas: verified, ancoradas, emDisputa: disputa, vetadas: vetos, comConcordanciaCruzada: comCruz, rodadas: usados });
    return G;
  }

  /* ---------- L3 (entropia semântica sobre as respostas inteiras) ---------- */
  async entropy(question, responses, emit) {
    const texts = responses.map(r => r.text);
    const clusters = await clusterByEntailment(question, texts, this.judge);
    const wPerSample = responses.map(r => this.w[r.cell.id] ?? 1 / this.n);
    const se = semanticEntropy(clusters, wPerSample);
    emit?.('entropia', { H: +se.H.toFixed(3), Hnorm: +se.Hnorm.toFixed(3), clusters: se.nClusters, massaModal: +se.modalMass.toFixed(3) });
    return se;
  }

  /* ---------- pipeline completo ---------- */
  async run(question, { domain = 'geral', emit = null } = {}) {
    const t0 = Date.now();
    emit?.('inicio', this.info());

    const emOndas = process.env.ONDAS !== '0' && this.samplesPerCell === 1;
    let responses, ondas = 1, usadas = this.n;
    if (emOndas) ({ respostas: responses, ondas, usadas } = await this.sampleEmOndas(question, domain, emit));
    else responses = await this.sample(question, domain, emit);
    if (!responses.length) throw new Error('nenhuma célula respondeu');

    const [atoms, se] = await Promise.all([
      this.atomize(responses, emit),
      this.entropy(question, responses, emit)
    ]);

    const refutacoes = await this.crossCheck(atoms, emit);
    this.ultimasOndas = ondas; this.ultimasUsadas = usadas;
    const G = this.buildGraph(atoms, emit, refutacoes, domain);
    const aprendizado = this.aprenderComVerificador(G, domain);
    if (aprendizado.creditos + aprendizado.debitos) emit?.('aprendizado', aprendizado);

    // limiar de aceitação vem do conformal, não de chute
    const claims = [...G.claims.values()].map(c => {
      const m = {
        p: sigmoid(c.llr), Hnorm: se.Hnorm,
        // em modo pares, a concordância cruzada substitui a contagem crua de
        // origens: duas famílias que sustentam a mesma alegação valem muito
        // mais que dez células da mesma família
        nOrigins: this.modo === 'pares' && c.paresTotais
          ? c.concordanciaCruzada * this.families.length
          : Msk.origens(c.mask),
        nFamilies: this.families.length,
        verifierChecked: !!c.verifier || !!c.ancora
      };
      const s = Conformal.score(m);
      const d = this.conformal.decide(domain, s);
      return { ...c, p: m.p, score: s, decisao: d.action, conformal: d };
    });

    const aceitas = claims.filter(c => c.decisao === 'emitir' && !c.vetoed);
    const incertas = claims.filter(c => c.decisao === 'ressalvar' && !c.vetoed);
    const rejeitadas = claims.filter(c => c.decisao === 'abster' || c.vetoed);

    emit?.('filtro', { aceitas: aceitas.length, incertas: incertas.length, rejeitadas: rejeitadas.length });

    // gate global: se o cluster não converge semanticamente, não sintetiza
    const gate = Conformal.score({ p: se.modalMass, Hnorm: se.Hnorm, nOrigins: popcount(claims.reduce((m, c) => m | c.mask, 0) & ~(1 << 31)), nFamilies: this.families.length, verifierChecked: true });
    const gd = this.conformal.decide(domain, gate);
    if (gd.action === 'abster' || (!aceitas.length && !incertas.length)) {
      emit?.('abstencao', gd);
      return this.pack({ question, domain, texto: null, abstencao: gd, se, aceitas, incertas, rejeitadas, t0 });
    }

    const synth = await call(this.judge.provider, {
      system: SYNTH_SYS, temperature: 0.2, maxTokens: 1400,
      messages: [{ role: 'user', content:
`PERGUNTA: ${question}

VERIFICADAS:
${aceitas.map(c => `- ${c.text}  [p=${c.p.toFixed(3)}, origens=${Msk.origens(c.mask)}${c.ancora ? `, ancora: ${c.ancora.fonte}${c.ancora.tensao ? ' (fontes em tensao)' : ''}` : ''}]`).join('\n') || '(nenhuma)'}

INCERTAS (hedgear):
${incertas.map(c => `- ${c.text}  [p=${c.p.toFixed(3)}]`).join('\n') || '(nenhuma)'}

REJEITADAS (proibido usar):
${rejeitadas.slice(0, 20).map(c => `- ${c.text}${c.vetoed ? '  [VETO Polo V]' : ''}`).join('\n') || '(nenhuma)'}` }]
    });

    emit?.('sintese', { chars: synth.text.length });
    return this.pack({ question, domain, texto: synth.text, abstencao: gd.action === 'ressalvar' ? gd : null, se, aceitas, incertas, rejeitadas, t0 });
  }

  pack({ question, domain, texto, abstencao, se, aceitas, incertas, rejeitadas, t0 }) {
    return {
      pergunta: question, dominio: domain, texto,
      abstencao,
      epistemico: {
        N_eff: +this.Neff.toFixed(2), familias: this.families.length,
        H_semantica: +se.Hnorm.toFixed(3), clusters: se.nClusters, massaModal: +se.modalMass.toFixed(3),
        modo: this.modo, ondas: this.ultimasOndas ?? null, celulasUsadas: this.ultimasUsadas ?? this.n,
        lambda2: +this.topology.lambda2.toFixed(4), rodadas: this.rounds
      },
      alegacoes: {
        aceitas: aceitas.map(fmt), incertas: incertas.map(fmt), rejeitadas: rejeitadas.map(fmt)
      },
      ms: Date.now() - t0
    };
    function fmt(c) {
      return {
        texto: c.text, p: +c.p.toFixed(4), llr: +c.llr.toFixed(2),
        origens: Msk.origens(c.mask), veto: !!c.vetoed, score: +c.score.toFixed(4),
        ancora: c.ancora || null,
        paresConcordantes: c.paresConcordantes ?? null, paresTotais: c.paresTotais ?? null,
        transistor: c.transistor || null
      };
    }
  }
}

module.exports = { Uroboros };

/* ---------------- servidor SSE ---------------- */
if (require.main === module) {
  const http = require('http');
  const U = new Uroboros({
    cells: Number(process.env.CELLS) || 16,
    samples: Number(process.env.SAMPLES) || 1,
    alpha: Number(process.env.ALPHA) || 0.10,
    calFile: process.env.CAL_FILE || './data/conformal.json'
  });

  http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/info') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(U.info(), null, 2));
    }
    if (u.pathname === '/ancora') {
      const q = u.searchParams.get('q');
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(q ? (U.ancora?.local(q) ?? { llr: 0, detalhe: 'sem ancoragem' }) : U.ancora?.tabela.naoVerificadas(), null, 2));
    }
    if (u.pathname === '/topologia') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(graph.bestChords(U.n, 6).slice(0, 5), null, 2));
    }
    if (u.pathname !== '/consulta') { res.writeHead(404); return res.end(); }

    const q = u.searchParams.get('q');
    const dom = u.searchParams.get('dominio') || 'geral';
    if (!q) { res.writeHead(400); return res.end('falta q'); }

    if (u.searchParams.get('formato') === 'texto') {           // camada de voz M01 Pro
      try {
        const r = await U.run(q, { domain: dom });
        res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
        return res.end(r.texto || `Abstenção. Entropia semântica ${r.epistemico.H_semantica}, N efetivo ${r.epistemico.N_eff}.`);
      } catch (e) { res.writeHead(500); return res.end(String(e.message)); }
    }

    res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive' });
    const emit = (ev, data) => res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`);
    try {
      const r = await U.run(q, { domain: dom, emit });
      emit('final', r);
    } catch (e) { emit('erro', { mensagem: String(e.message) }); }
    res.end();
  }).listen(process.env.PORT || 8080, () => console.log('URB2 em :' + (process.env.PORT || 8080)));
}
