'use strict';
/* UROBOROS · URB2 — telegrama v2
 *
 * Diferença essencial em relação ao URB1: o cabeçalho carrega PROVENIÊNCIA.
 *
 *   off  tam  campo
 *   ---  ---  --------------------------------------------------------
 *    0    4   MAGIC "URB2"
 *    4    1   versão (0x02)
 *    5    1   tipo   (0x10 alegação · 0x20 réplica · 0x30 veto · 0x40 consenso)
 *    6    1   célula emissora
 *    7    1   saltos percorridos
 *    8    4   claimId  (FNV-1a do texto canônico) — reformulações colidem aqui
 *   12    2   LLR em ponto fixo Q8.8  (int16, ×256)
 *   14    2   comprimento da originMask em bytes  (m)
 *   16    2   comprimento do payload              (n)
 *   18    m   originMask big-endian — bitmap das células que tocaram a alegação
 *   18+m  n   payload UTF-8
 *   18+m+n 2  CRC16-CCITT (0x1021, init 0xFFFF) sobre tudo que veio antes
 *
 * A originMask virou de largura VARIÁVEL na v3 do cabeçalho: os 4 bytes fixos
 * limitavam o cluster a 32 células, e acima disso `1 << i` envolvia em silêncio
 * — a célula 32 se apresentava como a 0 e o filtro extrínseco parava de
 * reconhecer o eco. Com 256 células a máscara ocupa 32 bytes.
 *
 * originMask é o que torna a regra R1 (informação extrínseca) executável no
 * fio, e não só na memória do orquestrador: qualquer nó pode decidir sozinho
 * se um telegrama é evidência nova ou eco do que ele mesmo emitiu.
 */

const MAGIC = 'URB2';
const VER = 0x03;
const TYPE = { CLAIM: 0x10, REPLY: 0x20, VETO: 0x30, CONSENSUS: 0x40 };
const HDR = 18;
const Msk = require('./mascara');

function crc16(buf) {
  let crc = 0xffff;
  for (const b of buf) {
    crc ^= b << 8;
    for (let i = 0; i < 8; i++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc & 0xffff;
}

function encode({ type = TYPE.CLAIM, cell = 0, hops = 0, claimId = 0, originMask = 0n, llr = 0, payload = '' }) {
  const pl = Buffer.from(String(payload), 'utf8');
  const mk = Msk.paraBytes(originMask);
  const b = Buffer.alloc(HDR + mk.length + pl.length + 2);
  b.write(MAGIC, 0, 'ascii');
  b.writeUInt8(VER, 4);
  b.writeUInt8(type, 5);
  b.writeUInt8(cell & 0xff, 6);
  b.writeUInt8(hops & 0xff, 7);
  b.writeUInt32BE(claimId >>> 0, 8);
  b.writeInt16BE(Math.max(-32768, Math.min(32767, Math.round(llr * 256))), 12);
  b.writeUInt16BE(mk.length, 14);
  b.writeUInt16BE(pl.length, 16);
  mk.copy(b, HDR);
  pl.copy(b, HDR + mk.length);
  const fim = HDR + mk.length + pl.length;
  b.writeUInt16BE(crc16(b.subarray(0, fim)), fim);
  return b;
}

function decode(buf) {
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf, 'hex');
  if (b.length < HDR + 2) throw new Error('URB2: curto demais');
  if (b.subarray(0, 4).toString('ascii') !== MAGIC) throw new Error('URB2: magic inválido');
  const ver = b.readUInt8(4);
  if (ver !== VER) throw new Error(`URB2: versão ${ver}`);
  const m = b.readUInt16BE(14), n = b.readUInt16BE(16);
  const fim = HDR + m + n;
  if (b.length !== fim + 2) throw new Error('URB2: comprimento inconsistente');
  const want = b.readUInt16BE(fim);
  const got = crc16(b.subarray(0, fim));
  if (want !== got) throw new Error(`URB2: CRC ${got.toString(16)} != ${want.toString(16)}`);
  return {
    type: b.readUInt8(5), cell: b.readUInt8(6), hops: b.readUInt8(7),
    claimId: b.readUInt32BE(8), llr: b.readInt16BE(12) / 256,
    originMask: Msk.deBytes(b.subarray(HDR, HDR + m)),
    payload: b.subarray(HDR + m, fim).toString('utf8')
  };
}

const toHex = o => encode(o).toString('hex').toUpperCase();
const fromHex = h => decode(Buffer.from(h, 'hex'));

/** Repasse: incrementa saltos, funde a máscara e recusa ecos. */
function forward(tel, myBit, maxHops = 4) {
  if (tel.hops >= maxHops) return null;
  const bit = typeof myBit === 'bigint' ? myBit : BigInt(myBit);
  if ((tel.originMask & bit) !== 0n) return null;   // já passei por aqui: eco
  return { ...tel, hops: tel.hops + 1, originMask: tel.originMask | bit };
}

module.exports = { MAGIC, VER, TYPE, HDR, crc16, encode, decode, toHex, fromHex, forward };
