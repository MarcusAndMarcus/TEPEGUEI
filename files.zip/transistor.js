'use strict';
/* UROBOROS · URB2 — o par como transistor
 *
 * ═══ POR QUE NÃO SOMAR ═══
 *
 * Até aqui o par somava: L = L_propositor + L_refutador. Isso tem um defeito
 * estrutural que só fica visível quando se pensa no par como dispositivo:
 * uma alegação que NINGUÉM propôs ganhava crença só porque um refutador disse
 * "sustento". Somar trata os dois lados como fontes simétricas, e eles não são.
 *
 * Num transistor não passa corrente de coletor sem alimentação de coletor,
 * por mais base que se injete. A assimetria é o ponto do dispositivo.
 *
 * ═══ O MODELO ═══
 *
 *   coletor  ← propositor   L_p   (fonte de conteúdo)
 *   base     ← refutador    (v,s) (controle, de OUTRA família)
 *   emissor  → L_par              (saída para o grafo de crença)
 *
 *   L_par = g(v,s) · L_p  +  d(v,s)
 *
 * Ganho g e pull-down d por veredito, com força s ∈ [0,1]:
 *
 *   refuto    g = (1−s)²      d = −δ·s     corte: mata o sinal e puxa para baixo
 *   nao_sei   g = 1           d = 0        transparente
 *   sustento  g = 1 + κ·s     d = 0        região ativa: amplifica
 *
 * Três regimes, como no dispositivo:
 *   CORTE      s→1 em refuto  ⇒ g→0. Não importa quão confiante o propositor
 *              estava: uma refutação forte de outra família zera o sinal.
 *   ATIVO      região linear em L_p, com ganho modulado pela base.
 *   SATURAÇÃO  g·L_p é limitado por L_MAX; acima disso a saída não cresce mais,
 *              o que impede que concordância entusiasmada vire certeza absoluta.
 *
 * E a propriedade que a soma não tinha:
 *   SEM BASE, SEM CORRENTE. Se L_p ≤ 0, nenhum ganho salva a alegação —
 *   g·L_p continua ≤ 0. Refutador sozinho não cria crença.
 *
 * ═══ COMPOSIÇÃO ═══
 *
 * Transistores compõem em portas. Pares também:
 *   SÉRIE     todos os pares precisam conduzir. Qualquer corte derruba tudo.
 *             Alta precisão, recall baixo. É o modo para alegação que vai
 *             virar número num relatório.
 *   PARALELO  basta um par conduzir. Alta cobertura, precisão menor.
 *             É o modo para levantar hipótese.
 *   MISTO     série dentro de cada família, paralelo entre famílias.
 */

const L_MAX = 12;
const clamp = x => Math.max(-L_MAX, Math.min(L_MAX, x));
const sigmoid = x => 1 / (1 + Math.exp(-x));

const PADRAO = {
  kappa: 1.5,      // ganho máximo em sustentação plena: g = 2,5
  delta: 2.0,      // pull-down máximo em refutação plena
  gMin: 0.0,       // corte total permitido
  gMax: 2.5
};

/** Característica de transferência da base: veredito+força → (ganho, pull-down). */
function base(veredito, forca = 0.5, cfg = PADRAO) {
  const s = Math.min(1, Math.max(0, Number(forca) || 0));
  switch (veredito) {
    case 'refuto':
      return { g: Math.max(cfg.gMin, (1 - s) ** 2), d: -cfg.delta * s, regiao: s > 0.7 ? 'corte' : 'ativo' };
    case 'sustento':
      return { g: Math.min(cfg.gMax, 1 + cfg.kappa * s), d: 0, regiao: 'ativo' };
    default:
      return { g: 1, d: 0, regiao: 'transparente' };
  }
}

/**
 * Um par. `refutacoes` pode ter mais de um veredito (pool de verificação):
 * os ganhos multiplicam e os pull-downs somam — transistores em cascata.
 */
function par(llrPropositor, refutacoes = [], cfg = PADRAO) {
  let g = 1, d = 0, regiao = 'transparente';
  for (const r of refutacoes) {
    const b = base(r.veredito, r.forca, cfg);
    g *= b.g; d += b.d;
    if (b.regiao === 'corte') regiao = 'corte';
    else if (regiao !== 'corte' && b.regiao === 'ativo') regiao = 'ativo';
  }
  g = Math.min(cfg.gMax, g);
  const bruto = g * clamp(llrPropositor) + d;
  const saida = clamp(bruto);
  return {
    llr: saida, p: sigmoid(saida), ganho: +g.toFixed(4), pullDown: +d.toFixed(4),
    regiao: Math.abs(bruto) >= L_MAX ? 'saturacao' : regiao,
    conduz: saida > 0
  };
}

/** SÉRIE: qualquer corte derruba. Precisão alta. */
function serie(pares, cfg = PADRAO) {
  if (!pares.length) return { llr: 0, p: 0.5, modo: 'serie', conduz: false, pares: 0 };
  const cortou = pares.some(p => !p.conduz);
  const llr = cortou ? Math.min(...pares.map(p => p.llr)) : clamp(pares.reduce((s, p) => s + p.llr, 0) / Math.sqrt(pares.length));
  return { llr: clamp(llr), p: sigmoid(clamp(llr)), modo: 'serie', conduz: !cortou, pares: pares.length };
}

/** PARALELO: basta um conduzir. Cobertura alta. */
function paralelo(pares, cfg = PADRAO) {
  if (!pares.length) return { llr: 0, p: 0.5, modo: 'paralelo', conduz: false, pares: 0 };
  const conduzindo = pares.filter(p => p.conduz);
  const llr = conduzindo.length
    ? clamp(Math.max(...conduzindo.map(p => p.llr)) + Math.log(conduzindo.length))
    : clamp(Math.max(...pares.map(p => p.llr)));
  return { llr, p: sigmoid(llr), modo: 'paralelo', conduz: conduzindo.length > 0, pares: pares.length };
}

/** MISTO: série dentro de cada família, paralelo entre famílias. */
function misto(paresPorFamilia, cfg = PADRAO) {
  const ramos = [...paresPorFamilia.values()].map(ps => serie(ps, cfg));
  const r = paralelo(ramos.map(x => ({ ...x, conduz: x.conduz })), cfg);
  return { ...r, modo: 'misto', ramos: ramos.length };
}

/** Curva de transferência, para inspeção. */
function curva(veredito, forcas = [0, 0.25, 0.5, 0.75, 1], llrP = 2) {
  return forcas.map(s => {
    const r = par(llrP, [{ veredito, forca: s }]);
    return { forca: s, ganho: r.ganho, llr: +r.llr.toFixed(3), p: +r.p.toFixed(4), regiao: r.regiao };
  });
}

module.exports = { PADRAO, L_MAX, base, par, serie, paralelo, misto, curva, clamp, sigmoid };
