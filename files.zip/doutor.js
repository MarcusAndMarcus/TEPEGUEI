'use strict';
/* UROBOROS · URB2 — doutor do ambiente
 *
 *   node tools/doutor.js
 *
 * Responde "isso vai rodar nesta máquina?" antes de gastar quota de API.
 * Cobre as armadilhas específicas do Windows: versão do Node, página de código
 * do console, BOM/UTF-16 nos arquivos de dados, CRLF nos checkpoints, e o
 * caminho de escrita de DATA_DIR.
 */

const envInfo = require('../lib/env').carregar();

const fs = require('fs');
const path = require('path');
const os = require('os');

let problemas = 0, avisos = 0;
const ok = (m, d = '') => console.log(`  ok    ${m}${d ? '  ' + d : ''}`);
const erro = (m, d = '') => { problemas++; console.log(`  ERRO  ${m}${d ? '  ' + d : ''}`); };
const aviso = (m, d = '') => { avisos++; console.log(`  aviso ${m}${d ? '  ' + d : ''}`); };

console.log(`\nUROBOROS · URB2 — diagnóstico\n${os.platform()} ${os.release()} · ${os.arch()} · ${os.cpus().length} núcleos · ${(os.totalmem() / 1e9).toFixed(1)} GB\n`);

/* ---------- Node ---------- */
console.log('[runtime]');
const maior = Number(process.versions.node.split('.')[0]);
maior >= 18 ? ok('Node', `v${process.versions.node}`)
            : erro('Node < 18', `v${process.versions.node} — fetch global e AbortController faltam`);
typeof fetch === 'function' ? ok('fetch global') : erro('fetch global ausente');
try { new RegExp('(?<!a)b'); ok('lookbehind em regex'); } catch { erro('lookbehind indisponível — a extração da âncora falha'); }
try { new RegExp('\\p{L}', 'u'); ok('propriedades unicode em regex'); } catch { erro('\\p{L} indisponível'); }

/* ---------- console ---------- */
console.log('\n[terminal]');
if (process.platform === 'win32') {
  const cp = process.env.CHCP || '';
  console.log('  nota  acentos e σ λ ± só aparecem certos com página de código UTF-8.');
  console.log('        No PowerShell:  [Console]::OutputEncoding = [Text.Encoding]::UTF8');
  console.log('        No cmd.exe   :  chcp 65001');
  console.log('        Teste agora   :  σ₈ = 0,811 ± 0,006 · λ₂ · ρ · Δ · ✓');
  aviso('confira acima se os símbolos saíram legíveis');
} else ok('plataforma POSIX', 'sem ajuste de codificação');

/* ---------- .env e chaves ---------- */
console.log('\n[.env e provedores]');
envInfo.existe ? ok('.env encontrado', `${envInfo.arquivo} · ${envInfo.carregadas} variáveis`)
               : aviso('.env não encontrado', 'copie .env.example para .env');
if (envInfo.existe) {
  const raw = fs.readFileSync(envInfo.arquivo);
  if (raw[0] === 0xff && raw[1] === 0xfe) aviso('.env está em UTF-16LE', 'o carregador converte, mas salve como UTF-8 sem BOM');
  else if (raw[0] === 0xef && raw[1] === 0xbb) ok('.env com BOM UTF-8', 'tolerado');
}

let REG, available;
try { ({ REG, available } = require('../lib/providers')); } catch (e) { erro('lib/providers não carrega', e.message); }
if (available) {
  const provs = available();
  const fams = [...new Set(provs.map(p => p.fam))];
  if (!provs.length) erro('nenhuma chave de provedor no ambiente', 'o cluster não sobe');
  else {
    ok(`${provs.length} provedor(es)`, provs.map(p => p.id).join(', '));
    const nEff = fams.length ? (fams.length / (1 + (fams.length - 1) * 0.28)).toFixed(2) : '—';
    fams.length >= 4 ? ok(`${fams.length} famílias`, `N_eff a priori ≈ ${nEff}`)
                     : aviso(`só ${fams.length} família(s)`, `N_eff a priori ≈ ${nEff} — adicione provedores de corpora distintos`);
    const faltando = Object.entries(REG).filter(([id]) => !provs.find(p => p.id === id)).map(([id]) => id);
    if (faltando.length) console.log(`        sem chave: ${faltando.join(', ')}`);

    // saturacao: acima de provedores x papeis x camadas, celulas viram replicas exatas
    try {
      const { buildCells, composicao } = require('../lib/providers');
      const N = Number(process.env.CELLS) || 16;
      const comp = composicao(buildCells(N));
      const neff = n => { const m = Math.ceil(n / fams.length); return n / (1 + (m - 1) * 0.85 + (n - m) * 0.28); };
      const ganho = ((neff(N * 2) / neff(N) - 1) * 100).toFixed(1);
      comp.saturado
        ? aviso(`CELLS=${N} satura`, `${comp.replicasExatas} réplicas exatas · só ${comp.combinacoesPossiveis} combinações existem · dobrar CELLS compra ${ganho}%`)
        : ok(`CELLS=${N}`, `${comp.combinacoesDistintas}/${comp.combinacoesPossiveis} combinações · dobrar compra ${ganho}%`);
      const conc = Number(process.env.CONCURRENCY) || Math.min(24, Math.max(4, Math.ceil(N / 8)));
      console.log(`        concorrência global: ${conc} chamadas simultâneas`);
    } catch (e) { aviso('não foi possível avaliar saturação', e.message.slice(0, 60)); }
  }
}

/* ---------- caminhos e escrita ---------- */
console.log('\n[arquivos]');
const DATA = process.env.DATA_DIR || './data';
try {
  fs.mkdirSync(DATA, { recursive: true });
  const teste = path.join(DATA, '.escrita-teste');
  fs.writeFileSync(teste, 'x'); fs.unlinkSync(teste);
  ok('DATA_DIR gravável', path.resolve(DATA));
} catch (e) { erro('DATA_DIR não gravável', `${path.resolve(DATA)} — ${e.message}`); }

for (const f of ['data/tabela.json', 'bench/sintetico.json']) {
  if (!fs.existsSync(f)) { f.includes('bench') ? aviso(`${f} ausente`, 'rode: npm run bench') : erro(`${f} ausente`); continue; }
  const raw = fs.readFileSync(f);
  if (raw[0] === 0xff && raw[1] === 0xfe) { erro(`${f} está em UTF-16LE`, 'gerado com `>` do PowerShell — regere com npm run bench'); continue; }
  if (raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf) { erro(`${f} tem BOM UTF-8`, 'JSON.parse falha — regrave sem BOM'); continue; }
  try { JSON.parse(raw.toString('utf8')); ok(`${f}`, `${(raw.length / 1024).toFixed(0)} KB, UTF-8 válido`); }
  catch (e) { erro(`${f} não é JSON válido`, e.message.slice(0, 60)); }
}

for (const f of ['ckpt-sigma.jsonl', 'ckpt-conformal.jsonl']) {
  const p = path.join(DATA, f);
  if (!fs.existsSync(p)) continue;
  const txt = fs.readFileSync(p, 'utf8');
  const linhas = txt.split(/\r?\n/).filter(Boolean);
  let ruins = 0;
  for (const l of linhas) { try { JSON.parse(l); } catch { ruins++; } }
  ruins ? erro(`${f}: ${ruins}/${linhas.length} linhas ilegíveis`) : ok(`${f}`, `${linhas.length} registros`);
}

/* ---------- módulos e autoteste rápido ---------- */
console.log('\n[módulos]');
for (const m of ['bp', 'conformal', 'epistemic', 'estimador', 'graph', 'urb2', 'verifier', 'ancora', 'rag', 'conectores']) {
  try { require(`../lib/${m}`); ok(`lib/${m}.js`); } catch (e) { erro(`lib/${m}.js`, e.message.slice(0, 70)); }
}

console.log('\n[sanidade numérica]');
try {
  const { verify } = require('../lib/verifier');
  const { Ancora } = require('../lib/ancora');
  const G = require('../lib/graph');
  verify('12*7 = 82').veto ? ok('Polo V veta aritmética errada') : erro('Polo V não vetou 12*7=82');
  const a = new Ancora().local('A idade do universo e 6000 anos');
  a && a.veto ? ok('âncora veta após converter unidade') : erro('âncora não vetou 6000 anos');
  G.mixingTime(10, [1, 3]) === Infinity ? ok('espectro detecta grafo bipartido') : erro('detecção de bipartição falhou');
} catch (e) { erro('sanidade numérica', e.message); }

/* ---------- estado calibrado ---------- */
console.log('\n[calibração]');
const cov = path.join(DATA, 'covariancia.json');
if (fs.existsSync(cov)) {
  try {
    const j = JSON.parse(fs.readFileSync(cov, 'utf8'));
    if (j.sigma) ok('Σ medida', `T=${j.sigma.T} · N_eff=${j.sigma.diagnostico?.N_eff} · fração comum=${j.sigma.diagnostico?.fracaoComum}`);
    else aviso('covariancia.json sem bloco sigma', 'rode a fase sigma');
  } catch { erro('covariancia.json ilegível'); }
} else aviso('sem Σ medida', 'rode: npm run cal:sigma — o sistema roda com prior, sem garantia');

const conf = path.join(DATA, 'conformal.json');
fs.existsSync(conf) ? ok('calibração conformal presente') : aviso('sem q̂ calibrado', 'os limiares ficam no default');

/* ---------- veredito ---------- */
console.log(`\n${problemas ? `${problemas} problema(s)` : 'nenhum problema'} · ${avisos} aviso(s)`);
if (problemas) console.log('Corrija os ERRO antes de rodar calibração ou subir.\n');
else console.log(avisos ? 'Pronto para rodar. Os avisos não impedem, mas reduzem garantia.\n' : 'Ambiente completo.\n');
process.exit(problemas ? 1 : 0);
