'use strict';
/* UROBOROS · URB2 — gerador de bench sintético
 *
 * O gargalo da calibração é rotular. Rotular 300 questões à mão é o que
 * mantém Σ como prior indefinidamente.
 *
 * ATALHO: gerar questões cujo gabarito é CALCULADO, não consultado.
 * Custo de rotulação zero, oferta infinita, e o julgamento fica determinístico
 * (comparação numérica com tolerância) — o que também elimina as chamadas de
 * API do juiz e o viés do juiz.
 *
 * DESIGN CRÍTICO: os parâmetros são SORTEADOS a cada item. H₀ = 68,31 e não
 * 67,36. Isso torna a memorização inútil — o modelo é obrigado a derivar.
 * O que se mede é o canal de RACIOCÍNIO, que é onde a correlação entre
 * famílias é mais informativa.
 *
 * O que isto NÃO mede: recuperação factual. Para essa, itens curados com
 * fonte primária continuam necessários — mas Σ do canal de raciocínio já
 * basta para os pesos GLS e para o N_eff.
 *
 *   node tools/gerar-bench.js 240 42 bench/sintetico.json
 *
 * O terceiro argumento faz a ferramenta GRAVAR o arquivo. Depender de `>` do
 * shell quebra no PowerShell, que grava UTF-16LE por padrão — o JSON sai
 * ilegível para JSON.parse e o erro só aparece muito depois, na calibração.
 */

const MPC = 3.0856775814913673e22;     // m
const C = 299792458;                   // m/s
const G = 6.674e-11;
const GYR = 3.1556952e16;              // s

function rng(seed) { let s = seed >>> 0 || 1; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296); }
const r = (u, a, b, d = 2) => +(a + u() * (b - a)).toFixed(d);
const pick = (u, arr) => arr[Math.floor(u() * arr.length)];
const sig = (x, n = 6) => +Number(x).toPrecision(n);

/* ---------- cosmologia: derivação pura, parâmetros no enunciado ---------- */
const cosmo = {
  rho_crit(u) {
    const H0 = r(u, 62, 76, 2);
    const H = H0 * 1000 / MPC;
    const v = 3 * H * H / (8 * Math.PI * G);
    return { q: `Dado H₀ = ${H0} km/s/Mpc e G = 6,674×10⁻¹¹ m³kg⁻¹s⁻², calcule a densidade crítica ρ_c = 3H₀²/(8πG) em kg/m³. Responda o valor numérico com 4 algarismos significativos.`,
             a: `${sig(v, 4)} kg/m³`, num: sig(v, 6), tol: 0.002 };
  },
  idade(u) {
    const H0 = r(u, 63, 74, 2), Om = r(u, 0.26, 0.36, 3), OL = +(1 - Om).toFixed(3);
    const tH = 9.778 / (H0 / 100);
    const t = (2 / (3 * Math.sqrt(OL))) * Math.asinh(Math.sqrt(OL / Om)) * tH;
    return { q: `Universo ΛCDM plano com H₀ = ${H0} km/s/Mpc, Ω_m = ${Om} e Ω_Λ = ${OL}, desprezando radiação. Use t₀ = (2/(3H₀√Ω_Λ))·asinh(√(Ω_Λ/Ω_m)) e o tempo de Hubble 9,778/h Gyr. Qual a idade t₀ em Gyr? Dê 4 algarismos significativos.`,
             a: `${sig(t, 4)} Gyr`, num: sig(t, 6), tol: 0.003 };
  },
  Ez(u) {
    const Om = r(u, 0.26, 0.36, 3), z = r(u, 0.3, 2.5, 2), OL = +(1 - Om).toFixed(3);
    const E = Math.sqrt(Om * (1 + z) ** 3 + OL);
    return { q: `Universo plano com Ω_m = ${Om}, Ω_Λ = ${OL}. Calcule E(z) = √(Ω_m(1+z)³ + Ω_Λ) em z = ${z}. Dê 5 algarismos significativos.`,
             a: `${sig(E, 5)}`, num: sig(E, 6), tol: 0.001 };
  },
  distComovel(u) {
    const H0 = r(u, 64, 73, 2), Om = r(u, 0.27, 0.35, 3), z = r(u, 0.4, 2.0, 2), OL = +(1 - Om).toFixed(3);
    const DH = (C / 1000) / H0;                             // Mpc
    const f = zz => 1 / Math.sqrt(Om * (1 + zz) ** 3 + OL);
    const n = 2000, h = z / n; let s = f(0) + f(z);
    for (let i = 1; i < n; i++) s += f(i * h) * (i % 2 ? 4 : 2);
    const DC = DH * (h / 3) * s;
    return { q: `Universo plano, H₀ = ${H0} km/s/Mpc, Ω_m = ${Om}, Ω_Λ = ${OL}. Calcule a distância comóvel D_C(z) = (c/H₀)∫₀^z dz'/E(z') até z = ${z}, em Mpc. Dê 4 algarismos significativos.`,
             a: `${sig(DC, 4)} Mpc`, num: sig(DC, 6), tol: 0.005 };
  },
  bao(u) {
    const H0 = r(u, 64, 73, 2), Om = r(u, 0.27, 0.35, 3), z = r(u, 0.5, 1.5, 2), OL = +(1 - Om).toFixed(3);
    const DH0 = (C / 1000) / H0;
    const f = zz => 1 / Math.sqrt(Om * (1 + zz) ** 3 + OL);
    const n = 2000, h = z / n; let s = f(0) + f(z);
    for (let i = 1; i < n; i++) s += f(i * h) * (i % 2 ? 4 : 2);
    const DM = DH0 * (h / 3) * s;
    const DHz = DH0 / Math.sqrt(Om * (1 + z) ** 3 + OL);
    const DV = Math.cbrt(z * DM * DM * DHz);
    return { q: `Universo plano, H₀ = ${H0} km/s/Mpc, Ω_m = ${Om}. Em z = ${z}, calcule D_V = [z·D_M²·D_H]^(1/3) em Mpc, onde D_M é a distância comóvel e D_H = c/H(z). Dê 4 algarismos significativos.`,
             a: `${sig(DV, 4)} Mpc`, num: sig(DV, 6), tol: 0.005 };
  },
  S8(u) {
    const s8 = r(u, 0.74, 0.86, 3), Om = r(u, 0.26, 0.36, 3);
    const S8 = s8 * Math.sqrt(Om / 0.3);
    return { q: `Com σ₈ = ${s8} e Ω_m = ${Om}, calcule S₈ = σ₈√(Ω_m/0,3). Dê 5 algarismos significativos.`,
             a: `${sig(S8, 5)}`, num: sig(S8, 6), tol: 0.001 };
  },
  desaceleracao(u) {
    const Om = r(u, 0.24, 0.38, 3), OL = +(1 - Om).toFixed(3);
    const q0 = Om / 2 - OL;
    return { q: `Universo plano ΛCDM com Ω_m = ${Om} e Ω_Λ = ${OL}. Calcule o parâmetro de desaceleração hoje, q₀ = Ω_m/2 − Ω_Λ. Dê 5 algarismos significativos.`,
             a: `${sig(q0, 5)}`, num: sig(q0, 6), tol: 0.001 };
  },
  tensao(u) {
    const a = r(u, 66, 69, 2), sa = r(u, 0.4, 0.9, 2), b = r(u, 71, 75, 2), sb = r(u, 0.8, 1.5, 2);
    const t = (b - a) / Math.sqrt(sa * sa + sb * sb);
    return { q: `Duas medidas independentes de H₀: ${a} ± ${sa} e ${b} ± ${sb} km/s/Mpc. Calcule a tensão em σ, definida por |μ₁−μ₂|/√(σ₁²+σ₂²). Dê 4 algarismos significativos.`,
             a: `${sig(t, 4)}σ`, num: sig(t, 6), tol: 0.002 };
  },
  redshiftT(u) {
    const T0 = r(u, 2.70, 2.76, 3), z = r(u, 500, 1500, 0);
    const T = T0 * (1 + z);
    return { q: `A temperatura do fundo cósmico hoje é T₀ = ${T0} K e escala como T(z) = T₀(1+z). Qual T em z = ${z}? Dê 5 algarismos significativos, em K.`,
             a: `${sig(T, 5)} K`, num: sig(T, 6), tol: 0.001 };
  }
};

/* ---------- raciocínio geral ---------- */
const geral = {
  cadeia(u) {
    const a = r(u, 12, 99, 0), b = r(u, 3, 19, 0), c = r(u, 100, 999, 0), d = r(u, 4, 17, 0);
    const v = ((a * b) + c) / d;
    return { dominio: 'aritmetica', q: `Calcule ((${a} × ${b}) + ${c}) ÷ ${d}. Dê o resultado com 6 algarismos significativos.`,
             a: `${sig(v, 6)}`, num: sig(v, 8), tol: 1e-5 };
  },
  quadratica(u) {
    const p = r(u, 1, 9, 0), q = r(u, 1, 9, 0), A = r(u, 1, 5, 0);
    const B = -A * (p + q), Cc = A * p * q;
    const raiz = Math.max(p, q);
    return { dominio: 'algebra', q: `Resolva ${A}x² ${B < 0 ? '−' : '+'} ${Math.abs(B)}x ${Cc < 0 ? '−' : '+'} ${Math.abs(Cc)} = 0. Dê apenas a MAIOR raiz, com 6 algarismos significativos.`,
             a: `${sig(raiz, 6)}`, num: sig(raiz, 8), tol: 1e-5 };
  },
  trabalho(u) {
    const F = r(u, 15, 400, 1), d = r(u, 2, 60, 1), th = pick(u, [0, 30, 45, 60]);
    const W = F * d * Math.cos(th * Math.PI / 180);
    const kwh = W / 3.6e6;
    return { dominio: 'fisica', q: `Uma força de ${F} N desloca um corpo por ${d} m, com ângulo de ${th}° entre força e deslocamento. Calcule o trabalho em joules e depois converta para kWh. Dê o valor em kWh com 5 algarismos significativos.`,
             a: `${sig(kwh, 5)} kWh`, num: sig(kwh, 7), tol: 1e-4 };
  },
  potencia(u) {
    const V = r(u, 110, 480, 0), R = r(u, 4, 220, 1), t = r(u, 5, 90, 0);
    const P = V * V / R, E = P * t * 60 / 3.6e6;
    return { dominio: 'fisica', q: `Um resistor de ${R} Ω sob ${V} V. Calcule a potência dissipada e a energia consumida em ${t} minutos, em kWh. Dê a energia com 5 algarismos significativos.`,
             a: `${sig(E, 5)} kWh`, num: sig(E, 7), tol: 1e-4 };
  },
  juros(u) {
    const P = r(u, 1000, 90000, 0), i = r(u, 0.4, 2.4, 2), n = r(u, 6, 60, 0);
    const M = P * Math.pow(1 + i / 100, n);
    return { dominio: 'financeiro', q: `Capital de R$ ${P} a juros compostos de ${i}% ao mês por ${n} meses. Calcule o montante final. Dê 7 algarismos significativos, sem símbolo de moeda.`,
             a: `${sig(M, 7)}`, num: sig(M, 9), tol: 1e-5 };
  },
  meiaVida(u) {
    const N0 = r(u, 100, 9000, 0), th = r(u, 2, 40, 1), t = r(u, 5, 120, 1);
    const N = N0 * Math.pow(0.5, t / th);
    return { dominio: 'fisica', q: `Uma amostra tem ${N0} núcleos e meia-vida de ${th} dias. Quantos núcleos restam após ${t} dias? Dê 6 algarismos significativos.`,
             a: `${sig(N, 6)}`, num: sig(N, 8), tol: 1e-5 };
  },
  data(u) {
    const y = 1900 + Math.floor(u() * 150), m = 1 + Math.floor(u() * 12), d = 1 + Math.floor(u() * 28);
    const dias = 100 + Math.floor(u() * 4000);
    const base = new Date(Date.UTC(y, m - 1, d));
    const fim = new Date(base.getTime() + dias * 86400000);
    const iso = fim.toISOString().slice(0, 10);
    return { dominio: 'temporal', q: `Partindo de ${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y}, some ${dias} dias corridos. Responda a data resultante no formato AAAA-MM-DD.`,
             a: iso, num: null, tol: null, exato: iso };
  },
  ordem(u) {
    const a = r(u, 1.1, 9.9, 2), ea = Math.floor(r(u, -18, 18, 0));
    const b = r(u, 1.1, 9.9, 2), eb = Math.floor(r(u, -18, 18, 0));
    const v = (a * Math.pow(10, ea)) * (b * Math.pow(10, eb));
    return { dominio: 'aritmetica', q: `Calcule (${a}×10^${ea}) × (${b}×10^${eb}). Dê o resultado em notação científica com 5 algarismos significativos na mantissa.`,
             a: `${sig(v, 5)}`, num: sig(v, 7), tol: 1e-5 };
  }
};

function gerar(n = 200, seed = 42) {
  const u = rng(seed);
  const gerCos = Object.entries(cosmo), gerGer = Object.entries(geral);
  const itens = [];
  for (let i = 0; i < n; i++) {
    const usaCosmo = u() < 0.5;
    const [nome, fn] = usaCosmo ? pick(u, gerCos) : pick(u, gerGer);
    const it = fn(u);
    itens.push({
      id: `syn-${String(i).padStart(4, '0')}-${nome}`,
      tipo: nome,
      dominio: it.dominio || 'cosmologia',
      q: it.q,
      a: it.a,
      num: it.num ?? null,
      exato: it.exato ?? null,
      tol: it.tol ?? null,
      fonte: 'calculado'
    });
  }
  return itens;
}

module.exports = { gerar, cosmo, geral };

if (require.main === module) {
  const n = Number(process.argv[2] || 240), seed = Number(process.argv[3] || 42);
  const saida = process.argv[4] || null;
  const json = JSON.stringify(gerar(n, seed), null, 1);
  if (saida) {
    const fs = require('fs'), path = require('path');
    fs.mkdirSync(path.dirname(path.resolve(saida)), { recursive: true });
    fs.writeFileSync(saida, json, { encoding: 'utf8' });      // sempre UTF-8, sem BOM
    console.log(`${n} itens gravados em ${saida}`);
  } else {
    process.stdout.write(json);
  }
}
