# Subir o URB2 — Windows → GitHub → Render

Zero dependências npm. Node ≥ 18. Nada aqui precisa de WSL.

---

## 0. Antes: o TensorRAG5D do artigo não entra

O modelo do PDF é inerte em embeddings normalizados (Kendall τ = 1,000000 contra
cosseno) e as pontes nunca executam. O que sobe é `lib/rag.js`, que reproduz o
artigo em `alpha = 0` e melhora a partir daí.

```powershell
npm run auditoria     # reproduz todas as medições, sem rede e sem chave
```

---

## 1. Node

Precisa ser ≥ 18 — o código usa `fetch` global, `AbortController`, lookbehind em
regex e `\p{L}`. Node 16 falha em silêncio nas três últimas.

```powershell
winget install OpenJS.NodeJS.LTS
```

**Feche e reabra o terminal** — o `winget` não atualiza o `PATH` da sessão que
já está aberta. Depois:

```powershell
node -v
```

Se `node` não for reconhecido mesmo após reabrir, o instalador não pôs no PATH;
reinstale pelo `.msi` de nodejs.org.

Se preferir alternar versões, `winget install CoreyButler.NVMforWindows` e
`nvm install lts` / `nvm use lts`.

---

## 2. Terminal em UTF-8 — faça isto antes de qualquer coisa

O console do Windows usa página de código 850/437 por padrão. Os relatórios
imprimem `σ₈`, `λ₂`, `ρ`, `±`, `N_eff`, e sem UTF-8 tudo vira caractere quebrado.

**PowerShell** (por sessão):

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$OutputEncoding = [Text.Encoding]::UTF8
```

Para não repetir, ponha as duas linhas no seu perfil (`notepad $PROFILE`).

**cmd.exe**: `chcp 65001`

O Windows Terminal já lida com isso melhor que o console legado — se tiver, use.

### A armadilha do `>` no PowerShell

`node script.js > arquivo.json` no PowerShell grava **UTF-16LE**. O
`JSON.parse` do Node lê lixo, e o erro só aparece muito depois, na calibração.

Por isso **nenhum script deste projeto usa redirecionamento**. `npm run bench`
manda a própria ferramenta gravar o arquivo, sempre em UTF-8 sem BOM. Se você
gerar algo à mão, use `| Out-File -Encoding utf8` em vez de `>`.

---

## 3. Pegar os arquivos e diagnosticar

> **Nunca cole um bloco inteiro no PowerShell.** Ele lê tudo como um só script:
> se qualquer linha tiver erro de sintaxe, **nada** roda — nem as linhas boas
> antes dela. Rode um comando por vez.
>
> **E nunca escreva `<algo>` num comando.** No PowerShell `<` é operador
> reservado e o parser aborta com `RedirectionNotSupported`. Onde um endereço
> for variável, guarde numa variável antes.

Saia de `C:\WINDOWS\system32` — não se clona projeto ali.

```powershell
mkdir C:\dev -Force
cd C:\dev
```

**Se você já tem repositório**, ponha o endereço numa variável primeiro:

```powershell
$repo = "https://github.com/SEU-USUARIO/uroboros-urb2.git"
git clone $repo uroboros-urb2
cd uroboros-urb2
```

**Se ainda não tem**, descompacte o `uroboros-urb2.zip` em `C:\dev`, entre na
pasta e inicialize:

```powershell
cd C:\dev\uroboros-urb2
git init
git add -A
git commit -m "URB2 2.4.1"
```

Depois diagnostique:

```powershell
node tools/doutor.js
```

O doutor verifica versão do Node, recursos de regex, codificação dos arquivos de
dados, BOM/UTF-16 no `.env`, permissão de escrita em `DATA_DIR`, integridade dos
checkpoints, e roda três testes de sanidade numérica. **Ele diz o que quebrou e
por quê antes de você gastar quota de API.**

```powershell
npm test
```

56 testes, nenhum precisa de rede.

Sem `npm install`: não há dependências.

---

## 4. Chaves

```powershell
Copy-Item .env.example .env
notepad .env
```

Ao salvar no Bloco de Notas, escolha **UTF-8** (não "UTF-8 com BOM", embora o
carregador tolere ambos e até UTF-16LE).

Cada chave presente vira uma **família**, e família vale muito mais que célula:

| configuração | N_eff |
|---|---|
| 2 famílias | 1,56 |
| 4 famílias | 2,11 |
| 8 famílias | 2,70 |

Mínimo útil: `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `GROQ_API_KEY`,
`MISTRAL_API_KEY`. Cada uma além disso ainda paga. O doutor imprime o `N_eff`
a priori da sua configuração e lista quais provedores estão sem chave.

`.env` está no `.gitignore`. Confira antes do primeiro push.

---

## 5. Calibrar antes de subir

Sem isto, `Σ` é prior, `q̂` é default e o sistema não tem garantia nenhuma.

```powershell
npm run bench          # 240 itens com gabarito calculado, grava o arquivo
npm run cal:sigma      # 60 itens, ~15 min
npm run cal:relatorio
```

60 itens bastam para `N_eff` — medido, é estável já em T=60, enquanto os ρ
individuais só convergem lá pelos milhares. Resumível: se fechar o terminal ou o
processo morrer, rodar de novo continua de onde parou.

Leia dois números no relatório:

- **`N_eff`** — quantas testemunhas independentes você realmente tem.
- **`fracaoComum`** — que porcentagem do erro é modo comum, irremovível por
  qualquer média. Se estiver perto do teto, adicionar células é desperdício.

Depois, com tempo, `node tools/calibrar.js --fase conformal --bench bench/sintetico.json --n 80`
fecha o `q̂` por domínio.

Versione `data/covariancia.json` e `data/conformal.json`: são o estado calibrado.

---

## 6. Auditar a âncora

```powershell
npm run ancora
```

Lista as entradas pendentes de conferência contra fonte primária (hoje:
`H0_DESI`, `w0`, `wa`, `A_gwb`, `sum_m_nu`), mostra as tensões conhecidas, e
roda um autoteste. Entradas com `verificado: false` nunca votam nem vetam.

Confira por amostragem os valores marcados como verificados também — um valor
errado ali vira falso veto sobre alegação correta.

---

## 7. GitHub

```powershell
git add -A
git commit -m "URB2 2.4.0"
git push
```

O `.gitattributes` força LF em tudo. Sem ele, o `autocrlf` do Git no Windows
converte os checkpoints JSONL e o que foi calibrado numa máquina não lê direito
na outra.

---

## 8. Render

Web Service · Node · Oregon.

| campo | valor |
|---|---|
| Build Command | `echo sem dependencias` |
| Start Command | `node orchestrator.js` |
| Health Check Path | `/info` |

Variáveis de ambiente (cole as chaves do `.env`, mais):

```
CELLS=16
ALPHA=0.10
DATA_DIR=/opt/render/project/src/data
GEMINI_RPM=15
GROQ_RPM=30
```

`DATA_DIR` usa barra normal — no Render é Linux. O código monta caminhos com
`path`, então funciona igual nos dois lados.

O free tier hiberna: a primeira consulta após ~15 min de ociosidade demora.
`/info` é barato e serve de ping.

---

## 9. Verificar no ar

PowerShell não tem `curl` de verdade — `curl` é alias de `Invoke-WebRequest`.
Use `curl.exe` (existe desde o Windows 10 1803) ou os cmdlets nativos:

```powershell
curl.exe https://SEU-APP.onrender.com/info
Invoke-RestMethod https://SEU-APP.onrender.com/topologia
Invoke-RestMethod "https://SEU-APP.onrender.com/ancora?q=H0 = 67.4 km/s/Mpc"
curl.exe -N "https://SEU-APP.onrender.com/consulta?q=...&dominio=cosmologia"
curl.exe "https://SEU-APP.onrender.com/consulta?q=...&formato=texto"
```

Para SSE use `curl.exe -N`: o `Invoke-RestMethod` bufferiza e você não vê os
eventos chegando.

Confira em `/info` que `familias` traz o que você espera e que `N_eff` bate com
`data/covariancia.json`. Se vier o valor a priori, a calibração não subiu junto.

---

## 10. Ordem recomendada

0. Um comando por vez. Nada de colar blocos, nada de `<placeholder>`.
1. `node tools/doutor.js` — resolver todo **ERRO** antes de seguir.
2. `npm test` — 56/56.
3. `npm run ancora` — conferir as 5 pendentes.
4. `npm run bench` e `npm run cal:sigma` — ler `N_eff` e `fracaoComum`.
5. Desligar as células com peso GLS ≈ 0 que o relatório listar.
6. Só então push e deploy.

---

## Apêndice · Termux (tablet)

```bash
pkg update && pkg install -y nodejs-lts git
git clone "$repo" uroboros-urb2 && cd uroboros-urb2
node tools/doutor.js && npm test
```

O resto é idêntico. Sem os problemas de codificação: o Termux já é UTF-8.
