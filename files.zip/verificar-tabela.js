'use strict';
/* UROBOROS · URB2 — auditoria da tabela de âncora
 *
 * Entradas com verificado=false NUNCA votam nem vetam. Este utilitário lista
 * o que falta conferir contra a fonte primária, e checa a saúde do resto.
 *
 *   node tools/verificar-tabela.js
 *   node tools/verificar-tabela.js "H0 = 67.4 km/s/Mpc"
 */
const { Ancora, Tabela } = require('../lib/ancora');

const q = process.argv.slice(2).join(' ').trim();
const A = new Ancora();

if (q) {
  const m = A.tabela.extrair(q);
  const r = A.local(q);
  console.log('menções :', JSON.stringify(m.map(x => `${x.grandeza}=${x.valor} [${x.unidade}]`)));
  console.log('âncora  :', r ? JSON.stringify(r, (k, v) => (k === 'mencoes' ? undefined : v), 1) : 'sem ancoragem');
  process.exit(0);
}

const t = A.tabela;
const chaves = Object.keys(t.grandezas);
const semAlias = chaves.filter(k => !t.aliases[k]);
const naoVer = t.naoVerificadas();
const tensoes = chaves.filter(k => {
  const v = t.verificadas(k);
  for (let i = 0; i < v.length; i++) for (let j = i + 1; j < v.length; j++) {
    const d = Math.abs(v[i].valor - v[j].valor) / Math.max(1e-30, Math.hypot(v[i].sigma || 0, v[j].sigma || 0));
    if (d > 3) return true;
  }
  return false;
});

console.log(`\ntabela: ${chaves.length} grandezas · ${chaves.reduce((s, k) => s + t.entradas(k).length, 0)} entradas com valor`);
console.log(`verificadas: ${chaves.reduce((s, k) => s + t.verificadas(k).length, 0)}   podem votar e vetar`);
console.log(`pendentes  : ${naoVer.length}   abstêm até serem conferidas\n`);

if (naoVer.length) {
  console.log('CONFERIR CONTRA FONTE PRIMÁRIA (e virar verificado:true em data/tabela.json):');
  for (const e of naoVer) console.log(`  ${e.grandeza.padEnd(18)} ${e.fonte}`);
  console.log();
}
if (tensoes.length) {
  console.log('grandezas com fontes em tensão >3σ (âncora atenua, não veta):');
  for (const k of tensoes) {
    console.log(`  ${k}:`);
    for (const e of t.verificadas(k)) console.log(`    ${e.valor} ± ${e.sigma} ${e.unidade}  — ${e.fonte}`);
  }
  console.log();
}
if (semAlias.length) console.log('sem alias (nunca serão extraídas do texto):', semAlias.join(', '), '\n');

// sanidade: toda entrada verificada deve ser reconhecida a partir do próprio valor
let falhas = 0;
for (const k of chaves) {
  for (const e of t.verificadas(k)) {
    const alias = (t.aliases[k] || [k])[0];
    const frase = `${alias} = ${e.valor} ${e.unidade === '1' ? '' : e.unidade}`.trim();
    const r = A.local(frase);
    if (!r || r.llr <= 0) { console.log(`  AUTOTESTE FALHOU: "${frase}" -> ${r ? r.llr.toFixed(2) : 'sem ancoragem'}`); falhas++; }
  }
}
console.log(falhas ? `\n${falhas} entrada(s) não se reconhecem a partir do próprio valor.\n` : 'autoteste: toda entrada verificada se reconhece a partir do próprio valor.\n');
