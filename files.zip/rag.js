'use strict';
/* UROBOROS · URB2 — recuperação métrica (substitui o TensorRAG5D)
 *
 * ═══ POR QUE O MODELO ORIGINAL É INERTE ═══
 *
 * Com M = I + λ(q⊗q) e δ = x − q, decompondo δ em paralelo/perpendicular a q:
 *
 *     ds² = ‖δ⊥‖² + (1 + λ‖q‖²)·δ∥²
 *
 * O termo ESTICA ao longo da consulta. M é PSD, logo λ(q·δ)² ≥ 0 sempre:
 * a métrica nunca encurta distância, e portanto não existe garganta nem atalho.
 *
 * Pior: com embeddings normalizados (‖x‖=‖q‖=1), pondo t = 1 − cos,
 *
 *     ds² = 2t + λt²
 *
 * que é monótona crescente em t para todo λ > −1. O ranking é IDÊNTICO ao do
 * cosseno — medido: Kendall τ = 1,000000 para λ ∈ {0,01 … 100}. Abaixo de
 * λ = −1 a monotonicidade quebra e o ranking inverte (τ = −1).
 *
 * E toda métrica CONSTANTE é plana: ds² = δᵀMδ = ‖M^{1/2}δ‖², ou seja,
 * Euclidiana após um mapa linear fixo. Riemann ≡ 0. Sem curvatura não há
 * topologia não trivial, logo não há ponte de Einstein-Rosen.
 *
 * ═══ O QUE FUNCIONA ═══
 *
 * (1) BRANQUEAMENTO PARCIAL. Σ = VΛVᵀ dos documentos; M(α) = V Λ^(−α) Vᵀ.
 *     α = 0 → L2/cosseno · α = 1 → branqueamento total. É o botão que λ
 *     queria ser: desinfla as direções de maior variância, que são justamente
 *     as que separam domínios. Mesma ideia do w* = Σ⁻¹1 do resto do URB2.
 *
 * (2) PRÉ-FATORAÇÃO. Como M é constante, fatora-se M = RᵀR uma vez e
 *     transforma-se o corpus: x̃ = Rx. Aí ds² = ‖x̃ − q̃‖², e o custo cai de
 *     O(N·d²) por consulta para O(N·d) — o mesmo do produto interno.
 *     A contração tensorial por consulta do artigo é d× mais cara para o
 *     mesmo resultado (d = 768 → 768×).
 *
 * (3) GEODÉSICA EM GRAFO kNN. É a versão honesta do "atalho topológico":
 *     distância geodésica ao longo do corpus, que enxerga corredores de
 *     documentos interdisciplinares que a distância direta não vê.
 *
 * (4) PONTES DE GRAFO — com o bug corrigido. No código original,
 *     `retrieved_set` já tem top_k antes dos append, e o `[:top_k]` final
 *     descarta 100% das pontes: o único recurso novo do artigo nunca executa.
 */

const { jacobiEigen } = require('./estimador');

const dot = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; };
const l2 = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) { const d = a[i] - b[i]; s += d * d; } return s; };
const normalizar = v => { const n = Math.hypot(...v) || 1; return v.map(x => x / n); };

/* ---------- covariância e métrica ---------- */
function covariancia(X) {
  const n = X.length, d = X[0].length;
  const mu = new Array(d).fill(0);
  for (const v of X) for (let i = 0; i < d; i++) mu[i] += v[i] / n;
  const S = Array.from({ length: d }, () => new Array(d).fill(0));
  for (const v of X) for (let i = 0; i < d; i++) for (let j = 0; j < d; j++) S[i][j] += (v[i] - mu[i]) * (v[j] - mu[j]) / Math.max(1, n - 1);
  return { S, mu };
}

/** R tal que RᵀR = M(α) = V Λ^(−α) Vᵀ. Devolve R = Λ^(−α/2) Vᵀ (aplicável a vetores). */
function fatorMetrica(S, alpha = 0.5, eps = 1e-3) {
  const { values, vectors } = jacobiEigen(S);
  const n = S.length;
  const tr = values.reduce((a, b) => a + b, 0) / n || 1;
  const R = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let k = 0; k < n; k++) {
    const lk = Math.pow(Math.max(values[k], eps * tr) / tr, -alpha / 2);
    for (let j = 0; j < n; j++) R[k][j] = lk * vectors[k][j];
  }
  return { R, espectro: values, fracaoTopo: values[0] / values.reduce((a, b) => a + b, 0) };
}
const aplicar = (R, v) => R.map(row => dot(row, v));

/* ---------- índice ---------- */
class IndiceMetrico {
  /**
   * @param opts.alpha       0 = cosseno/L2 · 1 = branqueamento total. Botão real.
   * @param opts.normalizar  L2-normaliza antes de indexar (padrão true)
   * @param opts.pontes      {i: [j,k,...]} arestas de grafo de conhecimento
   */
  constructor(vetores, textos, opts = {}) {
    this.alpha = opts.alpha ?? 0.35;
    this.norm = opts.normalizar !== false;
    this.pontes = opts.pontes || {};
    this.textos = textos || vetores.map((_, i) => `doc${i}`);
    this.meta = opts.meta || null;
    this.docs = this.norm ? vetores.map(normalizar) : vetores.map(v => v.slice());
    this.d = this.docs[0].length;

    const { S } = covariancia(this.docs);
    const f = fatorMetrica(S, this.alpha);
    this.R = f.R;
    this.espectro = f.espectro;
    this.fracaoTopo = f.fracaoTopo;         // quanto da variância está no modo dominante
    this.proj = this.docs.map(v => aplicar(this.R, v));   // pré-fatoração: O(N·d) por consulta
    this.grafo = null;
  }

  /** Constrói o grafo kNN no espaço já transformado (necessário p/ geodésica). */
  construirGrafo(k = 8) {
    const N = this.proj.length;
    const adj = Array.from({ length: N }, () => []);
    for (let i = 0; i < N; i++) {
      const viz = this.proj.map((x, j) => ({ j, w: Math.sqrt(l2(this.proj[i], x)) }))
        .filter(o => o.j !== i).sort((a, b) => a.w - b.w).slice(0, k);
      for (const o of viz) { adj[i].push([o.j, o.w]); adj[o.j].push([i, o.w]); }
    }
    // pontes declaradas entram como arestas de peso reduzido — é o "atalho",
    // sem nenhuma pretensão de buraco de minhoca
    for (const [i, alvos] of Object.entries(this.pontes)) {
      for (const j of alvos) {
        if (j === +i || j >= N) continue;
        const w = Math.sqrt(l2(this.proj[+i], this.proj[j])) * (this.pesoPonte ?? 0.35);
        adj[+i].push([j, w]); adj[j].push([+i, w]);
      }
    }
    this.grafo = adj;
    return this;
  }

  /** Distância métrica direta. */
  distancias(consulta) {
    const q = aplicar(this.R, this.norm ? normalizar(consulta) : consulta);
    return this.proj.map(x => l2(x, q));
  }

  /** Distância geodésica: Dijkstra a partir da consulta ligada aos seus k vizinhos. */
  geodesicas(consulta, k = 8) {
    if (!this.grafo) this.construirGrafo(k);
    const q = aplicar(this.R, this.norm ? normalizar(consulta) : consulta);
    const N = this.proj.length;
    const viz = this.proj.map((x, j) => ({ j, w: Math.sqrt(l2(x, q)) })).sort((a, b) => a.w - b.w).slice(0, k);
    const adj = this.grafo.map(a => a.slice());
    adj.push(viz.map(o => [o.j, o.w]));
    for (const o of viz) adj[o.j] = [...adj[o.j], [N, o.w]];

    const dist = new Array(N + 1).fill(Infinity), vis = new Array(N + 1).fill(false);
    dist[N] = 0;
    for (let it = 0; it <= N; it++) {
      let b = -1, bd = Infinity;
      for (let i = 0; i <= N; i++) if (!vis[i] && dist[i] < bd) { bd = dist[i]; b = i; }
      if (b < 0) break;
      vis[b] = true;
      for (const [j, w] of adj[b]) if (dist[b] + w < dist[j]) dist[j] = dist[b] + w;
    }
    return dist.slice(0, N);
  }

  /**
   * @param opts.modo      'metrica' | 'geodesica'
   * @param opts.expandir  nº extra de vizinhos de grafo a trazer ALÉM do top_k
   *                       (o bug do artigo era truncar isso de volta a top_k)
   */
  recuperar(consulta, topK = 5, opts = {}) {
    const modo = opts.modo || 'metrica';
    const d = modo === 'geodesica' ? this.geodesicas(consulta, opts.k || 8) : this.distancias(consulta);
    const ordem = d.map((v, i) => i).sort((a, b) => d[a] - d[b]);
    const base = ordem.slice(0, topK);

    // expansão por ponte: reescorada e ORÇADA, nunca descartada
    const extra = [];
    const orc = opts.expandir ?? 0;
    if (orc > 0) {
      const vistos = new Set(base);
      for (const i of base) for (const j of (this.pontes[i] || [])) {
        if (vistos.has(j) || j >= d.length) continue;
        vistos.add(j); extra.push({ i: j, d: d[j], via: i });
      }
      extra.sort((a, b) => a.d - b.d);
    }
    const sel = [...base.map(i => ({ i, d: d[i], via: null })), ...extra.slice(0, orc)];
    return sel.map(o => ({
      indice: o.i, texto: this.textos[o.i], distancia: +o.d.toFixed(6),
      viaPonte: o.via, meta: this.meta ? this.meta[o.i] : null
    }));
  }

  info() {
    return {
      documentos: this.docs.length, dimensao: this.d, alpha: this.alpha,
      fracaoModoDominante: +this.fracaoTopo.toFixed(4),
      custoPorConsulta: `O(N·d) = ${(this.docs.length * this.d / 1e6).toFixed(2)}M`,
      custoContracaoTensorial: `O(N·d²) = ${(this.docs.length * this.d * this.d / 1e9).toFixed(2)}G`,
      pontes: Object.keys(this.pontes).length
    };
  }
}

/* ---------- porte fiel do artigo, para comparação ---------- */
function tensorRAG5D_paper(docs, consulta, lambda = 0.01) {
  const d = consulta.length;
  const M = Array.from({ length: d }, (_, i) => Array.from({ length: d }, (_, j) => (i === j ? 1 : 0) + lambda * consulta[i] * consulta[j]));
  let fro = 0; for (const r of M) for (const x of r) fro += x * x; fro = Math.sqrt(fro);
  const Mn = M.map(r => r.map(x => x / fro));
  return docs.map(x => {
    const dl = x.map((v, i) => v - consulta[i]);
    let s = 0;
    for (let i = 0; i < d; i++) { let t = 0; for (let j = 0; j < d; j++) t += Mn[i][j] * dl[j]; s += dl[i] * t; }
    return s;
  });
}

module.exports = { IndiceMetrico, covariancia, fatorMetrica, aplicar, normalizar, tensorRAG5D_paper };
