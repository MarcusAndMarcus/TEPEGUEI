'use strict';
/* UROBOROS · URB2 — conectores de âncora em rede
 *
 * REGRA DE OURO: estes conectores são chamados em L2 (verificação de
 * alegação), NUNCA em L0 (contexto do prompt). Injetar a mesma passagem
 * recuperada nas N células eleva ρ e colapsa N_eff — medido: ρ_inter
 * 0,09 → 0,50 e N_eff 6,0 → 1,9 com peso de contexto 0,45.
 *
 * Consulta a catálogo estruturado (SIMBAD, Gaia, VizieR) devolve NÚMERO, e a
 * comparação é aritmética: ρ ≈ 0 com todas as famílias de LLM, que é
 * exatamente o que ataca o viés compartilhado. Texto (arXiv) exige juiz para
 * julgar implicação, o que reintroduz correlação — por isso tipo 'texto' tem
 * ρ = 0,18, teto de LLR menor e NÃO pode vetar.
 *
 * SEGURANÇA: o conteúdo recuperado é DADO, nunca instrução. Nada que vier de
 * um catálogo ou de um abstract altera o comportamento do pipeline; só entra
 * como valor a ser comparado.
 *
 * Não testável offline. Todos usam apenas fetch global (Node ≥ 18).
 */

const { llrGaussiano, TIPOS } = require('./ancora');

const UA = { 'user-agent': 'UROBOROS-URB2/2.2 (+contato)' };

async function getJSON(url, timeoutMs = 15000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const r = await fetch(url, { headers: UA, signal: ac.signal });
    if (!r.ok) throw new Error(`${r.status}`);
    return await r.json();
  } finally { clearTimeout(t); }
}
async function getText(url, timeoutMs = 15000) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const r = await fetch(url, { headers: UA, signal: ac.signal });
    if (!r.ok) throw new Error(`${r.status}`);
    return await r.text();
  } finally { clearTimeout(t); }
}

/* ---------- SIMBAD (TAP/ADQL) ---------- */
const SIMBAD_TAP = 'https://simbad.cds.unistra.fr/simbad/sim-tap/sync';

function simbadURL(adql) {
  const p = new URLSearchParams({ request: 'doQuery', lang: 'adql', format: 'json', maxrec: '20', query: adql });
  return `${SIMBAD_TAP}?${p}`;
}

/** Coordenadas, tipo e magnitude de um objeto nomeado. */
async function simbadObjeto(nome) {
  const safe = String(nome).replace(/'/g, "''").slice(0, 80);
  const adql = `SELECT TOP 1 b.main_id, b.ra, b.dec, b.otype_txt, b.plx_value, b.plx_err, b.rvz_redshift
                FROM basic AS b JOIN ident AS i ON b.oid = i.oidref
                WHERE i.id = '${safe}'`;
  const j = await getJSON(simbadURL(adql));
  const d = j?.data?.[0];
  if (!d) return null;
  const cols = (j.metadata || []).map(m => m.name);
  const o = Object.fromEntries(cols.map((c, k) => [c, d[k]]));
  return { main_id: o.main_id, ra: o.ra, dec: o.dec, tipo: o.otype_txt, paralaxe: o.plx_value, paralaxeErr: o.plx_err, z: o.rvz_redshift };
}

/* ---------- Gaia (ESA TAP) ---------- */
const GAIA_TAP = 'https://gea.esac.esa.int/tap-server/tap/sync';

async function gaiaCone(ra, dec, raioArcsec = 5, limite = 5) {
  const r = raioArcsec / 3600;
  const adql = `SELECT TOP ${limite} source_id, ra, dec, parallax, parallax_error, phot_g_mean_mag
                FROM gaiadr3.gaia_source
                WHERE 1=CONTAINS(POINT('ICRS',ra,dec), CIRCLE('ICRS',${ra},${dec},${r}))
                ORDER BY phot_g_mean_mag ASC`;
  const p = new URLSearchParams({ REQUEST: 'doQuery', LANG: 'ADQL', FORMAT: 'json', QUERY: adql });
  const j = await getJSON(`${GAIA_TAP}?${p}`, 25000);
  const cols = (j.metadata || []).map(m => m.name);
  return (j.data || []).map(row => Object.fromEntries(cols.map((c, k) => [c, row[k]])));
}

/* ---------- VizieR (TAP) ---------- */
const VIZIER_TAP = 'https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync';

async function vizierQuery(adql, limite = 20) {
  const p = new URLSearchParams({ request: 'doQuery', lang: 'adql', format: 'json', maxrec: String(limite), query: adql });
  const j = await getJSON(`${VIZIER_TAP}?${p}`, 25000);
  const cols = (j.metadata || []).map(m => m.name);
  return (j.data || []).map(row => Object.fromEntries(cols.map((c, k) => [c, row[k]])));
}

/* ---------- arXiv (Atom) ---------- */
async function arxivBusca(termo, max = 5) {
  const p = new URLSearchParams({ search_query: `all:${termo}`, start: '0', max_results: String(max), sortBy: 'relevance' });
  const xml = await getText(`http://export.arxiv.org/api/query?${p}`, 20000);
  const out = [];
  for (const m of xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)) {
    const e = m[1];
    const g = (tag) => (new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`).exec(e)?.[1] || '').replace(/\s+/g, ' ').trim();
    out.push({ id: g('id'), titulo: g('title'), resumo: g('summary').slice(0, 1200), publicado: g('published') });
  }
  return out;
}

/* ================= fábricas de fonte para a Âncora ================= */

/**
 * Fonte estruturada genérica: extrai (grandeza, valor) da alegação com o
 * extrator da tabela, consulta o catálogo, e pontua por razão de
 * verossimilhança gaussiana — a mesma álgebra da âncora local.
 *
 * @param consultar (grandeza, mencao) => Promise<{valor, sigma, fonte}|null>
 */
function fonteEstruturada({ id, tabela, consultar, tipo = 'catalogo' }) {
  const cfg = TIPOS[tipo];
  return {
    id, tipo,
    async verificar(claimTexto) {
      const mencoes = tabela.extrair(claimTexto);
      if (!mencoes.length) return null;
      let melhor = null;
      for (const m of mencoes) {
        const ref = await consultar(m.grandeza, m);
        if (!ref || ref.valor == null) continue;
        const sig = Math.max(1e-30, Math.hypot(ref.sigma || Math.abs(ref.valor) * 1e-3, Math.abs(m.valor) * 1e-3));
        const z = Math.abs(m.valor - ref.valor) / sig;
        const llr = Math.max(-cfg.teto * 3, Math.min(cfg.teto, llrGaussiano(z)));
        if (!melhor || llr < melhor.llr) melhor = { llr, z: +z.toFixed(3), fonte: ref.fonte || id, detalhe: `${m.grandeza}: ${m.valor} vs ${ref.valor}` };
      }
      if (!melhor) return null;
      return { ...melhor, veto: cfg.podeVetar && melhor.z > 5 };
    }
  };
}

/**
 * Fonte de texto: recupera, e só então julga implicação com um modelo de
 * família DIFERENTE da que originou a alegação. Teto baixo e sem veto —
 * o juiz é um LLM, logo correlacionado com as células.
 */
function fonteTexto({ id, buscar, julgar, familiaJuiz }) {
  const cfg = TIPOS.texto;
  return {
    id, tipo: 'texto', familiaJuiz,
    async verificar(claimTexto) {
      const docs = await buscar(claimTexto);
      if (!docs?.length) return null;
      const v = await julgar(claimTexto, docs);      // -> {relacao: 'implica'|'contradiz'|'neutro', ref}
      if (!v || v.relacao === 'neutro') return null;
      const llr = v.relacao === 'implica' ? cfg.teto * 0.6 : -cfg.teto;
      return { llr, veto: false, fonte: v.ref || id, detalhe: `${id}: ${v.relacao}` };
    }
  };
}

module.exports = {
  simbadObjeto, simbadURL, gaiaCone, vizierQuery, arxivBusca,
  fonteEstruturada, fonteTexto, getJSON, getText
};
