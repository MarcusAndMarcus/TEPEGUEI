'use strict';
/* UROBOROS · URB2 — abstenção calibrada por predição conformal
 *
 * O limiar "emite se confiança > 0.8" é chute. Predição conformal dá
 * GARANTIA DISTRIBUTION-FREE, sem hipótese sobre a distribuição do escore:
 *
 *   Dado um conjunto de calibração de n exemplos com resposta conhecida e
 *   escore de não-conformidade s_i, defina
 *       q̂ = quantil de nível ⌈(n+1)(1-α)⌉/n dos {s_i}
 *   Então, para um novo exemplo trocável com os de calibração,
 *       P(s_{n+1} ≤ q̂) ≥ 1 - α.
 *
 *   Emitindo apenas quando s ≤ q̂, a taxa de erro fica ≤ α por construção.
 *   Não é heurística: é cobertura marginal garantida em amostra finita.
 *
 * MONDRIAN: calibra-se por perfil de domínio (o UROBOROS já tem perfis).
 * Isso troca cobertura marginal por cobertura CONDICIONAL ao domínio, que é
 * o que importa — α=0.1 global não serve se física tem 2% de erro e
 * jurisprudência tem 30%.
 *
 * Escore de não-conformidade usado (composto, tudo em [0,∞), menor = melhor):
 *     s = a·(1-p_BP) + b·H̃_sem + c·(1 - N_orig/N_fam) + d·1[verificador silente]
 */

const fs = require('fs');
const path = require('path');

class Conformal {
  constructor({ alpha = 0.10, minCal = 30, file = null } = {}) {
    this.alpha = alpha;
    this.minCal = minCal;
    this.file = file;
    this.cal = new Map();               // domínio -> [scores de exemplos CORRETOS]
    this.errs = new Map();              // domínio -> [scores de exemplos ERRADOS] (diagnóstico)
    if (file && fs.existsSync(file)) this.load();
  }

  static score(m, w = { p: 1.0, H: 0.8, orig: 0.6, ver: 0.5 }) {
    const pBP = Math.min(1, Math.max(0, m.p ?? 0.5));
    const H = Math.min(1, Math.max(0, m.Hnorm ?? 1));
    const origFrac = Math.min(1, Math.max(0, (m.nOrigins ?? 0) / Math.max(1, m.nFamilies ?? 1)));
    const verSilent = m.verifierChecked ? 0 : 1;
    const s = w.p * (1 - pBP) + w.H * H + w.orig * (1 - origFrac) + w.ver * verSilent;
    return s / (w.p + w.H + w.orig + w.ver);
  }

  observe(domain, score, correct) {
    const d = domain || '_';
    const bag = correct ? this.cal : this.errs;
    if (!bag.has(d)) bag.set(d, []);
    const arr = bag.get(d);
    arr.push(score);
    if (arr.length > 5000) arr.shift();
    return this;
  }

  /** q̂ do domínio; cai para o pool global se não houver amostras suficientes. */
  qhat(domain, alpha = this.alpha) {
    let arr = this.cal.get(domain || '_') || [];
    let scope = domain || '_';
    if (arr.length < this.minCal) { arr = [...this.cal.values()].flat(); scope = 'global'; }
    if (arr.length < 5) return { q: 0.35, n: arr.length, scope: 'default', calibrated: false };
    const s = [...arr].sort((a, b) => a - b);
    const n = s.length;
    const k = Math.ceil((n + 1) * (1 - alpha));
    const q = k > n ? s[n - 1] : s[k - 1];
    return { q, n, scope, calibrated: true };
  }

  /**
   * emitir | ressalvar | abster
   * A faixa intermediária (entre q̂ de α e de α/3) é onde vale escalar para
   * mais células ou para recuperação externa, em vez de calar.
   */
  decide(domain, score) {
    // q̂ é o quantil (1-α): α menor ⇒ quantil maior ⇒ limiar MAIS PERMISSIVO.
    // Emitir usa α (erro ≤ α garantido). Ressalvar estende até α/4.
    const hard = this.qhat(domain, this.alpha);
    const soft = this.qhat(domain, Math.max(0.005, this.alpha / 4));
    let action = 'abster';
    if (score <= hard.q) action = 'emitir';
    else if (score <= soft.q) action = 'ressalvar';
    return { action, score: +score.toFixed(4), qEmitir: +hard.q.toFixed(4), qRessalvar: +soft.q.toFixed(4), n: hard.n, scope: hard.scope, calibrated: hard.calibrated };
  }

  /** Cobertura empírica observada — sanidade da calibração. */
  audit(domain) {
    const d = domain || '_';
    const ok = this.cal.get(d) || [], bad = this.errs.get(d) || [];
    const { q } = this.qhat(d);
    const emittedOk = ok.filter(s => s <= q).length;
    const emittedBad = bad.filter(s => s <= q).length;
    const emitted = emittedOk + emittedBad;
    return {
      dominio: d, nCorretos: ok.length, nErrados: bad.length, qhat: +q.toFixed(4),
      coberturaCorretos: ok.length ? emittedOk / ok.length : null,  // deve ≈ 1-α (a garantia)
      coberturaAlvo: 1 - this.alpha,
      taxaEmissao: emitted / Math.max(1, ok.length + bad.length),
      precisaoEmitida: emitted ? emittedOk / emitted : null
    };
  }

  save(file = this.file) {
    if (!file) return;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify({ alpha: this.alpha, cal: [...this.cal], errs: [...this.errs] }));
  }

  load(file = this.file) {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    this.cal = new Map(j.cal || []);
    this.errs = new Map(j.errs || []);
    if (typeof j.alpha === 'number') this.alpha = j.alpha;
    return this;
  }
}

module.exports = { Conformal };
