# UROBOROS · URB2

Cluster multi-IA com propagação de crença, entropia semântica e abstenção conformal.
Zero dependências npm. Node ≥ 18. Termux → GitHub → Render.

```
lib/providers.js   10 provedores, 8 famílias, token bucket por free tier
lib/graph.js       espectro do anel-com-cordas, escolha ótima de cordas
lib/estimador.js   Σ estruturada em blocos, Jacobi, diagnóstico de modo comum
lib/ancora.js      âncora externa: verificação numérica por razão de verossimilhança
lib/conectores.js  SIMBAD · Gaia · VizieR · arXiv como fontes de nível de alegação
lib/epistemic.js   entropia semântica, Σ de erro, N_eff, pesos GLS, Dawid–Skene
lib/bp.js          propagação de crença em LLR, extrínseco, deflação, veto
lib/conformal.js   abstenção com garantia distribution-free, Mondrian por domínio
lib/verifier.js    Polo V estendido: aritmética sem eval, dimensional, datas
lib/urb2.js        telegrama v2 com máscara de origem + CRC16-CCITT
orchestrator.js    pipeline L0→L6 + servidor SSE
tools/teste.js          50 testes offline, sem chave de API
tools/gerar-bench.js    itens com gabarito calculado, custo de rotulação zero
tools/calibrar.js       Σ empírica + calibração conformal, em duas fases, resumível
tools/verificar-tabela.js  auditoria da âncora: o que falta conferir
data/tabela.json        parâmetros publicados com σ e flag de verificação
```

---

## 1. O diagnóstico

O URB1 tinha dez células e duas famílias (Claude, Gemini). Erros de LLM não são
independentes — corpora de pré-treino se sobrepõem massivamente. Para pesos `w`
e covariância de erro `Σ`:

```
N_eff = (v̄ · (Σwᵢ)²) / (wᵀ Σ w)      →   N/(1 + (N-1)ρ)  no caso homogêneo
```

Com ρ_intra ≈ 0.85 e ρ_inter ≈ 0.28, **10 células / 2 famílias dão N_eff ≈ 1.7**.
Dez chamadas de API, uma testemunha e três quartos. Passar para 16 células em
8 famílias leva a N_eff ≈ 2.8 — +63% com custo de API comparável.

A conclusão operacional: **heterogeneidade de família domina número de células.**
Adicionar a nona réplica de Claude compra ~0.01 de N_eff. Adicionar Mistral compra ~0.4.

## 2. Os três modos de falha estruturais

### R1 · Lavagem de alucinação

Num gossip em anel, a célula 3 inventa X, X circula, e volta à célula 3 como
"três pares concordam". A confiança sobe, a verdade não. É o análogo exato do
problema que a decodificação turbo resolve com **informação extrínseca**.

Correção: o telegrama URB2 carrega `originMask` de 32 bits. Nenhuma célula
recebe de volta evidência que ela mesma originou, e a contagem de testemunhas
é `popcount(mask)`, não número de mensagens. Um eco quádruplo continua valendo
uma origem.

### R2 · Concordância correlacionada contada como independente

LLRs da mesma família são somados e depois divididos por `1 + (m-1)ρ`.
Quatro células a favor com L=2 cada:

| configuração | LLR total | p |
|---|---|---|
| 4× mesma família (ρ=0.85) | 2.25 | 0.905 |
| 4 famílias distintas | 8.00 | 0.9997 |

Dois Claudes concordando não são duas testemunhas.

### R3 · Consenso elegante e errado

O aviso teórico que justifica a arquitetura toda: o consenso por gossip contrai
a **variância** como λ₂ᵀ, mas o **viés compartilhado** vive no autovetor de
λ₁ = 1 e **não contrai nunca**. Mais rodadas de consenso deixam o cluster mais
confiante numa alucinação compartilhada, não menos.

Viés só sai por dois caminhos: heterogeneidade de família (§1) e âncora externa
determinística. O Polo V é o único nó com direito de veto — `L = −L_MAX`, e
nenhuma quantidade de concordância entre modelos revoga aritmética.

## 3. A armadilha topológica

O anel-com-cordas é um grafo circulante `C_n(S)` com autovalores fechados:

```
λ_k = (1/2|S|) Σ_{s∈S} 2 cos(2πks/n),   λ₂ = max_{k≥1} |λ_k|,   T ≥ log ε / log λ₂
```

**Se todos os saltos forem ímpares, o grafo é bipartido, existe λ_k = −1 e o
gossip oscila para sempre.** `C₁₀(1,3)` — o anel-com-cordas óbvio — cai
exatamente nisso: λ₂ = 1.0000, T = ∞.

| topologia | grau | λ₂ | rodadas (ε=1e-2) |
|---|---|---|---|
| C₁₀(1,3) | 4 | **1.0000** | **∞** |
| C₁₀(1,2) | 4 | 0.5590 | 8 |
| C₁₀(1,2,3) | 6 | 0.4363 | 6 |
| C₁₆(1,6) | 4 | 0.8155 | 23 |
| **C₁₆(1,3,4)** | **6** | **0.4355** | **6** |
| C₁₆(1,4,7,8) | 8 | 0.5000 | 7 |

Grau 8 é *pior* que grau 6 em n=16. `node lib/graph.js 16` faz a busca exaustiva.

## 4. Detecção de alucinação: entropia semântica

Entropia sobre **classes de significado**, não sobre tokens (Farquhar et al.,
*Nature* 2024). "Paris" e "A capital é Paris" são o mesmo evento; 67.4 e 73.0
não são. Clusteriza por implicação bidirecional via juiz NLI barato (Groq),
com fallback determinístico que inclui **trava numérica**: números
significativos conflitantes forçam clusters distintos, mesmo com redação
quase idêntica.

```
H̃ = H / ln N ∈ [0,1]
```

H̃ alto = incerteza epistêmica, o sinal primário de confabulação. Num teste com
as duas medidas de H₀, o clusterizador separa Planck de SH0ES corretamente:
2 clusters, H̃ = 1.0, massa modal 0.5 — que é a leitura certa da tensão de Hubble.

## 5. Abstenção com garantia, não com chute

"Emite se confiança > 0.8" é chute. Predição conformal split dá garantia
distribution-free em amostra finita:

```
q̂ = quantil de nível ⌈(n+1)(1−α)⌉/n dos escores de calibração
P(s_{novo} ≤ q̂) ≥ 1 − α
```

Emitindo só quando `s ≤ q̂`, a taxa de erro fica ≤ α **por construção**.
Auditoria empírica com 500 amostras: cobertura 0.903 contra alvo 0.900.

Calibração **Mondrian** por perfil de domínio — cobertura condicional ao
domínio, que é o que importa: α = 0.10 global não serve se física tem 2% de
erro e jurisprudência tem 30%. Cai para o pool global quando falta amostra.

Escore de não-conformidade composto:
```
s = a·(1−p_BP) + b·H̃_sem + c·(1 − N_orig/N_fam) + d·1[verificador silente]
```

Três faixas: **emitir** (s ≤ q̂(α)) · **ressalvar** (s ≤ q̂(α/4)) · **abster**.

## 6. Papéis, não só temperaturas

Diversificar a amostragem não basta — é preciso diversificar o *prior*. Seis
papéis: `solver`, `skeptic`, `adversarial`, `formalist`, `empirical`,
`minimalist`. O papel adversarial é anti-cascata de confirmação: sua tarefa é
falsificar, e apontar pressuposto falso na pergunta.

## 7. Pipeline

```
L0 amostragem     N células × k amostras, temperatura espalhada, papéis distintos
L1 atomização     resposta → alegações atômicas + confiança declarada (teto 0.93)
L2 Polo V         verificação determinística; veto absoluto
L3 entropia sem.  clusteriza por implicação; H̃ global
L4 crença         BP no grafo alegação×célula: extrínseco + deflação + amortecimento
L5 conformal      escore → emitir / ressalvar / abster
L6 síntese        redação só com alegações sobreviventes; rejeitadas proibidas
```

Cada estágio emite evento SSE. `?formato=texto` devolve texto limpo para a
camada de voz (M01 Pro / Tasker / AutoVoice).

## 8. Uso

```bash
cp .env.example .env        # cada chave presente vira uma família
node tools/teste.js         # 29 testes, sem API
node lib/graph.js 16        # busca topológica
node orchestrator.js        # servidor SSE
```

```
GET /info                          configuração e N_eff atual
GET /topologia                     ranking de cordas
GET /consulta?q=...&dominio=...    SSE
GET /consulta?q=...&formato=texto  texto puro (voz)
```

## 9. Calibração — o passo que converte teoria em garantia

Sem isto, Σ é prior e q̂ é default. O gargalo real não é computação, é
**rotulação** — e é ele que mantém Σ como chute indefinidamente.

### O atalho: gabarito calculado, não consultado

`tools/gerar-bench.js` emite itens cujo gabarito é **derivado**, não procurado:
ρ_crit a partir de H₀, idade ΛCDM, E(z), distância comóvel por Simpson, D_V de
BAO, S₈, q₀, tensão em σ, escala de T(z) — mais aritmética, álgebra, trabalho,
potência, meia-vida e data.

O ponto de projeto: **os parâmetros são sorteados a cada item.** H₀ = 68,31 e
não 67,36. Memorização não ajuda; só derivação. O que se mede é o canal de
raciocínio, com custo de rotulação zero e julgamento determinístico — sem
chamadas de juiz e sem viés de juiz.

Julgar exige um filtro anti-eco: só contam números da resposta que **não
aparecem no enunciado**. Sem ele, repetir os parâmetros de entrada seria
contado como acerto.

O que isto não cobre é recuperação factual. Para essa, itens curados com fonte
primária continuam necessários — mas Σ do canal de raciocínio já basta para os
pesos GLS e para o N_eff.

### Duas fases, porque custam coisas diferentes

| fase | o que roda | chamadas/item | itens necessários |
|---|---|---|---|
| `sigma` | só L0 + julgamento | N | 60–240 |
| `conformal` | pipeline completo | ~2N+2 | 40–100 |

Σ é propriedade das **células**, não do pipeline — não precisa de atomização,
BP, entropia nem síntese. Separar as fases corta o custo da parte cara.

```bash
node tools/gerar-bench.js 240 42 > bench/sintetico.json
node tools/calibrar.js --fase sigma     --bench bench/sintetico.json
node tools/calibrar.js --fase conformal --bench bench/sintetico.json --n 80
node tools/calibrar.js --relatorio
```

Resumível: cada item é gravado em JSONL na hora, e reexecutar continua de onde
parou — requisito, não conforto, num tablet que mata processo longo. O custo em
chamadas e o gargalo de RPM são impressos antes de começar.

### Σ estruturada, não Σ cheia

Σ cheia com N=16 tem 136 parâmetros livres. Estimar 136 com T=100 é ruído: a
matriz sai mal condicionada, `w* = Σ⁻¹1` explode, e a "otimização" piora o
cluster. A estrutura de família é um prior forte e verdadeiro, então ajusta-se
um modelo em blocos — f variâncias, f correlações intra, f(f−1)/2 inter — com
encolhimento hierárquico (bloco → média do tipo → média global) ponderado por
n·T, não por n. Um único par medido em 300 questões é um estimador forte.

Convergência medida contra verdade em T=40.000:

| T | ρ intra | ρ inter | **N_eff** | fração comum |
|---|---|---|---|---|
| 60 | 0,424 | 0,185 | **3,19** | 0,322 |
| 120 | 0,446 | 0,193 | **3,11** | 0,327 |
| 300 | 0,512 | 0,160 | **3,24** | 0,315 |
| 40.000 | 0,582 | 0,156 | **3,17** | 0,307 |

As correlações individuais convergem devagar. **N_eff é estável já em T=60** —
o número que mais importa é o mais barato de obter. Rodar 60 itens hoje e
refinar ρ depois é a ordem certa.

### φ binário, não ρ latente

A correlação medida em acerto/erro é o coeficiente φ, e ele é bem menor que a
intuição de "similaridade semântica" sugere: no teste acima, ρ latente 0,80
aparece como φ = 0,58. **φ é a quantidade certa** — é ela que aparece em
Var((1/N)Σeᵢ) e, portanto, em N_eff e na deflação de LLR. A tetracórica entra
só no relatório, por ser invariante à taxa base e comparável entre domínios
fáceis e difíceis.

### O número que a calibração existe para produzir

O autovetor dominante de Σ é a direção de erro comum — o viés b da §3. A razão

```
fracaoComum = λ₁ / tr(Σ)
```

diz que fração da variância de erro do cluster é modo comum, e portanto
**irremovível por qualquer média, com qualquer peso, com qualquer número de
células**. O relatório também imprime `tetoNeff = tr(Σ)/λ₁`: o limite superior
absoluto desta configuração. Se N_eff já está perto do teto, adicionar células
é desperdício e a única saída é mudar a composição de famílias ou trazer
âncora externa.

O relatório lista, por célula, taxa de erro, peso GLS e carga no modo comum.
Peso GLS ≈ 0 significa redundante: desligar economiza quota sem perder N_eff.

## 10. Âncora externa

`fracaoComum` mede exatamente o que N_eff não alcança. A única saída é evidência
que **não esteja no span gerado pelas células**.

### RAG como contexto é o modo de falha, não a cura

Injetar a passagem recuperada no prompt das N células faz todas condicionarem na
mesma informação. A dispersão cai, a "confiança do consenso" sobe, e o viés da
passagem entra inteiro em *b*. Simulado com 16 células em 8 famílias, T=3000:

| cenário | erro | ρ inter | **N_eff** | fração comum |
|---|---|---|---|---|
| sem recuperação | 25,2% | 0,092 | **6,00** | 0,167 |
| contexto injetado, 85% correto | 16,8% | 0,503 | **1,85** | 0,543 |
| contexto injetado, 60% correto | 32,9% | 0,585 | **1,62** | 0,619 |

A taxa de erro melhora — e o cluster fica cego. N_eff despenca de 6,0 para 1,9 e
mais da metade do erro residual vira modo comum, invisível ao consenso e
irremovível por média. Para um sistema cujo propósito é *detectar* alucinação,
é o pior negócio possível: mais acerto médio, menos capacidade de saber quando
errou.

A âncora só reduz *b* entrando como **verificação posterior**, no nível da
alegação, em L2 — onde o Polo V já opera. É por isso que ela é extensão do
verificador, não etapa de L0.

### Calibração do LLR da âncora

Alegação diz v; a fonte diz μ ± σ. Com z = |v−μ|/σ_ef:

$$L = \ln\!\big(Z\,\varphi(z)\big) = \ln Z - \ln\sqrt{2\pi} - \tfrac{z^2}{2}$$

sob "verdadeira → z ~ N(0,1)" contra "falsa → z difuso em [0,Z]". Com Z = 20:

| z | 0 | 1 | 2 | 3 | 5 |
|---|---|---|---|---|---|
| L | +2,08 | +1,58 | +0,08 | −2,42 | −10,4 |

Concordância dentro de 1σ vale ~1,6 nats; discordância a 5σ é veto. Não é limiar
arbitrário — é a razão de verossimilhança, a mesma álgebra do resto do grafo.

### Tensão não é erro

Com Planck 67,36±0,54 e SH0ES 73,04±1,04 na tabela, uma alegação de 73,0 está
certa em relação a uma medida legítima. A âncora pontua contra a melhor fonte,
marca `tensao` quando as fontes discordam entre si acima de 3σ, e **atenua o LLR
a no máximo +0,80** nesse caso — porque aí "qual fonte" é a questão em disputa e
a âncora não tem autoridade para resolvê-la. Mas a atenuação só vale se a
alegação for plausível sob alguma fonte concorrente: H₀ = 55 continua vetado,
porque estar errado para todas as fontes não se beneficia da briga entre elas.

### Conversão antes de comparar

Checar compatibilidade de unidade não basta. "A idade do universo é 6000 anos"
tem unidade de tempo legítima e passaria batido; convertida para Gyr dá
6×10⁻⁶ contra 13,797 ± 0,023, z ≈ 600, veto. Inversamente, 13797 Myr é aceito.

### A tabela mente se você deixar

`data/tabela.json` traz `verificado` por entrada. **Entradas com `false` nunca
votam nem vetam** — só marcam. É o que permite semear a tabela sem risco de
envenenar a calibração com um valor que eu lembrei errado. `npm run ancora`
lista o que falta conferir contra fonte primária, mostra as tensões, e roda um
autoteste: toda entrada verificada precisa se reconhecer a partir do próprio
valor. Esse autoteste já pegou um envenenamento real — o alias `"137"` de
`alpha_inv` casava *dentro* de 137,035999084 e extraía a cauda como valor novo,
vetando a própria entrada correta.

Pendentes de conferência hoje: `H0_DESI`, `w0`, `wa` (DESI DR2), `A_gwb`
(NANOGrav 15 yr) e `sum_m_nu`. Os valores de Planck 2018, SH0ES 2022, CODATA
2018 e FIRAS estão marcados como verificados — vale conferir por amostragem
antes de confiar em veto.

### Conectores em rede

`lib/conectores.js` traz SIMBAD (TAP/ADQL), Gaia DR3 (cone search), VizieR e
arXiv. Consulta a catálogo devolve **número**, e a comparação é aritmética:
ρ ≈ 0 com todas as famílias de LLM, que é precisamente o que ataca *b*. Texto
(arXiv) exige juiz LLM para julgar implicação, o que reintroduz correlação — por
isso o tipo `texto` tem ρ = 0,18, teto de LLR menor e **não pode vetar**.

Conteúdo recuperado é dado, nunca instrução: nada vindo de catálogo ou abstract
altera o comportamento do pipeline, só entra como valor a ser comparado.

## 11. Depois da calibração

1. **Bench factual curado.** O sintético cobre raciocínio, não recall. Itens com
   `fonte` e `tol` por valor publicado fecham a outra metade.
2. **Cobertura da âncora.** O ponto fraco dela é alcance, não precisão: ela
   abstém em silêncio no que não reconhece. Medir a taxa de ancoragem sobre o
   bench e crescer a tabela pelo que ficou de fora.
3. **Dawid–Skene online.** `Reliability` já rastreia Beta-Bernoulli por
   (célula, domínio); falta realimentar `llrWeight` no prior do BP.
4. **λ₂ adaptativo.** Menos rodadas quando H̃ já está baixo na primeira.
