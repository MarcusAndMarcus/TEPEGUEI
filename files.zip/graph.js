'use strict';
/* UROBOROS · URB2 — topologia do anel com cordas
 *
 * O anel-com-cordas é um grafo circulante C_n(S). Autovalores em forma fechada:
 *
 *     λ_k = (1/d) Σ_{s∈S} 2 cos(2πks/n),   d = 2|S|,  k = 0..n-1
 *
 * λ_0 = 1 sempre (direção de consenso). O que controla a convergência é
 *     λ₂ = max_{k≥1} |λ_k|
 * e o número de rodadas de gossip para erro relativo ε é
 *     T ≥ log ε / log λ₂.
 *
 * ARMADILHA CRÍTICA: se todos os saltos de S forem ÍMPARES, o grafo é
 * bipartido, existe λ_k = -1 e o gossip OSCILA para sempre (não converge).
 * C_10(1,3) — o anel-com-cordas "óbvio" — cai exatamente nisso.
 */

function eigen(n, S) {
  const d = 2 * S.length;
  const ev = [];
  for (let k = 0; k < n; k++) {
    let s = 0;
    for (const c of S) s += 2 * Math.cos((2 * Math.PI * k * c) / n);
    ev.push(s / d);
  }
  return ev;
}

function lambda2(n, S, lazy = 0) {
  // gossip preguiçoso: W' = (1-a)I + aW  =>  λ' = (1-a) + aλ
  const ev = eigen(n, S).slice(1).map(l => (lazy > 0 ? (1 - lazy) + lazy * l : l));
  return Math.max(...ev.map(Math.abs));
}

function mixingTime(n, S, eps = 1e-2, lazy = 0) {
  const l2 = lambda2(n, S, lazy);
  if (l2 >= 1 - 1e-12) return Infinity;
  return Math.ceil(Math.log(eps) / Math.log(l2));
}

/** Busca exaustiva do melhor conjunto de cordas para grau fixo. */
function bestChords(n, degree, eps = 1e-2) {
  const k = degree / 2;
  const cand = [];
  const max = Math.floor(n / 2);
  const rec = (start, acc) => {
    if (acc.length === k) { cand.push(acc.slice()); return; }
    for (let s = start; s <= max; s++) { acc.push(s); rec(s + 1, acc); acc.pop(); }
  };
  rec(1, []);
  return cand
    .map(S => ({ S, lambda2: lambda2(n, S), T: mixingTime(n, S, eps) }))
    .sort((a, b) => a.lambda2 - b.lambda2);
}

/** Matriz de mistura de Metropolis-Hastings (duplamente estocástica). */
function mixingMatrix(n, S, lazy = 0) {
  const adj = Array.from({ length: n }, () => new Set());
  for (let i = 0; i < n; i++) for (const s of S) { adj[i].add((i + s) % n); adj[i].add((i - s + n) % n); }
  const W = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    let off = 0;
    for (const j of adj[i]) { const w = 1 / (1 + Math.max(adj[i].size, adj[j].size)); W[i][j] = w; off += w; }
    W[i][i] = 1 - off;
  }
  if (lazy > 0) for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) W[i][j] = (i === j ? (1 - lazy) : 0) + lazy * W[i][j];
  return W;
}

function neighbors(n, S) {
  return Array.from({ length: n }, (_, i) => {
    const set = new Set();
    for (const s of S) { set.add((i + s) % n); set.add((i - s + n) % n); }
    set.delete(i);
    return [...set].sort((a, b) => a - b);
  });
}

module.exports = { eigen, lambda2, mixingTime, bestChords, mixingMatrix, neighbors };

if (require.main === module) {
  const n = Number(process.argv[2] || 16);
  console.log(`C_${n} — melhores cordas por grau:`);
  for (const d of [4, 6, 8]) {
    const top = bestChords(n, d).slice(0, 3);
    for (const t of top) console.log(`  grau ${d}  S={${t.S}}  λ₂=${t.lambda2.toFixed(4)}  T(ε=1e-2)=${t.T}`);
  }
}
