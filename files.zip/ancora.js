'use strict';
/* UROBOROS · URB2 — camada de âncora externa
 *
 * ═══ O PONTO ARQUITETURAL QUE INVERTE A INTUIÇÃO ═══
 *
 * Recuperação injetada como CONTEXTO **aumenta** ρ. Se as 16 células recebem
 * a mesma passagem no prompt, elas passam a condicionar na mesma informação:
 * a dispersão cai, a "confiança do consenso" sobe, e o viés da passagem entra
 * inteiro no viés compartilhado b. RAG-como-contexto é o modo de falha da §3
 * amplificado, não a cura dele.
 *
 * A âncora só reduz b se entrar como VERIFICAÇÃO POSTERIOR, no nível da
 * alegação, fora do span gerado pelas células. É onde o Polo V já opera —
 * e por isso a âncora é uma extensão do Polo V, não uma etapa de L0.
 *
 * ═══ CALIBRAÇÃO DO LLR ═══
 *
 * Alegação diz v; a fonte diz μ ± σ. Com z = |v−μ|/σ_ef:
 *
 *   verdadeira → z ~ N(0,1)          densidade φ(z)
 *   falsa      → z difuso em [0,Z]   densidade ≈ 1/Z
 *
 *   L = ln( Z·φ(z) ) = ln Z − ln√(2π) − z²/2
 *
 * Com Z = 20: L(0) = +2,08 · L(2) = +0,08 · L(3) = −2,42 · L(5) = −10,4.
 * Concordância dentro de 1σ vale ~1,6 nats; discordância a 5σ é veto de fato.
 * Não é limiar arbitrário — é a razão de verossimilhança, a mesma álgebra do
 * resto do grafo.
 *
 * ═══ TENSÃO NÃO É ERRO ═══
 *
 * Se a tabela traz Planck 67,36±0,54 e SH0ES 73,04±1,04, uma alegação de 73,0
 * está certa em relação a uma medida legítima. A âncora pontua contra a
 * MELHOR fonte, marca `tensao` quando as fontes discordam entre si acima de
 * 3σ, e ATENUA o LLR nesse caso — porque aí "qual fonte" é a questão em
 * disputa, e a âncora não tem autoridade para resolvê-la.
 */

const fs = require('fs');
const path = require('path');

/* Tipos de fonte: ρ é a correlação a priori com as famílias de LLM.
 * Consulta determinística a catálogo tem ρ≈0 — é o que dá poder à âncora.
 * Texto exige juiz LLM para julgar implicação, o que reintroduz correlação. */
const TIPOS = {
  estruturado: { rho: 0.00, teto: 4.0, podeVetar: true },
  catalogo:    { rho: 0.02, teto: 3.5, podeVetar: true },
  texto:       { rho: 0.18, teto: 2.0, podeVetar: false }
};

const Z_DIFUSO = 20;
const LN_SQRT_2PI = Math.log(Math.sqrt(2 * Math.PI));

function llrGaussiano(z, Z = Z_DIFUSO) {
  return Math.log(Z) - LN_SQRT_2PI - (z * z) / 2;
}

/* ---------- unidades: dimensão + fator, com conversão real ----------
 * Só checar compatibilidade não basta: "a idade do universo é 6000 anos"
 * tem unidade de tempo legítima e precisa ser CONVERTIDA para Gyr antes de
 * virar z, senão a alegação mais errada possível passa despercebida. */
const UNID = {
  'km/s/mpc': { dim: 'H', f: 1 }, 'kms-1mpc-1': { dim: 'H', f: 1 }, 'kms/mpc': { dim: 'H', f: 1 },
  gyr: { dim: 'T', f: 1 }, ga: { dim: 'T', f: 1 }, myr: { dim: 'T', f: 1e-3 },
  ano: { dim: 'T', f: 1e-9 }, anos: { dim: 'T', f: 1e-9 }, yr: { dim: 'T', f: 1e-9 }, year: { dim: 'T', f: 1e-9 }, years: { dim: 'T', f: 1e-9 },
  s: { dim: 'T', f: 1 / 3.1556952e16 },
  mpc: { dim: 'L', f: 1 }, kpc: { dim: 'L', f: 1e-3 }, pc: { dim: 'L', f: 1e-6 }, gpc: { dim: 'L', f: 1e3 },
  k: { dim: 'K', f: 1 }, kelvin: { dim: 'K', f: 1 },
  'm/s': { dim: 'V', f: 1 }, 'kg': { dim: 'M', f: 1 }, 'c': { dim: 'Q', f: 1 },
  'j/k': { dim: 'JK', f: 1 }, 'js': { dim: 'JS', f: 1 }, '1/mol': { dim: 'MOL', f: 1 },
  'm^3kg^-1s^-2': { dim: 'G', f: 1 }, 'm3kg-1s-2': { dim: 'G', f: 1 },
  'wm^-2k^-4': { dim: 'SB', f: 1 },
  '1': { dim: '1', f: 1 }, '': { dim: '?', f: 1 }
};
const normUnid = u => String(u || '').toLowerCase()
  .replace(/·/g, '').replace(/⁻/g, '-').replace(/¹/g, '1').replace(/²/g, '2').replace(/³/g, '3').replace(/⁴/g, '4')
  .replace(/\s+/g, '').trim();

function unidInfo(u) { return UNID[normUnid(u)] || null; }

/** Converte valor da unidade da alegação para a unidade da tabela.
 *  null = dimensões incompatíveis (ou desconhecidas de ambos os lados). */
function converter(valor, uClaim, uTab) {
  const a = unidInfo(uClaim), b = unidInfo(uTab);
  if (!b) return valor;                       // tabela sem unidade reconhecida: aceita cru
  if (!normUnid(uClaim) || !a || a.dim === '?') return valor;   // alegação sem unidade: assume a da tabela
  if (a.dim !== b.dim) return null;
  return valor * a.f / b.f;
}
const compativel = (uClaim, uTab) => converter(1, uClaim, uTab) !== null;

/* ---------- extração de (grandeza, valor, unidade) ---------- */
// (?<![\p{L}\d]) impede que o "0" de "H0" ou "t0" seja lido como o valor:
// "constante de Hubble H0 vale 55" extraía H0 = 0, e o veto acertava pelo motivo errado.
const NUM = String.raw`(?<![\p{L}\d])(-?\d[\d.,]*(?:\s*[×x*]\s*10\s*\^?\s*-?\d+|\s*[eE][+-]?\d+)?)`;

function parseNum(s) {
  let t = String(s).replace(/\s/g, '');
  const sci = /^(-?[\d.,]+)(?:[×x*]10\^?|[eE])([+-]?\d+)$/.exec(t);
  const dec = x => (x.includes(',') && !x.includes('.') ? x.replace(',', '.') : x.replace(/,/g, ''));
  const v = sci ? parseFloat(dec(sci[1])) * Math.pow(10, parseInt(sci[2], 10)) : parseFloat(dec(t));
  return Number.isFinite(v) ? v : null;
}

const esc = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Captura só o que parece unidade. Prosa depois do número vira string vazia. */
const UNID_RE = /^\s*(km\s*\/?\s*s\s*\/?\s*Mpc|km\s*s-1\s*Mpc-1|Gyr|Myr|Ga|anos?|years?|yr|Gpc|Mpc|kpc|pc|K|kelvin|eV|m\s*\/\s*s|m\^?3\s*kg\^?-1\s*s\^?-2|J\s*\/?\s*K|J\s*s|W\s*m\^?-2\s*K\^?-4|1\s*\/\s*mol|kg|m|s|C)(?![\p{L}])/iu;
function capturarUnidade(resto) {
  const m = UNID_RE.exec(resto);
  return m ? m[1].replace(/\s+/g, ' ').trim() : '';
}

class Tabela {
  constructor(file) {
    this.file = file || path.join(__dirname, '..', 'data', 'tabela.json');
    const j = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    this.grandezas = j.grandezas || {};
    this.aliases = j.aliases || {};
    // índice alias -> chave canônica, do mais longo para o mais curto
    this.idx = [];
    for (const [chave, lista] of Object.entries(this.aliases))
      for (const a of [chave, ...lista]) {
        // alias puramente numérico casa DENTRO do próprio valor e injeta
        // menções fantasmas ("137" dentro de 137.0359... vira 0359...).
        if (/^[\d.,\s]+$/.test(a)) continue;
        this.idx.push({ alias: a.toLowerCase(), chave });
      }
    this.idx.sort((x, y) => y.alias.length - x.alias.length);
  }

  entradas(chave) { return (this.grandezas[chave] || []).filter(e => e.valor != null); }
  verificadas(chave) { return this.entradas(chave).filter(e => e.verificado); }
  naoVerificadas() {
    return Object.entries(this.grandezas)
      .flatMap(([k, l]) => l.filter(e => !e.verificado).map(e => ({ grandeza: k, ...e })));
  }

  /** Encontra menções (grandeza, valor, unidade) no texto de uma alegação. */
  extrair(texto) {
    const t = String(texto);
    const achados = [];
    const usados = [];
    const numsUsados = [];
    for (const { alias, chave } of this.idx) {
      // fronteira de letra/dígito: sem isso o alias "G" casa dentro de "kg^-1"
      const re = new RegExp(`(?<![\\p{L}\\d])${esc(alias)}(?![\\p{L}\\d])`, 'giu');
      let m;
      while ((m = re.exec(t))) {
        const p = m.index, fim = p + m[0].length;
        if (usados.some(([a, b]) => p < b && fim > a)) continue;
        const janela = t.slice(fim, fim + 90);
        const mm = new RegExp(`^.{0,20}?${NUM}`, 'u').exec(janela);
        if (!mm) continue;
        const v = parseNum(mm[1]);
        if (v === null) continue;
        // Dedupe pelo NÚMERO, não pelo alias: "constante de Hubble H0 vale 67,4"
        // casa dois aliases apontando para o mesmo valor, e somar os dois
        // dobraria o LLR de uma única evidência.
        const posNum = fim + mm.index + mm[0].length - mm[1].length;
        const fimNum = posNum + mm[1].length;
        // sobreposição de SPAN, não só de início: sem isso, um alias que casa
        // dentro de um número já consumido extrai a cauda dele como valor novo.
        if (numsUsados.some(([a, b]) => posNum < b && fimNum > a)) continue;
        numsUsados.push([posNum, fimNum]);
        const unidade = capturarUnidade(janela.slice(mm.index + mm[0].length));
        achados.push({ grandeza: chave, valor: v, unidade, trecho: t.slice(p, fimNum + unidade.length + 1).trim() });
        usados.push([p, fim]);
      }
    }
    return achados;
  }
}

/**
 * Pontua uma menção contra todas as entradas verificadas da grandeza.
 * @returns {{llr, z, fonte, tensao, veto, detalhe}}
 */
function pontuar(mencao, tabela, { tipo = 'estruturado', Z = Z_DIFUSO } = {}) {
  const cfg = TIPOS[tipo] || TIPOS.estruturado;
  const verif = tabela.verificadas(mencao.grandeza);
  if (!verif.length) {
    const todas = tabela.entradas(mencao.grandeza);
    return { llr: 0, z: null, fonte: null, tensao: false, veto: false,
             detalhe: todas.length ? 'entrada existe mas nao verificada — abstem' : 'grandeza ausente da tabela' };
  }

  const cands = verif
    .map(e => ({ e, v: converter(mencao.valor, mencao.unidade, e.unidade) }))
    .filter(x => x.v !== null)
    .map(({ e, v }) => {
      // σ efetivo: incerteza publicada + resolução implícita da alegação
      const sigPub = e.exato ? Math.abs(e.valor) * 1e-12 : (e.sigma || Math.abs(e.valor) * 1e-3);
      const sigAleg = Math.abs(v) * resolucao(mencao.valor);
      const sig = Math.max(1e-30, Math.hypot(sigPub, sigAleg));
      return { e, v, z: Math.abs(v - e.valor) / sig, sig };
    })
    .sort((a, b) => a.z - b.z);

  if (!cands.length) return { llr: 0, z: null, fonte: null, tensao: false, veto: false, detalhe: 'unidade incompativel' };

  const best = cands[0];
  // fontes mutuamente inconsistentes? (tensão real, ex.: H0)
  let tensao = false;
  for (let i = 0; i < verif.length && !tensao; i++)
    for (let j = i + 1; j < verif.length; j++) {
      const si = verif[i].sigma || 0, sj = verif[j].sigma || 0;
      if (Math.abs(verif[i].valor - verif[j].valor) / Math.max(1e-30, Math.hypot(si, sj)) > 3) { tensao = true; break; }
    }

  // Tensão só atenua se a alegação for plausível sob ALGUMA fonte concorrente.
  // Um valor errado para todas as fontes não se beneficia da disputa entre elas.
  const naDisputa = tensao && best.z <= 3;
  let llr = llrGaussiano(best.z, Z);
  if (naDisputa) llr = Math.min(llr, 0.8);   // em tensão real, não afirma forte
  llr = Math.max(-cfg.teto * 3, Math.min(cfg.teto, llr));
  const veto = cfg.podeVetar && !naDisputa && best.z > 5;

  return {
    llr: veto ? -Infinity : llr,
    z: +best.z.toFixed(3),
    fonte: best.e.fonte,
    rotulo: best.e.rotulo || null,
    tensao, naDisputa,
    veto,
    detalhe: `${mencao.grandeza} = ${+best.v.toPrecision(6)} ${best.e.unidade} vs ${best.e.valor} ± ${best.e.sigma} (${best.e.fonte})`
  };
}

/** Resolução implícita: "67,4" carrega ~0,05 de incerteza; "67" carrega ~0,5. */
function resolucao(v) {
  const s = String(Math.abs(v));
  const dec = s.includes('.') ? s.split('.')[1].length : 0;
  const mag = Math.floor(Math.log10(Math.abs(v) || 1));
  const passo = Math.pow(10, -dec) / 2;
  return Math.abs(v) > 0 ? passo / Math.abs(v) : 1e-3;
}

/* ---------- interface de âncora ---------- */
class Ancora {
  /**
   * @param fontes lista de {id, tipo, verificar(claimTexto) -> Promise<{llr, detalhe, veto}>}
   *               A tabela local é registrada automaticamente.
   */
  constructor({ tabela = null, fontes = [], L_MAX = 12 } = {}) {
    this.tabela = tabela || new Tabela();
    this.fontes = fontes;
    this.L_MAX = L_MAX;
  }

  /** Verificação local, síncrona, sem rede. É a âncora de ρ = 0. */
  local(claimTexto) {
    const mencoes = this.tabela.extrair(claimTexto);
    if (!mencoes.length) return null;
    const res = mencoes.map(m => ({ mencao: m, ...pontuar(m, this.tabela) })).filter(r => r.llr !== 0 || r.veto);
    if (!res.length) return null;
    if (res.some(r => r.veto)) {
      const v = res.find(r => r.veto);
      return { llr: -this.L_MAX, veto: true, tensao: false, fonte: v.fonte, detalhe: v.detalhe, mencoes: res };
    }
    const llr = res.reduce((s, r) => s + r.llr, 0);
    return {
      llr: Math.max(-this.L_MAX, Math.min(this.L_MAX, llr)),
      veto: false,
      tensao: res.some(r => r.tensao),
      fonte: res[0].fonte,
      detalhe: res.map(r => r.detalhe).join(' · '),
      mencoes: res
    };
  }

  /** Evidência pronta para o grafo de crença. `bit` fora do espaço das células. */
  async evidencia(claimTexto, { bit = 1 << 30, usarRede = false } = {}) {
    const out = [];
    const loc = this.local(claimTexto);
    if (loc) out.push({ cell: 254, family: '__ancora:tabela', bit, llr: loc.llr, kind: loc.veto ? 'verifier' : 'ancora', meta: loc });

    if (usarRede) {
      for (const f of this.fontes) {
        try {
          const r = await f.verificar(claimTexto);
          if (r && Number.isFinite(r.llr) && r.llr !== 0)
            out.push({ cell: 253, family: `__ancora:${f.id}`, bit: bit << 1, llr: r.llr, kind: 'ancora', meta: r });
        } catch { /* fonte fora do ar não invalida as outras */ }
      }
    }
    return out;
  }
}

module.exports = { Ancora, Tabela, pontuar, llrGaussiano, TIPOS, parseNum, resolucao, compativel, converter, capturarUnidade };
