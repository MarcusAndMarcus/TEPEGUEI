'use strict';
/* UROBOROS · URB2 — Polo V estendido (âncora determinística)
 *
 * Toda alegação redutível a computação DEVE ser computada, nunca votada.
 * O verificador é o único nó do grafo com direito de veto (L = -L_MAX):
 * é o que impede o cluster de convergir suavemente para um erro elegante.
 *
 * Sem eval(). Parser recursivo-descendente próprio.
 */

/* ---------------- 1. aritmética ---------------- */

const FUNCS = {
  sqrt: Math.sqrt, abs: Math.abs, ln: Math.log, log: Math.log10, log2: Math.log2,
  exp: Math.exp, sin: Math.sin, cos: Math.cos, tan: Math.tan,
  asin: Math.asin, acos: Math.acos, atan: Math.atan,
  sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
  floor: Math.floor, ceil: Math.ceil, round: Math.round
};
const CONSTS = { pi: Math.PI, e: Math.E, c: 299792458, G: 6.674e-11, h: 6.62607015e-34, hbar: 1.054571817e-34, k_B: 1.380649e-23, N_A: 6.02214076e23 };

function evalExpr(src) {
  let i = 0;
  const s = String(src).replace(/\s+/g, '').replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/\^/g, '**');
  const peek = () => s[i];
  const eat = ch => { if (s[i] === ch) { i++; return true; } return false; };

  function expr() { let v = term(); for (;;) { if (eat('+')) v += term(); else if (eat('-')) v -= term(); else return v; } }
  function term() { let v = unary(); for (;;) { if (s.startsWith('**', i)) break; if (eat('*')) v *= unary(); else if (eat('/')) v /= unary(); else if (eat('%')) v %= unary(); else return v; } return v; }
  function unary() { if (eat('-')) return -unary(); if (eat('+')) return unary(); return power(); }
  function power() { const b = atom(); if (s.startsWith('**', i)) { i += 2; return Math.pow(b, unary()); } return b; }
  function atom() {
    if (eat('(')) { const v = expr(); if (!eat(')')) throw new Error('parêntese'); return v; }
    const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i));
    if (m) {
      const name = m[0]; i += name.length;
      if (eat('(')) { const a = expr(); if (!eat(')')) throw new Error('parêntese'); const f = FUNCS[name]; if (!f) throw new Error(`função ${name}`); return f(a); }
      if (name in CONSTS) return CONSTS[name];
      throw new Error(`símbolo ${name}`);
    }
    const num = /^\d+(\.\d+)?([eE][+-]?\d+)?/.exec(s.slice(i));
    if (num) { i += num[0].length; return parseFloat(num[0]); }
    throw new Error(`token em ${i}`);
  }

  const v = expr();
  if (i !== s.length) throw new Error('sobra de tokens');
  if (!Number.isFinite(v)) throw new Error('não finito');
  return v;
}

/** Encontra e checa igualdades numéricas em texto livre: "12*7 = 82" -> falso. */
function checkArithmetic(text, relTol = 1e-6) {
  const out = [];
  const re = /([0-9()][0-9\s+\-*/^().eE]{1,80}?)\s*(?:=|≈|é igual a|equals?)\s*(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g;
  let m;
  while ((m = re.exec(text))) {
    const lhs = m[1].trim(), rhs = parseFloat(m[2]);
    if (!/[+\-*/^]/.test(lhs)) continue;
    let got;
    try { got = evalExpr(lhs); } catch { continue; }
    const ok = Math.abs(got - rhs) <= Math.max(relTol * Math.abs(got), 1e-9);
    out.push({ tipo: 'aritmetica', expr: `${lhs} = ${m[2]}`, esperado: got, obtido: rhs, ok });
  }
  return out;
}

/* ---------------- 2. análise dimensional ---------------- */
/* base: [m, kg, s, A, K, mol, cd] */
const DIM = {
  m: [1,0,0,0,0,0,0], km:[1,0,0,0,0,0,0], cm:[1,0,0,0,0,0,0], mm:[1,0,0,0,0,0,0],
  kg:[0,1,0,0,0,0,0], g:[0,1,0,0,0,0,0], t:[0,1,0,0,0,0,0],
  s:[0,0,1,0,0,0,0], ms:[0,0,1,0,0,0,0], min:[0,0,1,0,0,0,0], h:[0,0,1,0,0,0,0],
  A:[0,0,0,1,0,0,0], K:[0,0,0,0,1,0,0], mol:[0,0,0,0,0,1,0],
  N:[1,1,-2,0,0,0,0], J:[2,1,-2,0,0,0,0], W:[2,1,-3,0,0,0,0],
  Pa:[-1,1,-2,0,0,0,0], V:[2,1,-3,-1,0,0,0], C:[0,0,1,1,0,0,0],
  Ohm:[2,1,-3,-2,0,0,0], F:[-2,-1,4,2,0,0,0], T:[0,1,-2,-1,0,0,0], Hz:[0,0,-1,0,0,0,0]
};
const SCALE = { km:1e3, cm:1e-2, mm:1e-3, g:1e-3, t:1e3, ms:1e-3, min:60, h:3600 };

function dimOf(unit) {
  const parts = String(unit).split(/[·*\s]+/).filter(Boolean);
  const d = [0,0,0,0,0,0,0]; let f = 1;
  for (const p of parts) {
    const m = /^([A-Za-z]+)(?:\^?(-?\d+))?$/.exec(p);
    if (!m) return null;
    const base = DIM[m[1]]; if (!base) return null;
    const e = m[2] ? parseInt(m[2], 10) : 1;
    for (let k = 0; k < 7; k++) d[k] += base[k] * e;
    f *= Math.pow(SCALE[m[1]] ?? 1, e);
  }
  return { dim: d, factor: f };
}
const sameDim = (a, b) => a && b && a.dim.every((x, i) => x === b.dim[i]);

/** "A energia é 5 N" -> incompatível com J. */
function checkUnits(pairs) {
  return pairs.map(({ grandeza, valor, unidade, unidadeEsperada }) => {
    const a = dimOf(unidade), b = dimOf(unidadeEsperada);
    return { tipo: 'dimensional', grandeza, valor, unidade, unidadeEsperada, ok: sameDim(a, b) };
  });
}

/* ---------------- 3. datas e faixas ---------------- */

function checkDates(text) {
  const out = [];
  const re = /(\d{4})\s*(?:-|–|até|a)\s*(\d{4})/g;
  let m;
  while ((m = re.exec(text))) {
    const a = +m[1], b = +m[2];
    out.push({ tipo: 'intervalo_temporal', trecho: m[0], ok: b >= a && a > 1000 && b < 2200 });
  }
  return out;
}

function checkRanges(claims, ranges) {
  return claims.map(c => {
    const r = ranges[c.grandeza];
    if (!r) return { tipo: 'faixa', ...c, ok: null };
    return { tipo: 'faixa', ...c, ok: c.valor >= r[0] && c.valor <= r[1], faixa: r };
  });
}

/* ---------------- 4. execução ---------------- */

/**
 * Roda tudo o que der. Retorna {checks, veto, llr} pronto para o grafo de crença.
 * llr = -L_MAX se algo determinístico falhou; +ganho por check aprovado; 0 se silente.
 */
function verify(text, { units = [], ranges = null, numeric = [], L_MAX = 12 } = {}) {
  const checks = [
    ...checkArithmetic(text),
    ...checkDates(text),
    ...(units.length ? checkUnits(units) : []),
    ...(ranges && numeric.length ? checkRanges(numeric, ranges) : [])
  ];
  const decided = checks.filter(c => c.ok !== null);
  const failed = decided.filter(c => c.ok === false);
  if (failed.length) return { checks, veto: true, llr: -L_MAX, checked: true, failed };
  const llr = Math.min(4, 1.4 * decided.length);   // confirmação determinística vale, mas não é ilimitada
  return { checks, veto: false, llr, checked: decided.length > 0, failed: [] };
}

module.exports = { evalExpr, checkArithmetic, checkUnits, checkDates, checkRanges, dimOf, verify, DIM, CONSTS };
