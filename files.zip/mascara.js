'use strict';
/* UROBOROS · URB2 — máscara de proveniência de largura arbitrária
 *
 * ═══ POR QUE ISTO EXISTE ═══
 *
 * A máscara de origem era um Number de 32 bits, com `bit = 1 << i`. Em
 * JavaScript, `<<` opera em int32 com envolvimento:
 *
 *     1 << 31  =  2147483648    ok
 *     1 << 32  =  1             ← mesma máscara da célula 0
 *     1 << 33  =  2             ← mesma máscara da célula 1
 *
 * Acima de 31 células a proveniência não só quebra: ela MENTE em silêncio.
 * A célula 32 passa a se apresentar como a célula 0, o filtro de informação
 * extrínseca deixa de reconhecer o eco, e o `popcount` conta duas origens
 * onde há uma. Sem erro, sem aviso — só confiança inflada.
 *
 * Como toda a defesa contra lavagem de alucinação depende da máscara ser
 * exata, isto é pré-requisito absoluto para qualquer contagem de células
 * acima de 31. Com BigInt não há teto.
 *
 * Slots reservados no topo, fora do espaço das células:
 *   VERIFICADOR  Polo V determinístico
 *   ANCORA       tabela numérica local
 *   ANCORA_REDE  conectores externos (SIMBAD, Gaia, VizieR, arXiv)
 */

const ZERO = 0n;

/** Bit da célula i. Sem teto: i = 4096 funciona igual a i = 3. */
const bitDe = i => 1n << BigInt(i);

/** Slots reservados começam bem acima de qualquer contagem plausível. */
const RESERVADO = 1n << 4096n;
const VERIFICADOR = RESERVADO;
const ANCORA = RESERVADO << 1n;
const ANCORA_REDE = RESERVADO << 2n;
const RESERVADOS = VERIFICADOR | ANCORA | ANCORA_REDE;

const uniao = (a, b) => (a | b);
const contem = (mascara, bit) => (mascara & bit) !== ZERO;
const semReservados = m => m & ~RESERVADOS;

/** Número de bits em 1. Processa 32 bits por passo — O(bits/32). */
function popcount(m) {
  let x = typeof m === 'bigint' ? m : BigInt(m || 0);
  if (x < ZERO) x = -x;
  let n = 0;
  while (x > ZERO) {
    let w = Number(x & 0xffffffffn);
    while (w) { w &= w - 1; n++; }
    x >>= 32n;
  }
  return n;
}

/** Quantas células distintas (ignora verificador e âncoras). */
const origens = m => popcount(semReservados(m));

/** Índices das células presentes — para relatório e depuração. */
function indices(m, limite = 4096) {
  let x = semReservados(typeof m === 'bigint' ? m : BigInt(m || 0));
  const out = [];
  for (let i = 0; x > ZERO && i < limite; i++, x >>= 1n) if (x & 1n) out.push(i);
  return out;
}

/* ---------- serialização para o telegrama URB2 ---------- */

/** BigInt -> Buffer big-endian, sem zeros à esquerda. */
function paraBytes(m) {
  let x = typeof m === 'bigint' ? m : BigInt(m || 0);
  if (x <= ZERO) return Buffer.alloc(0);
  let hex = x.toString(16);
  if (hex.length % 2) hex = '0' + hex;
  return Buffer.from(hex, 'hex');
}

function deBytes(buf) {
  if (!buf || !buf.length) return ZERO;
  return BigInt('0x' + Buffer.from(buf).toString('hex'));
}

/** Forma curta para log: contagem + prefixo hex. */
function resumo(m) {
  const n = origens(m);
  const h = paraBytes(semReservados(m)).toString('hex');
  return `${n} origem(ns)${h ? ' 0x' + (h.length > 16 ? h.slice(0, 16) + '…' : h) : ''}`;
}

module.exports = {
  ZERO, RESERVADO, VERIFICADOR, ANCORA, ANCORA_REDE, RESERVADOS,
  bitDe, uniao, contem, semReservados, popcount, origens, indices,
  paraBytes, deBytes, resumo
};
