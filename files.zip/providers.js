'use strict';
/* UROBOROS · URB2 — camada de provedores
 * Zero dependências. Node >= 18 (fetch global, AbortController).
 *
 * O campo `fam` é o mais importante do registro: é a chave de agrupamento
 * de correlação. Duas células da mesma família NÃO contam como evidência
 * independente (ver lib/epistemic.js :: neff).
 */

const { bitDe } = require('./mascara');

const REG = {
  anthropic: { fam: 'anthropic', kind: 'anthropic', url: 'https://api.anthropic.com/v1/messages',
               key: 'ANTHROPIC_API_KEY', model: 'claude-sonnet-5', rpm: 50,
               // Camadas do MESMO provedor. Não são famílias novas — a linhagem
               // de pré-treino é comum — mas tamanhos diferentes erram de forma
               // parcialmente diferente, e ρ_intra cai. É o único jeito de fazer
               // contagem alta de células render alguma coisa.
               camadas: ['claude-opus-5', 'claude-sonnet-5', 'claude-haiku-4-5-20251001'] },

  gemini:    { fam: 'google', kind: 'gemini', url: 'https://generativelanguage.googleapis.com/v1beta/models',
               key: 'GEMINI_API_KEY', model: 'gemini-2.0-flash', rpm: 15,
               camadas: ['gemini-2.0-flash', 'gemini-2.0-flash-lite'] },

  groq:      { fam: 'llama', kind: 'openai', url: 'https://api.groq.com/openai/v1/chat/completions',
               key: 'GROQ_API_KEY', model: 'llama-3.3-70b-versatile', rpm: 30 },

  cerebras:  { fam: 'llama', kind: 'openai', url: 'https://api.cerebras.ai/v1/chat/completions',
               key: 'CEREBRAS_API_KEY', model: 'llama-3.3-70b', rpm: 30 },

  mistral:   { fam: 'mistral', kind: 'openai', url: 'https://api.mistral.ai/v1/chat/completions',
               key: 'MISTRAL_API_KEY', model: 'mistral-large-latest', rpm: 60 },

  deepseek:  { fam: 'deepseek', kind: 'openai', url: 'https://api.deepseek.com/chat/completions',
               key: 'DEEPSEEK_API_KEY', model: 'deepseek-chat', rpm: 60 },

  qwen:      { fam: 'qwen', kind: 'openai',
               url: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions',
               key: 'DASHSCOPE_API_KEY', model: 'qwen-plus', rpm: 60 },

  xai:       { fam: 'xai', kind: 'openai', url: 'https://api.x.ai/v1/chat/completions',
               key: 'XAI_API_KEY', model: 'grok-3-mini', rpm: 60 },

  cohere:    { fam: 'cohere', kind: 'openai', url: 'https://api.cohere.ai/compatibility/v1/chat/completions',
               key: 'COHERE_API_KEY', model: 'command-r-plus', rpm: 60 },

  openrouter:{ fam: 'mixed', kind: 'openai', url: 'https://openrouter.ai/api/v1/chat/completions',
               key: 'OPENROUTER_API_KEY', model: 'meta-llama/llama-3.3-70b-instruct:free', rpm: 20 }
};

/* ---------- token bucket por provedor (respeita free tier) ---------- */
class Bucket {
  constructor(rpm) { this.cap = Math.max(1, rpm); this.tokens = this.cap; this.rate = rpm / 60000; this.t = Date.now(); }
  refill() { const now = Date.now(); this.tokens = Math.min(this.cap, this.tokens + (now - this.t) * this.rate); this.t = now; }
  async take() {
    for (;;) {
      this.refill();
      if (this.tokens >= 1) { this.tokens -= 1; return; }
      await sleep(Math.ceil((1 - this.tokens) / this.rate) + 25);
    }
  }
}
const buckets = new Map();
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* Semáforo global. Com 256 células, disparar Promise.all cru abre 256 sockets
 * ao mesmo tempo: o SO recusa, o provedor devolve 429 em rajada e o retry com
 * backoff transforma tudo num congestionamento. O limite mantém o pipeline
 * cheio sem estourar nada. */
class Semaforo {
  constructor(n) { this.n = Math.max(1, n); this.ativos = 0; this.fila = []; }
  async adquirir() {
    if (this.ativos < this.n) { this.ativos++; return; }
    await new Promise(r => this.fila.push(r));
    this.ativos++;
  }
  liberar() { this.ativos--; const r = this.fila.shift(); if (r) r(); }
  async com(fn) { await this.adquirir(); try { return await fn(); } finally { this.liberar(); } }
}
let SEM = null;
const semaforo = (env = process.env) => (SEM ||= new Semaforo(Number(env.CONCURRENCY) || 8));
const ajustarConcorrencia = n => { SEM = new Semaforo(n); return SEM; };

/** Executa tarefas com limite global de concorrência e progresso opcional. */
async function emLote(tarefas, { onProgresso = null, env = process.env } = {}) {
  const sem = semaforo(env);
  let feitas = 0;
  return Promise.all(tarefas.map(t => sem.com(async () => {
    const r = await t();
    onProgresso?.(++feitas, tarefas.length);
    return r;
  })));
}

/* ---------- provedores ativos = os que têm chave no ambiente ---------- */
function available(env = process.env) {
  return Object.entries(REG)
    .filter(([, p]) => !!env[p.key])
    .map(([id, p]) => ({ id, ...p, model: env[`${id.toUpperCase()}_MODEL`] || p.model }));
}

/* ---------- construção de células ----------
 * Uma célula = (provedor, papel, semente). Papéis diversificam o prior,
 * não só a amostragem. `adversarial` é anti-cascata de confirmação.
 */
/* Papéis. Diversificar amostragem não move ρ_intra — diversificar o PRIOR move.
 * Cada papel impõe um modo de raciocínio distinto, e é isso que descorrelaciona
 * células da mesma família. Medido no modelo: ρ_intra 0,85 → 0,55 quase dobra o
 * N_eff em contagem alta. É a diferença entre 256 células valerem 1,77 ou 2,40. */
const ROLES = [
  'solver', 'skeptic', 'adversarial', 'formalist', 'empirical', 'minimalist',
  'decompositor', 'analogico', 'limite', 'unidades', 'contraexemplo', 'historico',
  'quantitativo', 'causal', 'definicional', 'operacional'
];

/**
 * MODO PARES — células nascem em duplas de famílias DIFERENTES.
 *
 * O pareamento não altera Σ, logo não altera N_eff: rotular as células em
 * duplas não muda a estrutura de covariância. O que ele muda é onde cada
 * chamada de API cai dentro dessa estrutura.
 *
 *   duas células concordando, LLR = 2 cada (soma bruta 4):
 *     mesma família (ρ=0,85) → L = 2,16
 *     par cruzado   (ρ=0,28) → L = 3,13     1,45× mais evidência, mesmo custo
 *
 * E abre a refutação cruzada, que é a única arma interna contra viés: um
 * refutador da mesma família erra junto com o propositor (ρ=0,85) e quase não
 * enxerga o que o outro não viu. De outra família, cobre 4,8× mais do espaço
 * de erro não coberto.
 *
 * Cada par recebe papéis COMPLEMENTARES: o membro A propõe, o B contesta.
 */
function buildPairs(nPares, env = process.env) {
  const provs = available(env);
  const fams = [...new Set(provs.map(p => p.fam))];
  if (fams.length < 2) throw new Error('URB2: modo pares exige ao menos 2 famílias distintas');

  // agrupa provedores por família e alterna entre elas
  const porFam = fams.map(f => provs.filter(p => p.fam === f));
  const cells = [];
  const modelo = (p, volta) => {
    const cfg = (env[`${p.id.toUpperCase()}_CAMADAS`] || '').split(',').map(x => x.trim()).filter(Boolean);
    const lista = cfg.length ? cfg : (p.camadas && p.camadas.length ? p.camadas : [p.model]);
    return lista[volta % lista.length];
  };

  for (let k = 0; k < nPares; k++) {
    const fa = porFam[k % porFam.length];
    const fb = porFam[(k + 1) % porFam.length];
    const pa = fa[Math.floor(k / porFam.length) % fa.length];
    const pb = fb[Math.floor(k / porFam.length) % fb.length];
    const papelA = ROLES[k % ROLES.length];
    const papelB = COMPLEMENTO[papelA] || 'adversarial';
    const volta = Math.floor(k / ROLES.length);

    for (const [p, papel, lado] of [[pa, papelA, 'propositor'], [pb, papelB, 'refutador']]) {
      const id = cells.length;
      cells.push({
        id, bit: bitDe(id), par: k, lado,
        provider: p.id, family: p.fam, model: modelo(p, volta),
        role: papel, temperature: lado === 'propositor' ? 0.30 + 0.12 * (k % 5) : 0.20
      });
    }
  }
  // vincula parceiros
  for (const c of cells) c.parceiro = cells.find(o => o.par === c.par && o.id !== c.id)?.id ?? null;
  return cells;
}

/* Papel do refutador, escolhido para atacar o ponto cego do propositor. */
const COMPLEMENTO = {
  solver: 'contraexemplo', skeptic: 'quantitativo', adversarial: 'formalist',
  formalist: 'empirical', empirical: 'limite', minimalist: 'decompositor',
  decompositor: 'causal', analogico: 'definicional', limite: 'unidades',
  unidades: 'quantitativo', contraexemplo: 'formalist', historico: 'empirical',
  quantitativo: 'unidades', causal: 'contraexemplo', definicional: 'operacional',
  operacional: 'limite'
};

/**
 * Constrói n células percorrendo provedor × papel × camada de modelo, nesta
 * ordem de prioridade. Assim as primeiras células já cobrem todas as famílias
 * (que é o que move N_eff), depois todos os papéis (que reduzem ρ_intra), e só
 * então repetem camadas.
 */
function buildCells(n, env = process.env) {
  const provs = available(env);
  if (!provs.length) throw new Error('URB2: nenhum provedor com chave no ambiente');
  const cells = [];
  for (let i = 0; i < n; i++) {
    const p = provs[i % provs.length];
    const volta = Math.floor(i / provs.length);
    const role = ROLES[volta % ROLES.length];
    const camadas = (env[`${p.id.toUpperCase()}_CAMADAS`] || '').split(',').map(x => x.trim()).filter(Boolean);
    const lista = camadas.length ? camadas : (p.camadas && p.camadas.length ? p.camadas : [p.model]);
    const model = lista[Math.floor(volta / ROLES.length) % lista.length];
    cells.push({
      id: i,
      bit: bitDe(i),                     // BigInt: sem teto de 31 células
      provider: p.id,
      family: p.fam,
      model,
      role,
      temperature: 0.30 + 0.14 * (i % 6)
    });
  }
  return cells;
}

/**
 * Composição efetiva do cluster. Serve para o usuário ver, antes de gastar,
 * quantas combinações distintas realmente existem — acima disso as células
 * viram réplicas exatas e o N_eff para de subir.
 */
function composicao(cells) {
  const chave = c => `${c.provider}|${c.role}|${c.model}|${c.lado || ''}`;
  const distintas = new Set(cells.map(chave)).size;
  const provs = available();
  const maxDistintas = provs.reduce((s, p) => s + ROLES.length * ((p.camadas || [p.model]).length), 0);
  const pares = [...new Set(cells.filter(c => c.par != null).map(c => c.par))];
  const cruzados = pares.filter(k => {
    const d = cells.filter(c => c.par === k);
    return d.length === 2 && d[0].family !== d[1].family;
  }).length;
  return {
    celulas: cells.length,
    familias: [...new Set(cells.map(c => c.family))].length,
    combinacoesDistintas: distintas,
    combinacoesPossiveis: maxDistintas,
    replicasExatas: Math.max(0, cells.length - distintas),
    saturado: cells.length > maxDistintas,
    pares: pares.length,
    paresCruzados: cruzados,
    modo: pares.length ? 'pares' : 'solto'
  };
}

/* ---------- chamada normalizada ---------- */
async function call(providerId, { system, messages, maxTokens = 1200, temperature = 0.4, json = false, timeoutMs = 60000, env = process.env }) {
  const p = REG[providerId];
  if (!p) throw new Error(`provedor desconhecido: ${providerId}`);
  const apiKey = env[p.key];
  if (!apiKey) throw new Error(`sem chave ${p.key}`);
  const model = env[`${providerId.toUpperCase()}_MODEL`] || p.model;

  if (!buckets.has(providerId)) buckets.set(providerId, new Bucket(Number(env[`${providerId.toUpperCase()}_RPM`]) || p.rpm));
  await buckets.get(providerId).take();

  let url, headers, body;
  if (p.kind === 'anthropic') {
    url = p.url;
    headers = { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' };
    body = { model, max_tokens: maxTokens, temperature, messages };
    if (system) body.system = system;
  } else if (p.kind === 'gemini') {
    url = `${p.url}/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
    headers = { 'content-type': 'application/json' };
    body = {
      contents: messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
      generationConfig: { temperature, maxOutputTokens: maxTokens, ...(json ? { responseMimeType: 'application/json' } : {}) }
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };
  } else { // openai-compatible
    url = p.url;
    headers = { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` };
    body = {
      model, max_tokens: maxTokens, temperature,
      messages: system ? [{ role: 'system', content: system }, ...messages] : messages,
      ...(json ? { response_format: { type: 'json_object' } } : {})
    };
  }

  const t0 = Date.now();
  const text = await retry(async () => {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    try {
      const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body), signal: ac.signal });
      const raw = await r.text();
      if (!r.ok) { const e = new Error(`${providerId} ${r.status}: ${raw.slice(0, 300)}`); e.status = r.status; throw e; }
      return extract(p.kind, JSON.parse(raw));
    } finally { clearTimeout(timer); }
  });

  return { provider: providerId, family: p.fam, model, text, ms: Date.now() - t0 };
}

function extract(kind, d) {
  if (kind === 'anthropic') return (d.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n');
  if (kind === 'gemini') return (d.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('\n');
  return d.choices?.[0]?.message?.content ?? '';
}

async function retry(fn, tries = 4) {
  let last;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); }
    catch (e) {
      last = e;
      const st = e.status || 0;
      if (st && st < 500 && st !== 429 && st !== 408) throw e;   // erro de cliente: não insiste
      await sleep(Math.round((2 ** i) * 700 * (0.7 + Math.random() * 0.6)));
    }
  }
  throw last;
}

/* ---------- JSON tolerante (modelos cercam com ``` às vezes) ---------- */
function parseJSON(text) {
  if (!text) return null;
  let s = String(text).replace(/```(?:json)?/gi, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  const c = s.indexOf('['), d = s.lastIndexOf(']');
  const cand = (c >= 0 && (a < 0 || c < a)) ? s.slice(c, d + 1) : s.slice(a, b + 1);
  try { return JSON.parse(cand); } catch { try { return JSON.parse(s); } catch { return null; } }
}

module.exports = { REG, ROLES, COMPLEMENTO, available, buildCells, buildPairs, composicao, call, parseJSON, sleep, emLote, semaforo, ajustarConcorrencia, Semaforo };
