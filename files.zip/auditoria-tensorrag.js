'use strict';
/* UROBOROS · URB2 — auditoria numérica do TensorRAG5D (arXiv/PDF de M. A. P. Roriz)
 *
 * Reproduz, sem rede e sem chave de API, todas as medições que sustentam a
 * conclusão de que o modelo como especificado é inerte:
 *   A  ranking idêntico ao cosseno em embeddings normalizados (Kendall τ = 1)
 *   B  divergência só em embeddings não normalizados
 *   C  o termo λ(q·δ)² ESTICA ao longo da consulta; nunca encurta
 *   D  λ < −1 inverte o ranking em vez de abrir garganta
 *   E  métrica constante é plana: ranking == Euclidiano após x → M^{1/2}x
 *   F  custo O(N·d²) contra O(N·d) para o mesmo resultado
 *   G  as pontes são 100% descartadas pelo slice final
 *   H  onde difere do cosseno, difere para pior (recall@10)
 *   I  branqueamento parcial: o botão que λ queria ser
 *
 *   node tools/auditoria-tensorrag.js
 */

/* ── A-G ── */
(function(){
/* Porte fiel do TensorRAG5D do PDF para Node, para medir o que ele faz. */

let s=20260810; const u=()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);
let sp=null; const g=()=>{if(sp!==null){const v=sp;sp=null;return v;}let a,b,r;do{a=2*u()-1;b=2*u()-1;r=a*a+b*b;}while(r>=1||r===0);const f=Math.sqrt(-2*Math.log(r)/r);sp=b*f;return a*f;};
const vec=d=>Array.from({length:d},g);
const norm=v=>{const n=Math.hypot(...v);return v.map(x=>x/n);};
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);

// --- implementacao do paper ---
function apply_field_deformation(q, lambda){
  const d=q.length;
  const M=Array.from({length:d},(_,i)=>Array.from({length:d},(_,j)=>(i===j?1:0)+lambda*q[i]*q[j]));
  let fro=0; for(const r of M) for(const x of r) fro+=x*x; fro=Math.sqrt(fro);
  return M.map(r=>r.map(x=>x/fro));
}
function ds2_paper(docs,q,lambda){
  const M=apply_field_deformation(q,lambda);
  return docs.map(x=>{
    const dl=x.map((v,i)=>v-q[i]);
    let s=0; for(let i=0;i<dl.length;i++){ let t=0; for(let j=0;j<dl.length;j++) t+=M[i][j]*dl[j]; s+=dl[i]*t; }
    return s;
  });
}
const rankAsc=a=>a.map((v,i)=>i).sort((x,y)=>a[x]-a[y]);

function kendall(r1,r2){
  const pos1=[],pos2=[]; r1.forEach((v,i)=>pos1[v]=i); r2.forEach((v,i)=>pos2[v]=i);
  let c=0,dsc=0; const n=r1.length;
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){ const a=(pos1[i]-pos1[j]), b=(pos2[i]-pos2[j]); (a*b>0)?c++:dsc++; }
  return (c-dsc)/(c+dsc);
}

const D=256, N=2000;
const docsN=Array.from({length:N},()=>norm(vec(D)));
const qN=norm(vec(D));

console.log('=== TESTE A · embeddings normalizados (padrao em RAG) ===');
const cos = docsN.map(x=>1-dot(x,qN));
const rc=rankAsc(cos);
for(const lam of [0.01,0.1,1,10,100]){
  const r=rankAsc(ds2_paper(docsN,qN,lam));
  const tau=kendall(rc,r);
  const inter=new Set(r.slice(0,10)); const ov=rc.slice(0,10).filter(i=>inter.has(i)).length;
  console.log(`  lambda=${String(lam).padStart(5)}  Kendall tau vs cosseno = ${tau.toFixed(6)}   top-10 identico = ${ov}/10`);
}
console.log('  -> identidade de ranking exata. Prova: com ||x||=||q||=1 e t=1-cos,');
console.log('     ds2 = 2t + lambda*t^2, monotona crescente em t para lambda >= 0.');

console.log('\n=== TESTE B · embeddings NAO normalizados ===');
const docsU=Array.from({length:N},()=>vec(D).map(x=>x*(0.5+2*u())));
const qU=vec(D).map(x=>x*1.3);
const cosU=docsU.map(x=>1-dot(norm(x),norm(qU)));
const l2U=docsU.map(x=>x.reduce((s,v,i)=>s+(v-qU[i])**2,0));
for(const lam of [0.01,1,100]){
  const r=rankAsc(ds2_paper(docsU,qU,lam));
  console.log(`  lambda=${String(lam).padStart(4)}  tau vs cosseno=${kendall(rankAsc(cosU),r).toFixed(4)}   tau vs L2=${kendall(rankAsc(l2U),r).toFixed(4)}`);
}

console.log('\n=== TESTE C · sinal: o termo alonga, nao encurta ===');
const q2=norm(vec(D));
const alvo=norm(q2.map((x,i)=>x+0.25*g()));   // documento alinhado com a consulta
const orto=norm(vec(D));
for(const lam of [0,1,10]){
  const [a,b]=ds2_paper([alvo,orto],q2,lam);
  console.log(`  lambda=${String(lam).padStart(3)}  ds2(alinhado)=${a.toExponential(3)}  ds2(ortogonal)=${b.toExponential(3)}  razao=${(a/b).toFixed(4)}`);
}
console.log('  -> M = I + lambda*qq^T e' + ' PSD: soma (q.delta)^2 >= 0. Nunca reduz distancia.');
console.log('     ds2 = ||delta_perp||^2 + (1 + lambda*||q||^2)*delta_par^2  <- ESTICA ao longo de q.');

console.log('\n=== TESTE D · lambda negativo (unica forma de "encurtar") ===');
for(const lam of [-0.5,-1.01,-2]){
  const v=ds2_paper(docsN,qN,lam);
  const neg=v.filter(x=>x<0).length;
  console.log(`  lambda=${lam}  ds2 negativos: ${neg}/${N}  min=${Math.min(...v).toExponential(3)}`);
}
console.log('  -> metrica deixa de ser definida positiva; argsort passa a premiar o mais anti-alinhado.');

console.log('\n=== TESTE E · a "curvatura" e nula ===');
// M constante => ds2 = ||M^{1/2} delta||^2 => e Euclidiana apos mapa linear fixo => Riemann == 0
function sqrtPSD(M){ // Newton-Schulz simplificado via decomposicao de Cholesky-like (usa Jacobi)
  const n=M.length; let A=M.map(r=>r.slice()), V=Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>i===j?1:0));
  for(let sw=0;sw<40;sw++){ let off=0; for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)off+=A[i][j]**2; if(Math.sqrt(2*off)<1e-12)break;
    for(let p=0;p<n-1;p++)for(let q=p+1;q<n;q++){ if(Math.abs(A[p][q])<1e-15)continue;
      const th=(A[q][q]-A[p][p])/(2*A[p][q]); const t=Math.sign(th||1)/(Math.abs(th)+Math.sqrt(th*th+1));
      const c=1/Math.sqrt(t*t+1), sn=t*c;
      for(let k=0;k<n;k++){const kp=A[k][p],kq=A[k][q];A[k][p]=c*kp-sn*kq;A[k][q]=sn*kp+c*kq;}
      for(let k=0;k<n;k++){const pk=A[p][k],qk=A[q][k];A[p][k]=c*pk-sn*qk;A[q][k]=sn*pk+c*qk;}
      for(let k=0;k<n;k++){const kp=V[k][p],kq=V[k][q];V[k][p]=c*kp-sn*kq;V[k][q]=sn*kp+c*kq;}
    } }
  const lam=A.map((r,i)=>Math.max(0,r[i]));
  const S=Array.from({length:n},()=>new Array(n).fill(0));
  for(let k=0;k<n;k++){const sl=Math.sqrt(lam[k]); for(let i=0;i<n;i++)for(let j=0;j<n;j++)S[i][j]+=sl*V[i][k]*V[j][k];}
  return S;
}
const Dm=48; const qs=norm(vec(Dm)); const dsS=Array.from({length:300},()=>norm(vec(Dm)));
const Ms=apply_field_deformation(qs,3.0); const R=sqrtPSD(Ms);
const map=v=>R.map(row=>dot(row,v));
const rTensor=rankAsc(ds2_paper(dsS,qs,3.0));
const qm=map(qs), dsm=dsS.map(map);
const rEuclid=rankAsc(dsm.map(x=>x.reduce((s,v,i)=>s+(v-qm[i])**2,0)));
console.log(`  ranking sob metrica M  ==  ranking Euclidiano apos x -> M^{1/2}x ?  tau = ${kendall(rTensor,rEuclid).toFixed(6)}`);
console.log('  -> toda metrica CONSTANTE e plana. Riemann identicamente nulo. Sem curvatura, sem buraco de minhoca.');

console.log('\n=== TESTE F · custo ===');
for(const [n,d] of [[2000,256],[10000,768],[100000,1536]]){
  console.log(`  N=${String(n).padStart(6)} d=${String(d).padStart(5)}  produto interno=${(n*d/1e6).toFixed(1)}M flops   contracao tensorial=${(n*d*d/1e9).toFixed(1)}G flops   razao=${d}x`);
}

console.log('\n=== TESTE G · as pontes (bridges) ===');
function retrieve_paper(docs,texts,bridges,q,top_k){
  const r=rankAsc(ds2_paper(docs,q,0.01));
  const set=r.slice(0,top_k);            // list(ranked_indices[:top_k])
  const top=set[0];
  if(bridges[top]) for(const t of bridges[top]) if(!set.includes(t)) set.push(t);
  return set.slice(0,top_k).map(i=>texts[i]);  // <- corta de volta em top_k
}
const tx=Array.from({length:20},(_,i)=>'doc'+i);
const dd=Array.from({length:20},()=>norm(vec(16)));
const qq=norm(vec(16));
const r0=rankAsc(ds2_paper(dd,qq,0.01));
const br={}; br[r0[0]]=[97,98,99].map(x=>x%20);
const outc=retrieve_paper(dd,tx,br,qq,3);
console.log('  top_k=3, ponte declarada de', r0[0], '->', br[r0[0]]);
console.log('  retornado:', JSON.stringify(outc));
console.log('  algum alvo de ponte apareceu?', br[r0[0]].some(t=>outc.includes('doc'+t)));

})();

/* ── G refeito, D refeito, H ── */
(function(){
let s=31415; const u=()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);
let sp=null; const g=()=>{if(sp!==null){const v=sp;sp=null;return v;}let a,b,r;do{a=2*u()-1;b=2*u()-1;r=a*a+b*b;}while(r>=1||r===0);const f=Math.sqrt(-2*Math.log(r)/r);sp=b*f;return a*f;};
const vec=d=>Array.from({length:d},g);
const norm=v=>{const n=Math.hypot(...v);return v.map(x=>x/n);};
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const rankAsc=a=>a.map((v,i)=>i).sort((x,y)=>a[x]-a[y]);
function ds2_paper(docs,q,lambda){
  const d=q.length;
  const M=Array.from({length:d},(_,i)=>Array.from({length:d},(_,j)=>(i===j?1:0)+lambda*q[i]*q[j]));
  return docs.map(x=>{ const dl=x.map((v,i)=>v-q[i]); let s=0;
    for(let i=0;i<d;i++){ let t=0; for(let j=0;j<d;j++) t+=M[i][j]*dl[j]; s+=dl[i]*t; } return s; });
}
function kendall(r1,r2){const p1=[],p2=[];r1.forEach((v,i)=>p1[v]=i);r2.forEach((v,i)=>p2[v]=i);let c=0,d=0;const n=r1.length;
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){const a=p1[i]-p1[j],b=p2[i]-p2[j];(a*b>0)?c++:d++;}return (c-d)/(c+d);}

console.log('=== G (refeito) · pontes com alvos GARANTIDAMENTE fora do top-k ===');
{
  const D=16,N=20;
  const dd=Array.from({length:N},()=>norm(vec(D))); const qq=norm(vec(D));
  const r0=rankAsc(ds2_paper(dd,qq,0.01));
  const top3=r0.slice(0,3);
  const fora=r0.slice(-3);                       // os 3 PIORES: certamente fora do top-3
  const set=[...top3];
  for(const t of fora) if(!set.includes(t)) set.push(t);
  const retornado=set.slice(0,3);
  console.log('  ranking top-3        :',JSON.stringify(top3));
  console.log('  pontes de',r0[0],'para  :',JSON.stringify(fora));
  console.log('  retrieved_set apos append:',JSON.stringify(set));
  console.log('  retornado (slice top_k)  :',JSON.stringify(retornado));
  console.log('  alguma ponte sobreviveu? ', fora.some(t=>retornado.includes(t)));
  console.log('  -> retrieved_set ja tem top_k antes do append; o slice final descarta 100% das pontes.');
}

console.log('\n=== D (refeito) · onde lambda<0 quebra a monotonicidade ===');
{
  const D=256,N=2000;
  const docs=Array.from({length:N},()=>norm(vec(D))); const q=norm(vec(D));
  const rc=rankAsc(docs.map(x=>1-dot(x,q)));
  for(const lam of [-0.4,-0.9,-1.01,-1.5,-2,-3]){
    const v=ds2_paper(docs,q,lam);
    console.log(`  lambda=${String(lam).padStart(6)}  tau vs cosseno=${kendall(rc,rankAsc(v)).toFixed(4)}  ds2<0: ${v.filter(x=>x<0).length}/${N}`);
  }
  console.log('  -> ds2 = 2t + lambda t^2, t=1-cos in [0,2]. d/dt = 2 + 2*lambda*t.');
  console.log('     monotona (== cosseno) enquanto lambda > -1; abaixo disso o ranking inverte na cauda.');
}

console.log('\n=== H · o metodo AJUDA? (recall@10 com verdade plantada, embeddings nao normalizados) ===');
{
  const D=128, Nirr=1500, Nrel=20;
  function experimento(escalaNorma){
    const qbase=norm(vec(D));
    const rel=Array.from({length:Nrel},()=>{ const v=qbase.map(x=>x+0.55*g()); const k=1+escalaNorma*(u()-0.5)*2; return norm(v).map(x=>x*k); });
    const irr=Array.from({length:Nirr},()=>{ const k=1+escalaNorma*(u()-0.5)*2; return norm(vec(D)).map(x=>x*k); });
    const docs=[...rel,...irr]; const relSet=new Set(rel.map((_,i)=>i));
    const q=qbase.map(x=>x*1.0);
    const rec=r=>r.slice(0,10).filter(i=>relSet.has(i)).length/10;
    return {
      cos: rec(rankAsc(docs.map(x=>1-dot(norm(x),norm(q))))),
      l2:  rec(rankAsc(docs.map(x=>x.reduce((s,v,i)=>s+(v-q[i])**2,0)))),
      t001:rec(rankAsc(ds2_paper(docs,q,0.01))),
      t1:  rec(rankAsc(ds2_paper(docs,q,1))),
      t100:rec(rankAsc(ds2_paper(docs,q,100)))
    };
  }
  console.log('  disp.norma   cosseno    L2      tensor(0.01)  tensor(1)  tensor(100)');
  for(const e of [0,0.3,0.8,1.5]){
    const acc={cos:0,l2:0,t001:0,t1:0,t100:0};
    for(let k=0;k<12;k++){ const r=experimento(e); for(const key in acc) acc[key]+=r[key]/12; }
    console.log(`  ${String(e).padEnd(11)}  ${acc.cos.toFixed(3)}     ${acc.l2.toFixed(3)}    ${acc.t001.toFixed(3)}        ${acc.t1.toFixed(3)}      ${acc.t100.toFixed(3)}`);
  }
  console.log('  -> onde difere do cosseno, difere para PIOR: o termo lambda(q.delta)^2 penaliza');
  console.log('     deslocamento AO LONGO da consulta, que e exatamente a direcao relevante.');
}

})();

/* ── I · branqueamento parcial ── */
(function(){
/* Branqueamento parcial: M = V Lambda^{-alpha} V^T. alpha e o botao que lambda queria ser. */
let s=2718; const u=()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);
let sp=null; const g=()=>{if(sp!==null){const v=sp;sp=null;return v;}let a,b,r;do{a=2*u()-1;b=2*u()-1;r=a*a+b*b;}while(r>=1||r===0);const f=Math.sqrt(-2*Math.log(r)/r);sp=b*f;return a*f;};
const vec=d=>Array.from({length:d},g);
const norm=v=>{const n=Math.hypot(...v);return v.map(x=>x/n);};
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const rankAsc=a=>a.map((v,i)=>i).sort((x,y)=>a[x]-a[y]);
function jac(A,sw=60){const n=A.length;const a=A.map(r=>r.slice());const V=Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>i===j?1:0));
 for(let k=0;k<sw;k++){let off=0;for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)off+=a[i][j]**2;if(Math.sqrt(2*off)<1e-12)break;
  for(let p=0;p<n-1;p++)for(let q2=p+1;q2<n;q2++){if(Math.abs(a[p][q2])<1e-15)continue;
   const th=(a[q2][q2]-a[p][p])/(2*a[p][q2]);const t=Math.sign(th||1)/(Math.abs(th)+Math.sqrt(th*th+1));
   const c=1/Math.sqrt(t*t+1),sn=t*c;
   for(let m=0;m<n;m++){const kp=a[m][p],kq=a[m][q2];a[m][p]=c*kp-sn*kq;a[m][q2]=sn*kp+c*kq;}
   for(let m=0;m<n;m++){const pk=a[p][m],qk=a[q2][m];a[p][m]=c*pk-sn*qk;a[q2][m]=sn*pk+c*qk;}
   for(let m=0;m<n;m++){const kp=V[m][p],kq=V[m][q2];V[m][p]=c*kp-sn*kq;V[m][q2]=sn*kp+c*kq;}}}
 const val=a.map((r,i)=>r[i]);const ord=val.map((_,i)=>i).sort((x,y)=>val[y]-val[x]);
 return {values:ord.map(i=>val[i]),vectors:ord.map(i=>V.map(r=>r[i]))};}
function cov(X){const n=X.length,d=X[0].length,mu=new Array(d).fill(0);
 for(const v of X)for(let i=0;i<d;i++)mu[i]+=v[i]/n;
 const S=Array.from({length:d},()=>new Array(d).fill(0));
 for(const v of X)for(let i=0;i<d;i++)for(let j=0;j<d;j++)S[i][j]+=(v[i]-mu[i])*(v[j]-mu[j])/(n-1);return S;}
function metricaAlpha(S,alpha,eps=1e-3){const {values,vectors}=jac(S);const n=S.length;
 const tr=values.reduce((a,b)=>a+b,0)/n;
 const M=Array.from({length:n},()=>new Array(n).fill(0));
 for(let k=0;k<n;k++){const lk=Math.pow(Math.max(values[k],eps*tr)/tr,-alpha);
  for(let i=0;i<n;i++)for(let j=0;j<n;j++)M[i][j]+=lk*vectors[k][i]*vectors[k][j];}
 return M;}
const quad=(M,dl)=>{let s=0;for(let i=0;i<dl.length;i++){let t=0;for(let j=0;j<dl.length;j++)t+=M[i][j]*dl[j];s+=dl[i]*t;}return s;};

const D=64;
const cA=norm(vec(D)), cB=norm(vec(D));
const nuvem=(c,n,sd)=>Array.from({length:n},()=>norm(c.map(x=>x+sd*g())));
const A=nuvem(cA,120,0.25), B=nuvem(cB,120,0.25);
const P=Array.from({length:40},(_,i)=>{const t=(i+1)/41;return norm(cA.map((x,k)=>(1-t)*x+t*cB[k]+0.10*g()));});
const docs=[...A,...B,...P], rot=[...A.map(()=>'A'),...B.map(()=>'B'),...P.map(()=>'P')];
// subconjunto "verdadeiramente relevante" dentro de A: os 15 mais proximos do gerador
const q=norm(cA.map(x=>x+0.15*g()));
const relA=new Set(A.map((x,i)=>({i,d:1-dot(x,cA)})).sort((a,b)=>a.d-b.d).slice(0,15).map(o=>o.i));
const S=cov(docs);

console.log('alpha   prec@10 (relev. em A)   1a posicao de B   composicao top-20');
for(const al of [0,0.15,0.3,0.5,0.75,1.0]){
  const M=metricaAlpha(S,al);
  const r=rankAsc(docs.map(x=>quad(M,x.map((v,i)=>v-q[i]))));
  const prec=r.slice(0,10).filter(i=>relA.has(i)).length/10;
  let p1=-1;for(let k=0;k<r.length;k++)if(rot[r[k]]==='B'){p1=k+1;break;}
  const c={A:0,B:0,P:0};for(const i of r.slice(0,20))c[rot[i]]++;
  console.log(`${String(al).padEnd(7)} ${prec.toFixed(2)}                   ${String(p1).padStart(3)}              ${JSON.stringify(c)}`);
}
console.log('\nalpha=0 e exatamente L2/cosseno. alpha=1 e branqueamento total.');
console.log('O botao entrega o que lambda prometia: alcance entre dominios sem destruir precisao local.');

})();
