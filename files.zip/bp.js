'use strict';
/* UROBOROS · URB2 — propagação de crença (belief propagation) sobre alegações
 *
 * O anel-com-cordas é, literalmente, um grafo de Tanner. Tratar cada
 * ALEGAÇÃO ATÔMICA como um bit e cada CÉLULA como um nó de verificação
 * transforma o consenso do cluster num decodificador LDPC. Toda a
 * maquinaria de decodificação iterativa se aplica — inclusive as armadilhas.
 *
 * Trabalha-se em log-razão de verossimilhança:
 *     L(c) = ln P(c verdadeira) / P(c falsa)
 *     P = σ(L) = 1/(1+e^{-L})
 *
 * TRÊS REGRAS ESTRUTURAIS, cada uma matando um modo de falha distinto:
 *
 * (R1) INFORMAÇÃO EXTRÍNSECA APENAS.
 *      Nenhuma célula recebe de volta evidência que ela mesma originou.
 *      Sem isso, um gossip em anel faz LAVAGEM DE ALUCINAÇÃO: a célula 3
 *      inventa X, X circula pelo anel, e volta à célula 3 como "três pares
 *      concordam". Confiança sobe, verdade não. Princípio turbo.
 *      Implementado com máscara de bits de origem por alegação.
 *
 * (R2) DEFLAÇÃO POR CORRELAÇÃO.
 *      LLRs de células da mesma família são somados e depois divididos por
 *      (1 + (m-1)ρ), m = nº de origens distintas naquela família. Dois
 *      Claudes concordando não são duas testemunhas.
 *
 * (R3) VETO DETERMINÍSTICO DOMINA.
 *      Uma refutação do Polo V injeta L = -L_MAX. Nenhuma quantidade de
 *      concordância entre modelos revoga aritmética.
 *
 * E o aviso teórico que justifica tudo isso:
 *      O consenso por gossip contrai a VARIÂNCIA como λ₂^T, mas o VIÉS
 *      COMPARTILHADO vive no autovetor λ₁=1 e NÃO contrai nunca. Mais
 *      rodadas de consenso deixam o cluster mais confiante numa alucinação
 *      compartilhada, não menos. Viés só sai por heterogeneidade de família
 *      e por âncora externa (verificador/recuperação).
 */

const M = require('./mascara');

const L_MAX = 12;                       // σ(12) ≈ 0.999994
const clamp = x => Math.max(-L_MAX, Math.min(L_MAX, x));
const sigmoid = x => 1 / (1 + Math.exp(-x));
const logit = p => Math.log(Math.min(1 - 1e-9, Math.max(1e-9, p)) / (1 - Math.min(1 - 1e-9, Math.max(1e-9, p))));
const popcount = M.popcount;            // BigInt: sem teto de 31 células

/**
 * Evidência bruta de uma célula sobre uma alegação.
 * @typedef {{cell:number, family:string, bit:number, llr:number, kind?:string}} Ev
 */

/**
 * Agrega evidência com deflação de família e máscara de origem.
 * @param {Ev[]} evs
 * @param {{prior?:number, w?:number[], rho?:Object<string,number>, rhoDefault?:number}} cfg
 */
function aggregate(evs, cfg = {}) {
  const prior = cfg.prior ?? 0;
  const w = cfg.w || null;
  const rhoDefault = cfg.rhoDefault ?? 0.8;

  // veto determinístico curto-circuita tudo
  const veto = evs.find(e => e.kind === 'verifier' && e.llr <= -L_MAX + 1e-9);
  if (veto) return { llr: -L_MAX, p: sigmoid(-L_MAX), mask: veto.bit, nOrigins: 1, vetoed: true };

  const byFam = new Map();
  for (const e of evs) {
    const f = e.kind === 'verifier' ? '__verifier' : e.family;
    if (!byFam.has(f)) byFam.set(f, []);
    byFam.get(f).push(e);
  }

  let total = prior, mask = M.ZERO;
  for (const [fam, list] of byFam) {
    let famMask = M.ZERO;
    for (const e of list) famMask |= e.bit;
    const m = Math.max(1, popcount(famMask));
    // verificador é ground truth: sem deflação
    const rho = fam === '__verifier' ? 0 : (cfg.rho?.[fam] ?? rhoDefault);
    const deflate = 1 / (1 + (m - 1) * rho);
    // Os pesos entram normalizados para MÉDIA 1, não soma 1. Com soma 1 cada
    // LLR era dividido por N e a evidência inteira encolhia com o tamanho do
    // cluster — quanto mais células, menos o grafo acreditava em qualquer coisa.
    let s = 0;
    for (const e of list) s += (w ? (w[e.cell] ?? 1) : 1) * clamp(e.llr);
    total += deflate * s;
    mask |= famMask;
  }
  const llr = clamp(total);
  return { llr, p: sigmoid(llr), mask, nOrigins: M.origens(mask), vetoed: false };
}

/** (R1) mensagem para uma célula-alvo: exclui tudo que ela originou. */
function extrinsic(evs, targetBit, cfg = {}) {
  return aggregate(evs.filter(e => (e.bit & targetBit) === M.ZERO), cfg);
}

/**
 * Grafo de alegações. Uma alegação é identificada por um hash canônico do
 * texto normalizado, de modo que reformulações colidam no mesmo nó.
 */
class ClaimGraph {
  constructor(cfg = {}) {
    this.cfg = { rhoDefault: 0.8, damping: 0.35, ...cfg };
    this.claims = new Map();          // id -> {id, text, evs:Ev[], llr, mask, history:[]}
  }

  static id(text) {
    const s = String(text).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9\s.,+\-]/g, ' ').replace(/\s+/g, ' ').trim();
    let h = 0x811c9dc5;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return h >>> 0;
  }

  add(text, ev) {
    const id = ClaimGraph.id(text);
    if (!this.claims.has(id)) this.claims.set(id, { id, text, evs: [], llr: this.cfg.prior ?? 0, mask: M.ZERO, history: [] });
    const c = this.claims.get(id);
    c.evs.push(ev);
    c.mask |= ev.bit;
    return c;
  }

  /** Uma rodada síncrona com amortecimento (evita superconfiança em laços). */
  step() {
    const a = this.cfg.damping;
    for (const c of this.claims.values()) {
      const r = aggregate(c.evs, this.cfg);
      c.llr = clamp((1 - a) * c.llr + a * r.llr);
      if (r.vetoed) c.llr = -L_MAX;
      c.p = sigmoid(c.llr);
      c.nOrigins = r.nOrigins;
      c.vetoed = r.vetoed;
      c.history.push(c.llr);
    }
    return this;
  }

  /** Roda T passos ou até |ΔL|max < tol. Retorna nº de passos efetivos. */
  run(T = 6, tol = 1e-3) {
    for (let t = 0; t < T; t++) {
      const prev = [...this.claims.values()].map(c => c.llr);
      this.step();
      const now = [...this.claims.values()].map(c => c.llr);
      const d = Math.max(0, ...now.map((x, i) => Math.abs(x - prev[i])));
      if (d < tol) return t + 1;
    }
    return T;
  }

  /** Alegações aceitas, ordenadas por confiança. */
  accepted(threshold) {
    return [...this.claims.values()]
      .filter(c => !c.vetoed && c.p >= threshold)
      .sort((x, y) => y.llr - x.llr);
  }

  rejected(threshold) {
    return [...this.claims.values()].filter(c => c.vetoed || c.p < threshold);
  }

  snapshot() {
    return [...this.claims.values()].map(c => ({
      id: c.id, text: c.text, llr: +c.llr.toFixed(3), p: +sigmoid(c.llr).toFixed(4),
      origens: c.nOrigins ?? M.origens(c.mask), vetado: !!c.vetoed
    }));
  }
}

/** Converte confiança auto-declarada (0..1) em LLR, com teto anti-bravata. */
function confToLLR(conf, capP = 0.93) {
  const p = Math.min(capP, Math.max(1 - capP, Number(conf) || 0.5));
  return logit(p);
}

module.exports = { L_MAX, clamp, sigmoid, logit, popcount, origens: M.origens, aggregate, extrinsic, ClaimGraph, confToLLR };
